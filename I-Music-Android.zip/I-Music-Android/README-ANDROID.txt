I-MUSIC · APP ANDROID NATIVO
============================
Projeto Android Studio (Kotlin). A interface é a mesma do I-Music (pasta app/src/main/assets);
a parte nativa trata das músicas, das permissões e da notificação.

O QUE É NATIVO
- Leitura das músicas pelo MediaStore do Android (rápida, automática, com capas embutidas).
- "Escolher pasta" abre o seletor de pastas do sistema; só as músicas dessa pasta aparecem.
  "Usar todas as músicas do telemóvel" tira o filtro.
- Leitor nativo (ExoPlayer, no MusicService): lê mp3, m4a, flac, ogg, opus, wav; trata do foco de áudio
  (chamadas), pausa ao desligar os auscultadores, tenta de novo se uma música falha a meio e salta as que
  não abrem. A música continua mesmo se o app for removido dos recentes.
- Volume = volume de multimédia do telemóvel (botões físicos e barra do app ficam sincronizados).
- Widgets: "Leitor" (capa, título, anterior/play/seguinte) e "Leitor com lista" (controlos + lista de músicas,
  toque numa música para tocar). Funcionam com o app fechado.
- Capa personalizada: no menu "..." de uma música (Mudar capa / Remover capa) e no botão "Mudar capa" da página
  do álbum (aplica a todas as músicas dele). Escolhe da galeria; fica guardada no app e aparece também na
  notificação e nos widgets.
- Partilhar: no menu "..." da música, no botão Partilhar das páginas de álbum/artista/pasta e no player expandido.
  Envia os ficheiros de música (até 50) pelo menu de partilha do Android.
- Sem passo de escolher pasta no primeiro uso: o app pede a permissão e lê as músicas sozinho.
- Serviço em primeiro plano + MediaSession: notificação com capa, título, anterior / play-pausa / seguinte,
  também no ecrã bloqueado, e botões dos auscultadores / Bluetooth.
- Pede as permissões ao abrir (ler áudio e, no Android 13+, notificações).
- Botão voltar: recua na navegação; na página inicial manda o app para segundo plano (a música continua).

COMO GERAR O APK
1. Instale o Android Studio e abra esta pasta (File > Open). Aguarde o Gradle sincronizar.
2. Teste: ligue o telemóvel (depuração USB) e carregue em Run.
3. APK final: Build > Generate Signed App Bundle / APK > APK.
4. Para mudar o nome do pacote (com.imusic.app), altere "namespace" e "applicationId" em app/build.gradle.kts
   e o package das classes em app/src/main/java.

ATUALIZAR A INTERFACE
Copie os ficheiros novos do I-Music (index.html, app.js, library.js, player.js, storage.js, native.js, manifest.json,
icon-*.png) para app/src/main/assets e gere o APK de novo.

ESTADO DESTE PROJETO (leia)
A reprodução foi movida para o leitor nativo e os widgets são novos: NÃO foram compilados nem testados
(sem Android SDK / Google Maven neste ambiente). Teste: tocar vários formatos, ecrã bloqueado, remover dos
recentes com música a tocar, widgets (adicionar, play/pausa, tocar uma música da lista), volume com os botões.
Se o Gradle reclamar de algum símbolo, é provavelmente um detalhe de API a ajustar.

Escrevi o código mas NÃO o compilei nem o testei num telemóvel: aqui não há Android SDK.
Pode haver erros de compilação pequenos ou comportamentos a ajustar. Pontos que valem teste real:
- notificação e controlos no ecrã bloqueado com o ecrã desligado e a música a avançar sozinha;
- avançar/recuar na música (pedidos Range servidos por LocalFiles.kt);
- escolher pasta (o filtro usa o caminho relativo no MediaStore; em cartão SD com pasta de mesmo nome
  as duas aparecem);
- chamadas e outros apps com som: o app não gere o foco de áudio por conta própria.
Se remover o app dos recentes, a música para (o leitor vive dentro da página).
