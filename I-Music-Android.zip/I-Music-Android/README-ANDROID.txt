I-MUSIC · APP ANDROID NATIVO
============================
Projeto Android Studio (Kotlin). A interface é a mesma do I-Music (pasta app/src/main/assets);
a parte nativa trata das músicas, das permissões e da notificação.

O QUE É NATIVO
- Leitura das músicas pelo MediaStore do Android (rápida, automática, com capas embutidas).
- "Escolher pasta" abre o seletor de pastas do sistema; só as músicas dessa pasta aparecem.
  "Usar todas as músicas do telemóvel" tira o filtro.
- Serviço em primeiro plano + MediaSession: notificação com capa, título, anterior / play-pausa / seguinte,
  também no ecrã bloqueado, e botões dos auscultadores / Bluetooth.
- Pede as permissões ao abrir (ler áudio e, no Android 13+, notificações).
- Botão voltar: recua na navegação; na página inicial manda o app para segundo plano (a música continua).

COMO GERAR O APK
1. Instale o Android Studio e abra esta pasta (File > Open). Aguarde o Gradle sincronizar.
2. Teste: ligue o telemóvel (depuração USB) e carregue em Run.
3. APK final: Build > Generate Signed App Bundle / APK > APK.
4. Para mudar o nome do pacote (com.imusic.app), altere "namespace" e "applicationId" em app/build.gradle.kts
   e o package das classes em app/src/main/java.

ATUALIZAR A INTERFACE
Copie os ficheiros novos do I-Music (index.html, app.js, library.js, player.js, storage.js, native.js, manifest.json,
icon-*.png) para app/src/main/assets e gere o APK de novo.

ESTADO DESTE PROJETO (leia)
Escrevi o código mas NÃO o compilei nem o testei num telemóvel: aqui não há Android SDK.
Pode haver erros de compilação pequenos ou comportamentos a ajustar. Pontos que valem teste real:
- notificação e controlos no ecrã bloqueado com o ecrã desligado e a música a avançar sozinha;
- avançar/recuar na música (pedidos Range servidos por LocalFiles.kt);
- escolher pasta (o filtro usa o caminho relativo no MediaStore; em cartão SD com pasta de mesmo nome
  as duas aparecem);
- chamadas e outros apps com som: o app não gere o foco de áudio por conta própria.
Se remover o app dos recentes, a música para (o leitor vive dentro da página).
