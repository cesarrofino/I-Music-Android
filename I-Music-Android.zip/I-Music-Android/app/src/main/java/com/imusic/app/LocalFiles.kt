package com.imusic.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.InputStream

/**
 * Serve à página o áudio e as capas do MediaStore:
 *   https://appassets.androidplatform.net/native-audio/<id>
 *   https://appassets.androidplatform.net/native-cover/<id>
 * O áudio aceita pedidos Range (necessário para avançar/recuar na música).
 */
object LocalFiles {

    private fun empty(status: Int, reason: String, headers: Map<String, String> = emptyMap()) =
        WebResourceResponse("text/plain", "utf-8", status, reason, headers, ByteArrayInputStream(ByteArray(0)))

    fun audio(ctx: Context, idStr: String, req: WebResourceRequest): WebResourceResponse {
        val id = Uri.decode(idStr).toLongOrNull() ?: return empty(404, "Not Found")
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        val afd = try {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")
        } catch (_: Exception) {
            null
        } ?: return empty(404, "Not Found")

        val total = if (afd.length >= 0) afd.length else afd.parcelFileDescriptor.statSize
        val mime = ctx.contentResolver.getType(uri)?.takeIf { it.startsWith("audio/") } ?: "audio/mpeg"

        var start = 0L
        var end = total - 1
        var partial = false
        val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
        if (range != null && range.startsWith("bytes=") && total > 0) {
            val spec = range.substring(6).substringBefore(',').trim()
            val a = spec.substringBefore('-')
            val b = spec.substringAfter('-', "")
            if (a.isEmpty()) {
                val n = b.toLongOrNull() ?: 0L
                start = maxOf(0L, total - n)
            } else {
                start = a.toLongOrNull() ?: 0L
                if (b.isNotEmpty()) end = minOf(end, b.toLongOrNull() ?: end)
            }
            partial = true
        }
        if (total > 0 && (start > end || start >= total)) {
            afd.close()
            return empty(416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$total"))
        }

        val input = afd.createInputStream()
        var skipped = 0L
        while (skipped < start) {
            val n = input.skip(start - skipped)
            if (n <= 0) break
            skipped += n
        }
        val len = if (total > 0) end - start + 1 else -1L
        val headers = hashMapOf(
            "Accept-Ranges" to "bytes",
            "Access-Control-Allow-Origin" to "*",
            "Cache-Control" to "no-store",
        )
        if (len >= 0) headers["Content-Length"] = len.toString()
        if (partial) headers["Content-Range"] = "bytes $start-$end/$total"
        val body: InputStream = if (len >= 0) LimitedInputStream(input, len) else input
        return WebResourceResponse(
            mime, null,
            if (partial) 206 else 200,
            if (partial) "Partial Content" else "OK",
            headers, body,
        )
    }

    fun cover(ctx: Context, idStr: String): WebResourceResponse {
        val id = Uri.decode(idStr).toLongOrNull() ?: return empty(404, "Not Found")
        val bytes = CoverLoader.jpeg(ctx, id)
            ?: return empty(404, "Not Found", mapOf("Cache-Control" to "max-age=60"))
        return WebResourceResponse(
            "image/jpeg", null, 200, "OK",
            mapOf("Cache-Control" to "max-age=86400", "Access-Control-Allow-Origin" to "*"),
            ByteArrayInputStream(bytes),
        )
    }
}

class LimitedInputStream(private val src: InputStream, private var left: Long) : InputStream() {
    override fun read(): Int {
        if (left <= 0) return -1
        val b = src.read()
        if (b >= 0) left--
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (left <= 0) return -1
        val n = src.read(b, off, minOf(len.toLong(), left).toInt())
        if (n > 0) left -= n
        return n
    }

    override fun available(): Int = minOf(src.available().toLong(), left).toInt()

    override fun close() = src.close()
}
