package com.imusic.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.widget.RemoteViews
import android.widget.RemoteViewsService

/** Widget "Leitor": capa, título e controlos. */
class PlayerWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widgets.update(context, full = true, refreshList = false)
    }
}

/** Widget "Leitor com lista": controlos e a lista de músicas (fila atual ou, sem fila, todas as músicas). */
class ListWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widgets.update(context, full = true, refreshList = true)
    }
}

/** Liga a lista do widget aos dados (WidgetData). */
class SongsWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = SongsFactory(applicationContext)
}

private class SongsFactory(private val ctx: Context) : RemoteViewsService.RemoteViewsFactory {
    private var rows: List<WidgetData.Row> = emptyList()

    override fun onCreate() {}

    override fun onDataSetChanged() {
        rows = WidgetData.rows(ctx)
    }

    override fun onDestroy() {
        rows = emptyList()
    }

    override fun getCount(): Int = rows.size

    override fun getViewAt(position: Int): RemoteViews {
        val r = rows.getOrNull(position) ?: return RemoteViews(ctx.packageName, R.layout.widget_row)
        val rv = RemoteViews(ctx.packageName, R.layout.widget_row)
        rv.setTextViewText(R.id.row_title, r.title)
        rv.setTextViewText(R.id.row_artist, r.artist)
        rv.setTextColor(R.id.row_title, if (r.current) Color.parseColor("#B7A9FF") else Color.WHITE)
        rv.setViewVisibility(R.id.row_playing, if (r.current) android.view.View.VISIBLE else android.view.View.GONE)
        rv.setImageViewBitmap(R.id.row_cover, Widgets.thumb(ctx, r.cover))
        rv.setOnClickFillInIntent(R.id.row, Intent().putExtra("cmd", "playid").putExtra("id", r.id))
        return rv
    }

    override fun getLoadingView(): RemoteViews? = null

    override fun getViewTypeCount(): Int = 1

    override fun getItemId(position: Int): Long = rows.getOrNull(position)?.id ?: position.toLong()

    override fun hasStableIds(): Boolean = true
}

/** Dados da lista do widget. */
object WidgetData {
    data class Row(val id: Long, val title: String, val artist: String, val cover: Long, val current: Boolean)

    fun rows(ctx: Context): List<Row> {
        val saved = QueueStore.loadQueue(ctx)
        val list = if (saved.isNotEmpty()) saved else MediaScanner(ctx).libraryTracks()
        val cur = NowStore.read(ctx).id
        return list.take(500).map { Row(it.id, it.title, it.artist.ifEmpty { ctx.getString(R.string.unknown_artist) }, it.cover, it.id == cur) }
    }
}

/** Desenha e atualiza os dois widgets. */
object Widgets {
    private const val DEFAULT_TINT = 0xFF1B1533.toInt()

    private var coverKey = Long.MIN_VALUE
    private var coverBmp: Bitmap? = null
    private var coverTint = DEFAULT_TINT
    private var lastScrollId = -2L

    /**
     * [full] refaz tudo (inclui a ligação da lista); sem [full] só atualiza textos, capa e botões,
     * o que evita a lista piscar. [refreshList] pede à lista para reler os dados.
     */
    @Synchronized
    fun update(ctx: Context, full: Boolean, refreshList: Boolean) {
        try {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val playerIds = mgr.getAppWidgetIds(ComponentName(app, PlayerWidgetProvider::class.java))
            val listIds = mgr.getAppWidgetIds(ComponentName(app, ListWidgetProvider::class.java))
            if (playerIds.isEmpty() && listIds.isEmpty()) return

            val now = NowStore.read(app)
            val cover = coverFor(app, now.cover)
            val tint = coverTint

            for (id in playerIds) {
                val rv = RemoteViews(app.packageName, R.layout.widget_player)
                header(app, rv, now, cover, tint)
                mgr.updateAppWidget(id, rv)
            }
            for (id in listIds) {
                val rv = RemoteViews(app.packageName, R.layout.widget_list)
                header(app, rv, now, cover, tint)
                if (full) {
                    val svc = Intent(app, SongsWidgetService::class.java)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
                    rv.setRemoteAdapter(R.id.list, svc)
                    rv.setEmptyView(R.id.list, R.id.empty)
                    rv.setOnClickPendingIntent(R.id.empty, openApp(app))
                    val template = PendingIntent.getForegroundService(
                        app, 110,
                        Intent(app, MusicService::class.java).setAction(MusicService.ACT_CMD)
                            .setData(Uri.parse("imusic://cmd/playid")),
                        PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                    )
                    rv.setPendingIntentTemplate(R.id.list, template)
                }
                // Leva a lista até à música que está a tocar quando ela muda
                if (now.index >= 0 && now.id != lastScrollId && refreshList) {
                    rv.setScrollPosition(R.id.list, maxOf(0, now.index - 1))
                }
                if (full) mgr.updateAppWidget(id, rv) else mgr.partiallyUpdateAppWidget(id, rv)
            }
            if (refreshList) lastScrollId = now.id
            if (refreshList && listIds.isNotEmpty()) mgr.notifyAppWidgetViewDataChanged(listIds, R.id.list)
        } catch (_: Exception) {
            // Um widget nunca deve derrubar a música
        }
    }

    private fun header(ctx: Context, rv: RemoteViews, now: NowStore.Now, cover: Bitmap, tint: Int) {
        rv.setInt(R.id.bg, "setColorFilter", tint)
        rv.setImageViewBitmap(R.id.cover, cover)
        rv.setTextViewText(R.id.title, now.title.ifEmpty { ctx.getString(R.string.widget_idle_title) })
        rv.setTextViewText(R.id.artist, now.artist.ifEmpty { ctx.getString(R.string.widget_idle_artist) })
        rv.setImageViewResource(R.id.btn_play, if (now.playing) R.drawable.ic_pause else R.drawable.ic_play)
        rv.setContentDescription(R.id.btn_play, ctx.getString(if (now.playing) R.string.act_pause else R.string.act_play))
        rv.setOnClickPendingIntent(R.id.btn_prev, command(ctx, "prev", 101))
        rv.setOnClickPendingIntent(R.id.btn_play, command(ctx, "toggle", 102))
        rv.setOnClickPendingIntent(R.id.btn_next, command(ctx, "next", 103))
        val open = openApp(ctx)
        rv.setOnClickPendingIntent(R.id.cover, open)
        rv.setOnClickPendingIntent(R.id.texts, open)
    }

    private fun command(ctx: Context, cmd: String, req: Int): PendingIntent = PendingIntent.getForegroundService(
        ctx, req, MusicService.cmdIntent(ctx, cmd),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 100,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    /** Capa grande (arredondada) da música atual; guarda a última para não decodificar sempre. */
    private fun coverFor(ctx: Context, coverId: Long): Bitmap {
        val have = coverBmp
        if (have != null && coverKey == coverId) return have
        val src: Bitmap? = if (coverId > 0) CoverLoader.bitmap(ctx, coverId) else null
        val base: Bitmap = src ?: Art.brand(ctx)
        val out = Art.rounded(base, 256, 40f)
        coverTint = if (src != null) Art.tint(src) else DEFAULT_TINT
        coverKey = coverId
        coverBmp = out
        return out
    }

    private val thumbs = object : android.util.LruCache<Long, Bitmap>(160) {}

    /** Miniatura pequena para as linhas da lista. */
    fun thumb(ctx: Context, coverId: Long): Bitmap {
        thumbs.get(coverId)?.let { return it }
        val src: Bitmap? = if (coverId > 0) CoverLoader.bitmap(ctx, coverId) else null
        val out = Art.rounded(src ?: Art.brand(ctx), 96, 16f)
        thumbs.put(coverId, out)
        return out
    }
}
