package com.imusic.app

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import java.io.ByteArrayOutputStream
import java.util.Collections

/** Capas das músicas (embutidas ou da pasta), em JPEG, com cache em memória. */
object CoverLoader {
    private val cache = object : LruCache<Long, ByteArray>(12 * 1024 * 1024) {
        override fun sizeOf(key: Long, value: ByteArray) = value.size
    }
    private val none: MutableSet<Long> = Collections.synchronizedSet(HashSet())

    fun jpeg(ctx: Context, id: Long): ByteArray? {
        cache.get(id)?.let { return it }
        if (CustomCovers.isCustom(id)) {
            val b = CustomCovers.read(ctx, id) ?: return null
            cache.put(id, b)
            return b
        }
        if (none.contains(id)) return null
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        var bmp: Bitmap? = null
        if (Build.VERSION.SDK_INT >= 29) {
            bmp = try {
                ctx.contentResolver.loadThumbnail(uri, Size(512, 512), null)
            } catch (_: Exception) {
                null
            }
        }
        if (bmp == null) bmp = embedded(ctx, uri)
        if (bmp == null) {
            none.add(id)
            return null
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, out)
        bmp.recycle()
        val bytes = out.toByteArray()
        cache.put(id, bytes)
        return bytes
    }

    fun bitmap(ctx: Context, id: Long): Bitmap? {
        val b = jpeg(ctx, id) ?: return null
        return BitmapFactory.decodeByteArray(b, 0, b.size)
    }

    private fun embedded(ctx: Context, uri: android.net.Uri): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val data = r.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 600 && bounds.outHeight / (sample * 2) >= 600) sample *= 2
            BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }
}
