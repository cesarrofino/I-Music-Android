package com.imusic.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * O leitor de música do app (ExoPlayer) mais a MediaSession e a notificação.
 *
 * Toda a reprodução vive aqui, e não na página: assim a música continua com o ecrã
 * bloqueado, com o app fechado dos recentes, e os widgets conseguem controlá-la.
 * A página (WebView) só mostra o estado e envia comandos pela ponte (NativeBridge).
 */
class MusicService : Service() {
    companion object {
        const val CHANNEL = "imusic_playback"
        const val NOTIF_ID = 1
        const val ACT_BOOT = "com.imusic.app.BOOT"
        const val ACT_CLEAR = "com.imusic.app.CLEAR"
        const val ACT_CMD = "com.imusic.app.CMD"
        private const val IDLE_STOP_MS = 10 * 60 * 1000L

        @Volatile
        var running = false

        /** Intent de comando (usado pela notificação e pelos widgets). */
        fun cmdIntent(ctx: Context, cmd: String): Intent =
            Intent(ctx, MusicService::class.java).setAction(ACT_CMD)
                .setData(android.net.Uri.parse("imusic://cmd/$cmd"))
                .putExtra("cmd", cmd)
    }

    private lateinit var player: ExoPlayer
    private lateinit var session: MediaSessionCompat
    private lateinit var nm: NotificationManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val tracks = ArrayList<QTrack>()

    private var art: Bitmap? = null
    private var artFor = -1L
    private var errorStreak = 0
    private var retriedId = -1L
    private var tickCount = 0
    private var equalizer: Equalizer? = null
    private var eqGains = floatArrayOf(0f, 0f, 0f)

    private val idleStop = Runnable { shutdown() }
    private val ticker = object : Runnable {
        override fun run() {
            tickCount++
            syncSnap()
            if (tickCount % 5 == 0) saveCursor()
            if (playingNow()) main.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate() {
        super.onCreate()
        running = true
        nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, getString(R.string.channel_playback), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)

        session = MediaSessionCompat(this, "I-Music")
        session.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() = doPlay()
            override fun onPause() = player.pause()
            override fun onSkipToNext() = doNext()
            override fun onSkipToPrevious() = doPrev()
            override fun onStop() = player.pause()
            override fun onSeekTo(pos: Long) = player.seekTo(pos)
        })
        session.isActive = true

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true, // gere o foco de áudio: pausa em chamadas e baixa o volume com notificações
            )
            .setHandleAudioBecomingNoisy(true) // pausa ao desligar os auscultadores
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(listener)
        eqGains = QueueStore.eq(this)
        initEqualizer(player.audioSessionId)
        PlayerHub.service = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        // startForegroundService obriga a mostrar a notificação logo
        if (action != ACT_CLEAR) startFg(foregroundNotification())
        when (action) {
            ACT_BOOT -> PlayerHub.drain()
            ACT_CLEAR -> shutdown()
            ACT_CMD -> handleCmd(intent)
            else -> {}
        }
        if (action != ACT_CLEAR && tracks.isEmpty()) shutdown()
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // A música continua se estiver a tocar; em pausa não há motivo para ficar.
        if (!playingNow()) shutdown()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try {
            equalizer?.release()
            equalizer = null
            player.removeListener(listener)
            player.release()
        } catch (_: Exception) {
        }
        try {
            session.isActive = false
            session.release()
        } catch (_: Exception) {
        }
        running = false
        PlayerHub.detach(this)
        super.onDestroy()
    }

    private fun shutdown() {
        main.removeCallbacksAndMessages(null)
        try {
            if (tracks.isNotEmpty()) saveCursor()
            player.pause()
        } catch (_: Exception) {
        }
        NowStore.setPlaying(this, false)
        Widgets.update(applicationContext, full = false, refreshList = false)
        emit(JSONObject().put("e", "stopped"))
        PlayerHub.detach(this) // pedidos seguintes arrancam um serviço novo
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------ comandos (thread principal)

    private fun item(t: QTrack): MediaItem = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, t.id))
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album).build(),
        )
        .build()

    /** Define uma fila nova e começa em [startId]. */
    fun setQueue(list: List<QTrack>, startId: Long, autoplay: Boolean, posMs: Long) {
        if (list.isEmpty()) {
            stopAll()
            return
        }
        tracks.clear()
        tracks.addAll(list)
        val idx = tracks.indexOfFirst { it.id == startId }.coerceAtLeast(0)
        errorStreak = 0
        retriedId = -1L
        player.setMediaItems(tracks.map { item(it) }, idx, if (posMs > 0) posMs else C.TIME_UNSET)
        player.prepare()
        player.playWhenReady = autoplay
        QueueStore.saveQueue(this, tracks)
        onTrackChanged()
        onStateChanged()
    }

    fun setModes(shuffle: Boolean, repeat: Int) {
        player.shuffleModeEnabled = shuffle
        player.repeatMode = when (repeat) {
            1 -> Player.REPEAT_MODE_ALL
            2 -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    /** Equalizador de 3 zonas (graves, médios, agudos) sobre as bandas do equalizador do sistema. */
    fun setEq(bass: Float, mid: Float, treble: Float) {
        eqGains = floatArrayOf(bass, mid, treble)
        applyEq()
    }

    private fun initEqualizer(sessionId: Int) {
        try {
            equalizer?.release()
            equalizer = null
            if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
            equalizer = Equalizer(0, sessionId)
            applyEq()
        } catch (_: Exception) {
            equalizer = null // sem equalizador neste telemóvel: a música toca na mesma
        }
    }

    private fun applyEq() {
        try {
            val e = equalizer ?: return
            val range = e.bandLevelRange
            val lo = range[0].toInt()
            val hi = range[1].toInt()
            for (b in 0 until e.numberOfBands.toInt()) {
                val hz = e.getCenterFreq(b.toShort()) / 1000
                val gain = when {
                    hz < 250 -> eqGains[0]
                    hz < 2500 -> eqGains[1]
                    else -> eqGains[2]
                }
                e.setBandLevel(b.toShort(), (gain * 100f).toInt().coerceIn(lo, hi).toShort())
            }
            e.setEnabled(eqGains.any { it != 0f })
        } catch (_: Exception) {
        }
    }

    /** Capas mudadas pelo utilizador: atualiza a fila, a notificação e os widgets. */
    fun updateCovers(pairs: List<Pair<Long, Long>>) {
        val map = pairs.toMap()
        var curChanged = false
        val curId = cur()?.id
        for (i in tracks.indices) {
            val c = map[tracks[i].id] ?: continue
            tracks[i] = tracks[i].copy(cover = c)
            if (tracks[i].id == curId) curChanged = true
        }
        QueueStore.saveQueue(this, tracks)
        if (curChanged) {
            val t = cur() ?: return
            art = null
            artFor = t.cover
            loadArt(t.cover)
            updateMetadata()
            render(refreshList = true)
        }
    }

    fun playId(id: Long) {
        val i = tracks.indexOfFirst { it.id == id }
        if (i < 0) return
        errorStreak = 0
        player.seekTo(i, 0L)
        doPlay()
    }

    fun doPlay() {
        // Se o serviço foi recriado (ex.: o sistema o terminou), volta a carregar a última fila
        if (!ensureLoaded()) return
        when (player.playbackState) {
            Player.STATE_ENDED -> player.seekTo(0, 0L)
            Player.STATE_IDLE -> player.prepare()
            else -> {}
        }
        player.play()
    }

    fun doPause() = player.pause()

    fun doNext() {
        if (!ensureLoaded()) return
        errorStreak = 0
        if (player.hasNextMediaItem()) player.seekToNextMediaItem() else player.seekTo(0, 0L)
        doPlay()
    }

    fun doPrev() {
        if (!ensureLoaded()) return
        errorStreak = 0
        // Depois de 3 s reinicia a música; antes disso volta à anterior
        player.seekToPrevious()
        doPlay()
    }

    fun seekTo(ms: Long) {
        player.seekTo(ms.coerceAtLeast(0L))
    }

    fun addTrack(t: QTrack) {
        if (tracks.any { it.id == t.id }) return
        tracks.add(t)
        player.addMediaItem(item(t))
        QueueStore.saveQueue(this, tracks)
        emitQueue()
    }

    fun removeId(id: Long) {
        val i = tracks.indexOfFirst { it.id == id }
        if (i < 0) return
        tracks.removeAt(i)
        if (tracks.isEmpty()) {
            stopAll()
            return
        }
        player.removeMediaItem(i)
        QueueStore.saveQueue(this, tracks)
    }

    /** Esvazia a fila, mantendo só a música atual. */
    fun clearOthers() {
        val cur = player.currentMediaItemIndex
        val keep = tracks.getOrNull(cur) ?: return
        if (cur + 1 < player.mediaItemCount) player.removeMediaItems(cur + 1, player.mediaItemCount)
        if (cur > 0) player.removeMediaItems(0, cur)
        tracks.clear()
        tracks.add(keep)
        QueueStore.saveQueue(this, tracks)
    }

    /** Pára tudo e esquece a fila. */
    fun stopAll() {
        try {
            player.stop()
            player.clearMediaItems()
        } catch (_: Exception) {
        }
        tracks.clear()
        QueueStore.clear(this)
        NowStore.save(this, null, false, -1)
        shutdown()
    }

    private fun handleCmd(intent: Intent?) {
        when (intent?.getStringExtra("cmd")) {
            "play" -> if (ensureLoaded()) doPlay()
            "pause" -> player.pause()
            "toggle" -> if (playingNow()) player.pause() else if (ensureLoaded()) doPlay()
            "next" -> if (ensureLoaded()) doNext()
            "prev" -> if (ensureLoaded()) doPrev()
            "stop" -> {
                player.pause()
                shutdown()
            }
            "playid" -> {
                val id = intent.getLongExtra("id", -1L)
                if (id < 0 || !ensureLoaded()) return
                if (tracks.none { it.id == id }) {
                    if (!loadLibraryQueue()) return
                }
                playId(id)
            }
        }
    }

    /** Garante que há fila: a última guardada ou, se não houver, todas as músicas do telemóvel. */
    private fun ensureLoaded(): Boolean {
        if (tracks.isNotEmpty()) return true
        val saved = QueueStore.loadQueue(this)
        val cur = QueueStore.cursor(this)
        if (saved.isNotEmpty()) {
            tracks.addAll(saved)
            val found = tracks.indexOfFirst { it.id == cur.id }
            val startMs = if (found >= 0 && cur.posMs > 0) cur.posMs else C.TIME_UNSET
            setModes(cur.shuffle, cur.repeat)
            player.setMediaItems(tracks.map { item(it) }, found.coerceAtLeast(0), startMs)
            player.prepare()
            emitQueue()
            onTrackChanged()
            return true
        }
        return loadLibraryQueue()
    }

    private fun loadLibraryQueue(): Boolean {
        val list = try {
            MediaScanner(applicationContext).libraryTracks()
        } catch (_: Exception) {
            emptyList()
        }
        if (list.isEmpty()) return false
        tracks.clear()
        tracks.addAll(list)
        val cur = QueueStore.cursor(this)
        setModes(cur.shuffle, cur.repeat)
        player.setMediaItems(tracks.map { item(it) }, 0, C.TIME_UNSET)
        player.prepare()
        QueueStore.saveQueue(this, tracks)
        emitQueue()
        onTrackChanged()
        return true
    }

    // ------------------------------------------------------------------ eventos do ExoPlayer

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            retriedId = -1L
            onTrackChanged()
        }

        override fun onPlaybackStateChanged(playbackState: Int) = onStateChanged()

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = onStateChanged()

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) errorStreak = 0
            onStateChanged()
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int,
        ) {
            if (reason == Player.DISCONTINUITY_REASON_SEEK || reason == Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT) {
                syncSnap()
                updateSessionState()
                emit(JSONObject().put("e", "seek").put("pos", player.currentPosition))
            }
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) = initEqualizer(audioSessionId)

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = onModesChanged()

        override fun onRepeatModeChanged(repeatMode: Int) = onModesChanged()

        override fun onPlayerError(error: PlaybackException) = handleError(error)
    }

    private fun repeatInt(): Int = when (player.repeatMode) {
        Player.REPEAT_MODE_ALL -> 1
        Player.REPEAT_MODE_ONE -> 2
        else -> 0
    }

    private fun onModesChanged() {
        QueueStore.saveModes(this, player.shuffleModeEnabled, repeatInt())
        emit(JSONObject().put("e", "modes").put("shuffle", player.shuffleModeEnabled).put("repeat", repeatInt()))
    }

    private fun cur(): QTrack? = tracks.getOrNull(player.currentMediaItemIndex)

    private fun playingNow(): Boolean {
        val st = player.playbackState
        return player.playWhenReady && st != Player.STATE_ENDED && st != Player.STATE_IDLE
    }

    private fun durOf(t: QTrack?): Long {
        val d = player.duration
        return if (d > 0) d else (t?.durMs ?: 0L)
    }

    private fun syncSnap() {
        val t = cur()
        PlayerHub.snapId = t?.id ?: -1L
        PlayerHub.snapPos = player.currentPosition
        PlayerHub.snapAt = SystemClock.elapsedRealtime()
        PlayerHub.snapMoving = player.isPlaying
        PlayerHub.snapIntent = playingNow()
        PlayerHub.snapBuffering = player.playbackState == Player.STATE_BUFFERING
        PlayerHub.snapDur = durOf(t)
    }

    private fun saveCursor() {
        val t = cur() ?: return
        QueueStore.saveCursor(this, t.id, player.currentPosition)
    }

    private fun onTrackChanged() {
        val t = cur()
        syncSnap()
        art = null
        artFor = t?.cover ?: -1L
        if (t != null) loadArt(t.cover)
        updateMetadata()
        render(refreshList = true)
        if (t != null) {
            emit(
                JSONObject().put("e", "track").put("id", t.id.toString())
                    .put("pos", player.currentPosition).put("dur", durOf(t))
                    .put("playing", playingNow()).put("buffering", player.playbackState == Player.STATE_BUFFERING),
            )
        }
    }

    private fun onStateChanged() {
        syncSnap()
        val playing = playingNow()
        main.removeCallbacks(ticker)
        main.removeCallbacks(idleStop)
        if (playing) main.postDelayed(ticker, 1000L)
        else if (tracks.isNotEmpty()) main.postDelayed(idleStop, IDLE_STOP_MS)
        render(refreshList = false)
        val t = cur()
        emit(
            JSONObject().put("e", "state").put("playing", playing)
                .put("buffering", player.playbackState == Player.STATE_BUFFERING)
                .put("pos", player.currentPosition).put("dur", durOf(t)),
        )
        if (!playing) saveCursor()
    }

    private fun handleError(error: PlaybackException) {
        val idx = player.currentMediaItemIndex
        val t = tracks.getOrNull(idx)
        val kind = when (error.errorCode) {
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "missing"
            PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> "permission"
            else -> "decode"
        }
        // Primeiro tenta de novo a mesma música, no mesmo ponto (falhas passageiras do sistema de ficheiros)
        if (t != null && kind == "decode" && retriedId != t.id) {
            retriedId = t.id
            val pos = player.currentPosition
            player.seekTo(idx, pos)
            player.prepare()
            player.play()
            return
        }
        errorStreak++
        var skipped = false
        if (kind != "permission" && errorStreak < tracks.size) {
            val next = nextAfterError(idx)
            if (next >= 0) {
                player.seekTo(next, 0L)
                player.prepare()
                player.play()
                skipped = true
            }
        }
        emit(
            JSONObject().put("e", "error").put("id", (t?.id ?: -1L).toString())
                .put("kind", kind).put("skip", skipped),
        )
        if (!skipped) {
            errorStreak = 0
            player.playWhenReady = false
            onStateChanged()
        }
    }

    private fun nextAfterError(idx: Int): Int {
        val n = tracks.size
        if (n <= 1) return -1
        if (player.shuffleModeEnabled) {
            var r = (0 until n).random()
            if (r == idx) r = (r + 1) % n
            return r
        }
        if (idx + 1 < n) return idx + 1
        return if (player.repeatMode != Player.REPEAT_MODE_OFF) 0 else -1
    }

    private fun emit(o: JSONObject) = Dispatch.player(o)

    private fun emitQueue() {
        val ids = JSONArray()
        tracks.forEach { ids.put(it.id.toString()) }
        emit(JSONObject().put("e", "queue").put("ids", ids).put("id", (cur()?.id ?: -1L).toString()))
    }

    // ------------------------------------------------------------------ sessão, notificação, widgets

    private fun loadArt(id: Long) {
        if (id <= 0L) return
        io.execute {
            val b = CoverLoader.bitmap(applicationContext, id)
            main.post {
                if (artFor == id && b != null) {
                    art = b
                    updateMetadata()
                    render(refreshList = false)
                }
            }
        }
    }

    private fun updateMetadata() {
        val t = cur() ?: return
        val cover: Bitmap = art ?: Art.brand(this)
        val md = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, t.title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, t.artist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, t.album)
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, durOf(t))
            .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, cover)
            .putBitmap(MediaMetadataCompat.METADATA_KEY_ART, cover)
            .putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, cover)
        session.setMetadata(md.build())
    }

    private fun updateSessionState() {
        val state = when {
            player.playbackState == Player.STATE_BUFFERING && playingNow() -> PlaybackStateCompat.STATE_BUFFERING
            playingNow() -> PlaybackStateCompat.STATE_PLAYING
            else -> PlaybackStateCompat.STATE_PAUSED
        }
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                        PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                        PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO or
                        PlaybackStateCompat.ACTION_STOP,
                )
                .setState(state, player.currentPosition, if (player.isPlaying) 1f else 0f, SystemClock.elapsedRealtime())
                .build(),
        )
    }

    private fun render(refreshList: Boolean) {
        val t = cur() ?: return
        updateSessionState()
        startFg(buildNotification(t))
        NowStore.save(this, t, playingNow(), player.currentMediaItemIndex)
        Widgets.update(applicationContext, full = false, refreshList = refreshList)
    }

    private fun startFg(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (_: Exception) {
        }
    }

    private fun foregroundNotification(): Notification {
        val t = cur()
        return if (t != null) buildNotification(t) else basicNotification()
    }

    private fun cmd(c: String, req: Int): PendingIntent = PendingIntent.getService(
        this, req, cmdIntent(this, c),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotification(t: QTrack): Notification {
        val playing = playingNow()
        val playPause = if (playing) {
            NotificationCompat.Action(R.drawable.ic_pause, getString(R.string.act_pause), cmd("pause", 2))
        } else {
            NotificationCompat.Action(R.drawable.ic_play, getString(R.string.act_play), cmd("play", 2))
        }
        val cover: Bitmap = art ?: Art.brand(this)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setColor(Art.tint(cover))
            .setColorized(true)
            .setContentTitle(t.title)
            .setContentText(t.artist)
            .setSubText(t.album.ifEmpty { null })
            .setContentIntent(openApp())
            .setDeleteIntent(
                PendingIntent.getService(
                    this, 5, Intent(this, MusicService::class.java).setAction(ACT_CLEAR),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                ),
            )
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(playing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(NotificationCompat.Action(R.drawable.ic_prev, getString(R.string.act_prev), cmd("prev", 1)))
            .addAction(playPause)
            .addAction(NotificationCompat.Action(R.drawable.ic_next, getString(R.string.act_next), cmd("next", 3)))
            .addAction(NotificationCompat.Action(R.drawable.ic_close, getString(R.string.act_close), cmd("stop", 4)))
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setMediaSession(session.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2),
            )
            .setLargeIcon(cover)
            .build()
    }

    private fun basicNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle(getString(R.string.app_name))
            .setContentIntent(openApp())
            .build()
}
