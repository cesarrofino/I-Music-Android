package com.imusic.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.concurrent.Executors

/** Estado da música atual enviado pela página. Tempos em milissegundos. */
data class SessionInfo(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val cover: Long,
    val playing: Boolean,
    val pos: Long,
    val dur: Long,
) {
    fun toJson(): String = JSONObject()
        .put("id", id).put("title", title).put("artist", artist).put("album", album)
        .put("cover", cover.toString()).put("playing", playing).put("pos", pos).put("dur", dur)
        .toString()

    companion object {
        fun fromJson(s: String): SessionInfo {
            val o = JSONObject(s)
            return SessionInfo(
                o.optString("id"), o.optString("title"), o.optString("artist"), o.optString("album"),
                o.optString("cover").toLongOrNull() ?: 0L,
                o.optBoolean("playing"), o.optLong("pos"), o.optLong("dur"),
            )
        }
    }
}

/**
 * Serviço em primeiro plano com MediaSession e notificação de media.
 * É ele que mostra os controlos no ecrã bloqueado, na barra de notificações e nos auscultadores.
 * A música continua a tocar na página (WebView); os botões são reenviados para ela.
 */
class MusicService : Service() {
    companion object {
        const val CHANNEL = "imusic_playback"
        const val NOTIF_ID = 1
        const val ACT_UPDATE = "com.imusic.app.UPDATE"
        const val ACT_CLEAR = "com.imusic.app.CLEAR"
        const val ACT_CMD = "com.imusic.app.CMD"
        private const val IDLE_STOP_MS = 10 * 60 * 1000L

        @Volatile
        var running = false

        fun update(ctx: Context, info: SessionInfo) {
            val i = Intent(ctx, MusicService::class.java).setAction(ACT_UPDATE).putExtra("json", info.toJson())
            ContextCompat.startForegroundService(ctx, i)
        }

        fun clear(ctx: Context) {
            if (!running) return
            ctx.startService(Intent(ctx, MusicService::class.java).setAction(ACT_CLEAR))
        }
    }

    private lateinit var session: MediaSessionCompat
    private lateinit var nm: NotificationManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var info: SessionInfo? = null
    private var art: Bitmap? = null
    private var artFor = -1L
    private val idleStop = Runnable { shutdown() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, getString(R.string.channel_playback), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)

        session = MediaSessionCompat(this, "I-Music")
        session.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() = Dispatch.action("play")
            override fun onPause() = Dispatch.action("pause")
            override fun onSkipToNext() = Dispatch.action("next")
            override fun onSkipToPrevious() = Dispatch.action("prev")
            override fun onStop() = Dispatch.action("pause")
            override fun onSeekTo(pos: Long) = Dispatch.action("seek", pos)
        })
        session.isActive = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_UPDATE -> {
                val parsed = try {
                    SessionInfo.fromJson(intent.getStringExtra("json").orEmpty())
                } catch (_: Exception) {
                    null
                }
                if (parsed != null) {
                    apply(parsed)
                } else {
                    // startForegroundService exige startForeground; depois fecha
                    startFg(basicNotification())
                    shutdown()
                }
            }
            ACT_CLEAR -> shutdown()
            ACT_CMD -> {
                val c = intent.getStringExtra("cmd")
                if (c == "stop") {
                    Dispatch.action("pause")
                    shutdown()
                } else if (c != null) {
                    Dispatch.action(c)
                }
            }
            else -> {
                startFg(basicNotification())
                shutdown()
            }
        }
        return START_NOT_STICKY
    }

    private fun apply(i: SessionInfo) {
        val prev = info
        info = i
        if (prev == null || prev.cover != i.cover) {
            art = null
            artFor = i.cover
            loadArt(i.cover)
        }
        main.removeCallbacks(idleStop)
        if (!i.playing) main.postDelayed(idleStop, IDLE_STOP_MS)
        render()
    }

    private fun loadArt(id: Long) {
        if (id <= 0L) return
        io.execute {
            val b = CoverLoader.bitmap(applicationContext, id)
            main.post {
                if (artFor == id && b != null) {
                    art = b
                    render()
                }
            }
        }
    }

    private fun render() {
        val i = info ?: return
        val state = if (i.playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                        PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                        PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO or
                        PlaybackStateCompat.ACTION_STOP,
                )
                .setState(state, i.pos, if (i.playing) 1f else 0f, SystemClock.elapsedRealtime())
                .build(),
        )
        val md = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, i.title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, i.artist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, i.album)
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, i.dur)
        art?.let {
            md.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, it)
            md.putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, it)
        }
        session.setMetadata(md.build())
        startFg(buildNotification(i))
    }

    private fun startFg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun cmd(c: String, req: Int): PendingIntent = PendingIntent.getService(
        this, req,
        Intent(this, MusicService::class.java).setAction(ACT_CMD).putExtra("cmd", c),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotification(i: SessionInfo): Notification {
        val playPause = if (i.playing) {
            NotificationCompat.Action(R.drawable.ic_pause, getString(R.string.act_pause), cmd("pause", 2))
        } else {
            NotificationCompat.Action(R.drawable.ic_play, getString(R.string.act_play), cmd("play", 2))
        }
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle(i.title)
            .setContentText(i.artist)
            .setSubText(i.album.ifEmpty { null })
            .setContentIntent(openApp())
            .setDeleteIntent(
                PendingIntent.getService(
                    this, 5, Intent(this, MusicService::class.java).setAction(ACT_CLEAR),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                ),
            )
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(i.playing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(NotificationCompat.Action(R.drawable.ic_prev, getString(R.string.act_prev), cmd("prev", 1)))
            .addAction(playPause)
            .addAction(NotificationCompat.Action(R.drawable.ic_next, getString(R.string.act_next), cmd("next", 3)))
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setMediaSession(session.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2),
            )
        art?.let { b.setLargeIcon(it) }
        return b.build()
    }

    private fun basicNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle(getString(R.string.app_name))
            .setContentIntent(openApp())
            .build()

    private fun shutdown() {
        main.removeCallbacksAndMessages(null)
        info = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        shutdown()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try {
            session.isActive = false
            session.release()
        } catch (_: Exception) {
        }
        running = false
        super.onDestroy()
    }
}
