package com.imusic.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ContentUris
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {
    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val START_URL = "https://$HOST/assets/index.html"
        private const val SPLASH_MIN_MS = 700L   // tempo mínimo do splash
        private const val SPLASH_MAX_MS = 2500L  // limite máximo (segurança)
    }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge
    private lateinit var loader: WebViewAssetLoader
    private val prefs by lazy { getSharedPreferences("imusic", MODE_PRIVATE) }
    private var hadPermission = false
    private var pageReady = false
    private var lastVolume = -1f

    /** Avisa a página quando o volume do telemóvel muda (botões físicos, painel do sistema). */
    private val volumeObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) = pushVolume()
    }

    private fun pushVolume() {
        if (!::bridge.isInitialized) return
        val v: Float = bridge.currentVolume()
        if (v == lastVolume) return
        lastVolume = v
        Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onVolume($v)")
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            hadPermission = hasAudioPermission()
            Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onPermission($hadPermission)")
        }

    private val treeLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                bridge.addFolder(uri)
                Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onFolderPicked()")
            }
        }

    private var coverKey: String = ""

    private val coverLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            val key = coverKey
            if (uri == null) {
                Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onCoverPicked('$key','')")
            } else {
                Thread {
                    val id: Long? = CustomCovers.save(applicationContext, uri)
                    Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onCoverPicked('$key','${id ?: ""}')")
                }.start()
            }
        }

    fun pickCover(key: String) {
        coverKey = key.filter { it.isLetterOrDigit() }
        try {
            coverLauncher.launch("image/*")
        } catch (_: Exception) {
            Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onCoverPicked('$coverKey','')")
        }
    }

    /** Partilha ficheiros de música pelo menu do Android (WhatsApp, Bluetooth, Drive...). */
    fun shareTracks(ids: List<Long>) {
        val uris = ids.map { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it) }
        val intent: Intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        intent.type = if (uris.size == 1) {
            contentResolver.getType(uris[0])?.takeIf { it.startsWith("audio/") } ?: "audio/*"
        } else {
            "audio/*"
        }
        val clip = ClipData.newRawUri(null, uris[0])
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(Intent.createChooser(intent, getString(R.string.share_title)))
        } catch (_: Exception) {
        }
    }

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED

    /** Pede leitura de áudio e (Android 13+) notificações. Se já foi negado de vez, abre as definições. */
    fun askPermissions() {
        val list = arrayListOf<String>()
        if (!hasAudioPermission()) list.add(audioPermission)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) list.add(Manifest.permission.POST_NOTIFICATIONS)
        if (list.isEmpty()) return

        val asked = prefs.getBoolean("asked_perm", false)
        if (!hasAudioPermission() && asked && !shouldShowRequestPermissionRationale(audioPermission)) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)),
            )
            return
        }
        prefs.edit().putBoolean("asked_perm", true).apply()
        permLauncher.launch(list.toTypedArray())
    }

    fun pickFolder() {
        try {
            treeLauncher.launch(null)
        } catch (_: Exception) {
        }
    }

    /** Cor de fundo atual da página; serve para escolher ícones escuros (fundo claro) ou claros (fundo escuro) na barra de estado. */
    private var themeColor: Int = 0

    fun applyTheme(color: Int) {
        themeColor = color
        root.setBackgroundColor(color)
        val light: Boolean = ColorUtils.calculateLuminance(color) > 0.5
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = light
        c.isAppearanceLightNavigationBars = light
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Tem de ser chamado antes do super.onCreate()
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        // Os botões de volume mexem sempre no volume da música
        volumeControlStream = AudioManager.STREAM_MUSIC

        // Mantém o splash até a página carregar (mín. 0,7 s, máx. 2,5 s)
        val t0: Long = SystemClock.uptimeMillis()
        splash.setKeepOnScreenCondition {
            val elapsed: Long = SystemClock.uptimeMillis() - t0
            !(pageReady && elapsed >= SPLASH_MIN_MS) && elapsed < SPLASH_MAX_MS
        }
        // Saída suave (fade) em vez de corte seco
        splash.setOnExitAnimationListener { provider ->
            provider.view.animate()
                .alpha(0f)
                .setDuration(250L)
                .withEndAction { provider.remove() }
                .start()
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)

        root = FrameLayout(this)
        root.setBackgroundColor(ContextCompat.getColor(this, R.color.app_bg))
        web = WebView(this)
        web.setBackgroundColor(Color.TRANSPARENT)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        // Estado inicial das barras do sistema (antes de a página enviar a cor)
        applyTheme(ContextCompat.getColor(this, R.color.app_bg))

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime(),
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }

        loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host == HOST) {
                    val p = u.path.orEmpty()
                    if (p.startsWith("/native-audio/")) return LocalFiles.audio(applicationContext, p.removePrefix("/native-audio/"), request)
                    if (p.startsWith("/native-cover/")) return LocalFiles.cover(applicationContext, p.removePrefix("/native-cover/"))
                }
                return loader.shouldInterceptRequest(u)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageReady = true
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == HOST) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (_: Exception) {
                }
                return true
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }

        bridge = NativeBridge(this)
        web.addJavascriptInterface(bridge, "AndroidNative")
        Dispatch.web = web

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
                }
            },
        )

        hadPermission = hasAudioPermission()
        web.loadUrl(START_URL)
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        if (themeColor != 0) applyTheme(themeColor) // alguns telemóveis repõem os ícones ao voltar à app
        contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, volumeObserver)
        lastVolume = -1f
        pushVolume()
        // Voltou das definições com a permissão ativada
        val now = hasAudioPermission()
        if (now && !hadPermission) {
            Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onPermission(true)")
        }
        hadPermission = now
    }

    override fun onPause() {
        try {
            contentResolver.unregisterContentObserver(volumeObserver)
        } catch (_: Exception) {
        }
        super.onPause()
    }

    // De propósito NÃO chamamos web.onPause(): a página fica viva em segundo plano.
    // A música não depende dela: toca no MusicService (ExoPlayer).

    override fun onDestroy() {
        // A música continua no MusicService; só a página é destruída
        Dispatch.web = null
        root.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
