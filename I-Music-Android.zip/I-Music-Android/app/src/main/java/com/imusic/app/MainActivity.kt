package com.imusic.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {
    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val START_URL = "https://$HOST/assets/index.html"
    }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge
    private lateinit var loader: WebViewAssetLoader
    private val prefs by lazy { getSharedPreferences("imusic", MODE_PRIVATE) }
    private var hadPermission = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            hadPermission = hasAudioPermission()
            Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onPermission($hadPermission)")
        }

    private val treeLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                bridge.addFolder(uri)
                Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onFolderPicked()")
            }
        }

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED

    /** Pede leitura de áudio e (Android 13+) notificações. Se já foi negado de vez, abre as definições. */
    fun askPermissions() {
        val list = arrayListOf<String>()
        if (!hasAudioPermission()) list.add(audioPermission)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) list.add(Manifest.permission.POST_NOTIFICATIONS)
        if (list.isEmpty()) return

        val asked = prefs.getBoolean("asked_perm", false)
        if (!hasAudioPermission() && asked && !shouldShowRequestPermissionRationale(audioPermission)) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)),
            )
            return
        }
        prefs.edit().putBoolean("asked_perm", true).apply()
        permLauncher.launch(list.toTypedArray())
    }

    fun pickFolder() {
        try {
            treeLauncher.launch(null)
        } catch (_: Exception) {
        }
    }

    fun applyTheme(color: Int) {
        root.setBackgroundColor(color)
        val light = ColorUtils.calculateLuminance(color) > 0.5
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        root = FrameLayout(this)
        root.setBackgroundColor(ContextCompat.getColor(this, R.color.app_bg))
        web = WebView(this)
        web.setBackgroundColor(Color.TRANSPARENT)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime(),
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }

        loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host == HOST) {
                    val p = u.path.orEmpty()
                    if (p.startsWith("/native-audio/")) return LocalFiles.audio(applicationContext, p.removePrefix("/native-audio/"), request)
                    if (p.startsWith("/native-cover/")) return LocalFiles.cover(applicationContext, p.removePrefix("/native-cover/"))
                }
                return loader.shouldInterceptRequest(u)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == HOST) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (_: Exception) {
                }
                return true
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }

        bridge = NativeBridge(this)
        web.addJavascriptInterface(bridge, "AndroidNative")
        Dispatch.web = web

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
                }
            },
        )

        hadPermission = hasAudioPermission()
        web.loadUrl(START_URL)
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        // Voltou das definições com a permissão ativada
        val now = hasAudioPermission()
        if (now && !hadPermission) {
            Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onPermission(true)")
        }
        hadPermission = now
    }

    // De propósito NÃO chamamos web.onPause(): a música continua com o ecrã bloqueado ou noutra app.

    override fun onDestroy() {
        Dispatch.web = null
        MusicService.clear(applicationContext)
        root.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
