package com.imusic.app

import android.webkit.WebView
import org.json.JSONObject

/** Envia comandos do lado nativo para a página (WebView). Se a página não existir, ignora. */
object Dispatch {
    @Volatile
    var web: WebView? = null

    fun js(code: String) {
        val w = web ?: return
        w.post {
            try {
                w.evaluateJavascript(code, null)
            } catch (_: Exception) {
            }
        }
    }

    /** Evento do leitor nativo (mudança de música, estado, erro...). */
    fun player(o: JSONObject) = js("window.IMusicNativeHost&&IMusicNativeHost.onPlayer($o)")
}
