package com.imusic.app

import android.webkit.WebView

/** Envia comandos do lado nativo para a página (WebView). */
object Dispatch {
    @Volatile
    var web: WebView? = null

    fun js(code: String) {
        val w = web ?: return
        w.post {
            try {
                w.evaluateJavascript(code, null)
            } catch (_: Exception) {
            }
        }
    }

    fun action(name: String, arg: Long = 0L) =
        js("window.IMusicNativeHost&&IMusicNativeHost.onAction('$name',$arg)")
}
