package com.imusic.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils

/** Funções de imagem partilhadas pela notificação e pelos widgets. */
object Art {
    private var brand: Bitmap? = null

    /** Ícone do app desenhado num bitmap (usado quando a música não tem capa). */
    @Synchronized
    fun brand(ctx: Context): Bitmap {
        brand?.let { return it }
        val size = 512
        val bmp: Bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val d = ContextCompat.getDrawable(ctx, R.mipmap.ic_launcher)
        if (d != null) {
            d.setBounds(0, 0, size, size)
            d.draw(Canvas(bmp))
        } else {
            bmp.eraseColor(Color.parseColor("#8F7DFF"))
        }
        brand = bmp
        return bmp
    }

    /** Recorta ao centro em quadrado, redimensiona e arredonda os cantos. */
    fun rounded(src: Bitmap, size: Int, radiusPx: Float): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val s: Float = maxOf(size.toFloat() / src.width, size.toFloat() / src.height)
        val m = Matrix()
        m.setScale(s, s)
        m.postTranslate((size - src.width * s) / 2f, (size - src.height * s) / 2f)
        val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        shader.setLocalMatrix(m)
        paint.shader = shader
        Canvas(out).drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), radiusPx, radiusPx, paint)
        return out
    }

    /** Cor média da capa, escurecida para o texto branco ficar legível. */
    fun tint(b: Bitmap): Int {
        return try {
            val px: Int = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            ColorUtils.blendARGB(px or 0xFF000000.toInt(), Color.BLACK, 0.55f)
        } catch (_: Exception) {
            Color.parseColor("#2A1F5C")
        }
    }
}
