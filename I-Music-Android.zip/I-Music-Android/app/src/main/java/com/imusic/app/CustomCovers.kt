package com.imusic.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Capas escolhidas pelo utilizador (para uma música ou um álbum).
 * Cada capa é um ficheiro JPEG em files/covers/<id>.jpg; o id é sempre >= BASE para nunca
 * colidir com os _ID do MediaStore, e por isso circula como qualquer outro id de capa.
 */
object CustomCovers {
    const val BASE = 1_000_000_000_000L

    private fun dir(ctx: Context): File = File(ctx.applicationContext.filesDir, "covers").apply { mkdirs() }

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("imusic_covers", Context.MODE_PRIVATE)

    fun isCustom(id: Long): Boolean = id >= BASE

    fun read(ctx: Context, id: Long): ByteArray? = try {
        val f = File(dir(ctx), "$id.jpg")
        if (f.exists()) f.readBytes() else null
    } catch (_: Exception) {
        null
    }

    /** Lê a imagem escolhida, reduz para no máximo 1024 px e guarda. Devolve o id novo ou null. */
    fun save(ctx: Context, uri: Uri): Long? {
        return try {
            val data = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1024 && bounds.outHeight / (sample * 2) >= 1024) sample *= 2
            var bmp = BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            val longest = maxOf(bmp.width, bmp.height)
            if (longest > 1024) {
                val k = 1024f / longest
                val scaled = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
                if (scaled !== bmp) bmp.recycle()
                bmp = scaled
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
            bmp.recycle()
            var id = System.currentTimeMillis().coerceAtLeast(BASE)
            while (File(dir(ctx), "$id.jpg").exists()) id++
            File(dir(ctx), "$id.jpg").writeBytes(out.toByteArray())
            id
        } catch (_: Exception) {
            null
        }
    }

    /** Liga cada música a uma capa personalizada (coverId >= BASE) ou remove a ligação. */
    fun setOverrides(ctx: Context, pairs: List<Pair<Long, Long>>) {
        val e = prefs(ctx).edit()
        pairs.forEach { (track, cover) ->
            if (isCustom(cover)) e.putLong(track.toString(), cover) else e.remove(track.toString())
        }
        e.apply()
    }

    fun overrideFor(ctx: Context, trackId: Long): Long = prefs(ctx).getLong(trackId.toString(), 0L)
}
