package com.imusic.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat

/**
 * Ponto de contacto entre a ponte da página / widgets e o MusicService.
 * O ExoPlayer só pode ser usado na thread principal, por isso os pedidos são
 * guardados e executados lá; se o serviço ainda não existe, é arrancado primeiro.
 */
object PlayerHub {
    @Volatile
    var service: MusicService? = null

    private val main = Handler(Looper.getMainLooper())
    private val pending = ArrayList<(MusicService) -> Unit>()

    // Retrato do estado, escrito pelo serviço e lido pela ponte (thread do WebView)
    @Volatile var snapId = -1L
    @Volatile var snapPos = 0L
    @Volatile var snapAt = 0L
    @Volatile var snapMoving = false      // a posição está a avançar
    @Volatile var snapIntent = false      // há intenção de tocar
    @Volatile var snapBuffering = false
    @Volatile var snapDur = 0L

    fun position(): Long {
        var p = snapPos
        if (snapMoving) p += SystemClock.elapsedRealtime() - snapAt
        val d = snapDur
        return if (d > 0) minOf(p, d) else p
    }

    /** Executa [block] na thread principal com o serviço ligado (arranca-o se for preciso). */
    fun run(ctx: Context, block: (MusicService) -> Unit) {
        val app = ctx.applicationContext
        main.post {
            val s = service
            if (s != null) {
                block(s)
            } else {
                pending.add(block)
                try {
                    ContextCompat.startForegroundService(
                        app, Intent(app, MusicService::class.java).setAction(MusicService.ACT_BOOT),
                    )
                } catch (_: Exception) {
                    pending.clear()
                }
            }
        }
    }

    /** Só executa se o serviço já estiver a correr. */
    fun ifRunning(block: (MusicService) -> Unit) {
        main.post { service?.let(block) }
    }

    fun drain() {
        val s = service ?: return
        val list = ArrayList(pending)
        pending.clear()
        list.forEach {
            try {
                it(s)
            } catch (_: Exception) {
            }
        }
    }

    /** O serviço [s] terminou. Só limpa se ainda for o serviço registado (pode já haver um novo). */
    fun detach(s: MusicService) {
        if (service !== s) return
        service = null
        snapId = -1L; snapPos = 0L; snapMoving = false; snapIntent = false; snapBuffering = false; snapDur = 0L
    }
}
