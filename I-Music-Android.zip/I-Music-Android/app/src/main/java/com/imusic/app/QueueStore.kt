package com.imusic.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Uma música da fila. O id é o _ID do MediaStore; os tempos estão em milissegundos. */
data class QTrack(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val cover: Long,
    val durMs: Long,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("i", id.toString()).put("t", title).put("a", artist).put("b", album)
        .put("c", cover.toString()).put("d", durMs)

    companion object {
        fun fromJson(o: JSONObject): QTrack? {
            val id = o.optString("i").toLongOrNull() ?: return null
            return QTrack(
                id, o.optString("t"), o.optString("a"), o.optString("b"),
                o.optString("c").toLongOrNull() ?: 0L, o.optLong("d"),
            )
        }

        fun parseArray(s: String): List<QTrack> {
            val a = JSONArray(s)
            val out = ArrayList<QTrack>(a.length())
            for (i in 0 until a.length()) fromJson(a.getJSONObject(i))?.let { out.add(it) }
            return out
        }
    }
}

/**
 * Guarda a fila no disco para que os widgets e o serviço a encontrem mesmo com o app fechado.
 *  - queue.json: lista de músicas (escrita fora da thread principal);
 *  - preferências: música atual, posição, aleatório e repetição.
 */
object QueueStore {
    private const val FILE = "queue.json"
    private val io = Executors.newSingleThreadExecutor()
    private val lock = Any()

    data class Cursor(val id: Long, val posMs: Long, val shuffle: Boolean, val repeat: Int)

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("imusic_queue", Context.MODE_PRIVATE)

    fun saveQueue(ctx: Context, tracks: List<QTrack>) {
        val app = ctx.applicationContext
        val snapshot = ArrayList(tracks)
        io.execute {
            try {
                val a = JSONArray()
                snapshot.forEach { a.put(it.toJson()) }
                synchronized(lock) {
                    val tmp = File(app.filesDir, "$FILE.tmp")
                    tmp.writeText(a.toString())
                    if (!tmp.renameTo(File(app.filesDir, FILE))) File(app.filesDir, FILE).writeText(a.toString())
                }
            } catch (_: Exception) {
            }
        }
    }

    /** Espera as escritas pendentes e lê a fila guardada. */
    fun loadQueue(ctx: Context): List<QTrack> {
        try {
            io.submit { }.get(3, TimeUnit.SECONDS)
        } catch (_: Exception) {
        }
        return synchronized(lock) {
            try {
                val f = File(ctx.applicationContext.filesDir, FILE)
                if (f.exists()) QTrack.parseArray(f.readText()) else emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    fun cursor(ctx: Context): Cursor {
        val p = prefs(ctx)
        return Cursor(p.getLong("id", -1L), p.getLong("pos", 0L), p.getBoolean("shuffle", false), p.getInt("repeat", 0))
    }

    fun saveCursor(ctx: Context, id: Long, posMs: Long) {
        prefs(ctx).edit().putLong("id", id).putLong("pos", posMs).apply()
    }

    fun saveModes(ctx: Context, shuffle: Boolean, repeat: Int) {
        prefs(ctx).edit().putBoolean("shuffle", shuffle).putInt("repeat", repeat).apply()
    }

    /** Equalizador: ganho em dB de graves, médios e agudos. */
    fun saveEq(ctx: Context, bass: Float, mid: Float, treble: Float) {
        prefs(ctx).edit().putFloat("eq_b", bass).putFloat("eq_m", mid).putFloat("eq_t", treble).apply()
    }

    fun eq(ctx: Context): FloatArray {
        val p = prefs(ctx)
        return floatArrayOf(p.getFloat("eq_b", 0f), p.getFloat("eq_m", 0f), p.getFloat("eq_t", 0f))
    }

    fun clear(ctx: Context) {
        val app = ctx.applicationContext
        prefs(app).edit().remove("id").remove("pos").apply()
        io.execute {
            synchronized(lock) {
                try {
                    File(app.filesDir, FILE).delete()
                } catch (_: Exception) {
                }
            }
        }
    }
}

/** O que os widgets mostram (guardado para sobreviver ao fim do processo). */
object NowStore {
    data class Now(
        val id: Long,
        val title: String,
        val artist: String,
        val cover: Long,
        val playing: Boolean,
        val index: Int,
    )

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("imusic_now", Context.MODE_PRIVATE)

    fun save(ctx: Context, t: QTrack?, playing: Boolean, index: Int) {
        val e = prefs(ctx).edit()
        if (t == null) {
            e.clear()
        } else {
            e.putLong("id", t.id).putString("title", t.title).putString("artist", t.artist)
                .putLong("cover", t.cover).putBoolean("playing", playing).putInt("index", index)
        }
        e.apply()
    }

    fun setPlaying(ctx: Context, playing: Boolean) {
        prefs(ctx).edit().putBoolean("playing", playing).apply()
    }

    fun read(ctx: Context): Now {
        val p = prefs(ctx)
        return Now(
            p.getLong("id", -1L), p.getString("title", "").orEmpty(), p.getString("artist", "").orEmpty(),
            p.getLong("cover", 0L), p.getBoolean("playing", false), p.getInt("index", -1),
        )
    }
}
