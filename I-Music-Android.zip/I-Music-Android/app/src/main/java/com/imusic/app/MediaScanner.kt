package com.imusic.app

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

/** Lê as músicas do telemóvel pelo MediaStore (instantâneo, sem abrir ficheiro a ficheiro). */
class MediaScanner(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("imusic", Context.MODE_PRIVATE)

    data class Folder(val id: String, val name: String, val rel: String)

    fun folders(): List<Folder> {
        val raw = prefs.getString("folders", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Folder(o.getString("id"), o.getString("name"), o.getString("rel"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(list: List<Folder>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("rel", it.rel)) }
        prefs.edit().putString("folders", a.toString()).apply()
    }

    fun foldersJson(): String {
        val a = JSONArray()
        folders().forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }
        return a.toString()
    }

    /** Guarda a pasta escolhida no seletor do sistema (ex.: primary:Music/Rock). */
    fun addFolder(tree: Uri) {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val rel = docId.substringAfter(':', "").trim('/')
        if (rel.isEmpty()) {
            clear()
            return
        }
        val name = rel.substringAfterLast('/')
        save(folders().filter { it.rel != rel } + Folder(docId, name, rel))
    }

    fun clear() {
        prefs.edit().remove("folders").apply()
    }

    private fun clean(s: String?): String =
        if (s == null || s == MediaStore.UNKNOWN_STRING) "" else s.trim()

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    /** Devolve true se terminou, false se foi cancelado. */
    fun scan(cancelled: () -> Boolean, emit: (JSONObject) -> Unit): Boolean {
        val m = MediaStore.Audio.Media
        val proj = arrayListOf(
            m._ID, m.TITLE, m.ARTIST, m.ALBUM, m.TRACK, m.DURATION, m.SIZE,
            m.DATE_MODIFIED, m.DATE_ADDED, m.DISPLAY_NAME, m.MIME_TYPE, m.ALBUM_ID,
        )
        val pathCol = if (Build.VERSION.SDK_INT >= 29) m.RELATIVE_PATH else m.DATA
        proj.add(pathCol)
        val hasAA = Build.VERSION.SDK_INT >= 30
        if (hasAA) proj.add(m.ALBUM_ARTIST)

        val sel = StringBuilder("${m.IS_MUSIC} != 0 AND ${m.DURATION} > 0")
        val args = ArrayList<String>()
        val fs = folders()
        if (fs.isNotEmpty()) {
            sel.append(" AND (")
            fs.forEachIndexed { i, f ->
                if (i > 0) sel.append(" OR ")
                sel.append("$pathCol LIKE ? ESCAPE '\\'")
                args.add(if (Build.VERSION.SDK_INT >= 29) esc(f.rel) + "/%" else "%/" + esc(f.rel) + "/%")
            }
            sel.append(")")
        }

        var finished = true
        ctx.contentResolver.query(m.EXTERNAL_CONTENT_URI, proj.toTypedArray(), sel.toString(), args.toTypedArray(), null)?.use { c ->
            val total = c.count
            val iId = c.getColumnIndexOrThrow(m._ID)
            val iTitle = c.getColumnIndexOrThrow(m.TITLE)
            val iArtist = c.getColumnIndexOrThrow(m.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(m.ALBUM)
            val iTrack = c.getColumnIndexOrThrow(m.TRACK)
            val iDur = c.getColumnIndexOrThrow(m.DURATION)
            val iSize = c.getColumnIndexOrThrow(m.SIZE)
            val iMod = c.getColumnIndexOrThrow(m.DATE_MODIFIED)
            val iAdd = c.getColumnIndexOrThrow(m.DATE_ADDED)
            val iName = c.getColumnIndexOrThrow(m.DISPLAY_NAME)
            val iMime = c.getColumnIndexOrThrow(m.MIME_TYPE)
            val iAlbumId = c.getColumnIndexOrThrow(m.ALBUM_ID)
            val iPath = c.getColumnIndexOrThrow(pathCol)
            val iAA = if (hasAA) c.getColumnIndex(m.ALBUM_ARTIST) else -1

            val albumFirst = HashMap<Long, Long>()
            var items = JSONArray()
            while (c.moveToNext()) {
                if (cancelled()) {
                    finished = false
                    break
                }
                val id = c.getLong(iId)
                val name = c.getString(iName).orEmpty()
                val album = clean(c.getString(iAlbum))
                val albumId = c.getLong(iAlbumId)
                val coverId = if (album.isEmpty() || albumId == 0L) id else albumFirst.getOrPut(albumId) { id }
                val rawPath = c.getString(iPath).orEmpty()
                val folder = if (Build.VERSION.SDK_INT >= 29) rawPath.trim('/')
                else rawPath.substringBeforeLast('/', "").removePrefix("/storage/emulated/0/").trim('/')
                val title = clean(c.getString(iTitle)).ifEmpty { name.substringBeforeLast('.') }
                items.put(
                    JSONObject()
                        .put("i", id).put("t", title)
                        .put("a", clean(c.getString(iArtist))).put("b", album)
                        .put("aa", if (iAA >= 0) clean(c.getString(iAA)) else "")
                        .put("n", c.getInt(iTrack) % 1000)
                        .put("d", (c.getLong(iDur) / 1000L).toInt())
                        .put("s", c.getLong(iSize)).put("m", c.getLong(iMod)).put("da", c.getLong(iAdd))
                        .put("f", folder).put("nm", name).put("ty", c.getString(iMime).orEmpty())
                        .put("c", coverId),
                )
                if (items.length() >= 250) {
                    emit(JSONObject().put("total", total).put("items", items))
                    items = JSONArray()
                }
            }
            if (finished && items.length() > 0) emit(JSONObject().put("total", total).put("items", items))
        }
        return finished
    }
}
