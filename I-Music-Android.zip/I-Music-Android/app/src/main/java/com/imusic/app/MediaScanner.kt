package com.imusic.app

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

/** Lê as músicas do telemóvel pelo MediaStore (instantâneo, sem abrir ficheiro a ficheiro). */
class MediaScanner(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("imusic", Context.MODE_PRIVATE)

    data class Folder(val id: String, val name: String, val rel: String)

    fun folders(): List<Folder> {
        val raw = prefs.getString("folders", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Folder(o.getString("id"), o.getString("name"), o.getString("rel"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(list: List<Folder>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("rel", it.rel)) }
        prefs.edit().putString("folders", a.toString()).apply()
    }

    fun foldersJson(): String {
        val a = JSONArray()
        folders().forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }
        return a.toString()
    }

    /** Guarda a pasta escolhida no seletor do sistema (ex.: primary:Music/Rock). */
    fun addFolder(tree: Uri) {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val rel = docId.substringAfter(':', "").trim('/')
        if (rel.isEmpty()) {
            clear()
            return
        }
        val name = rel.substringAfterLast('/')
        save(folders().filter { it.rel != rel } + Folder(docId, name, rel))
    }

    fun clear() {
        prefs.edit().remove("folders").apply()
    }

    private fun clean(s: String?): String =
        if (s == null || s == MediaStore.UNKNOWN_STRING) "" else s.trim()

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    /** Filtro das músicas: só música com duração e, se houver pastas escolhidas, só essas. */
    private fun selection(isQ: Boolean, pathCol: String): Pair<String, Array<String>> {
        val sel = StringBuilder(
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 0"
        )
        val args: ArrayList<String> = ArrayList()
        val fs: List<Folder> = folders()
        if (fs.isNotEmpty()) {
            sel.append(" AND (")
            fs.forEachIndexed { i: Int, f: Folder ->
                if (i > 0) sel.append(" OR ")
                sel.append("$pathCol LIKE ? ESCAPE '\\'")
                args.add(if (isQ) esc(f.rel) + "/%" else "%/" + esc(f.rel) + "/%")
            }
            sel.append(")")
        }
        return Pair(sel.toString(), args.toTypedArray())
    }

    /** Todas as músicas (já com o filtro de pastas), por ordem alfabética. Usado pelos widgets e pelo serviço. */
    @Suppress("DEPRECATION")
    fun libraryTracks(): List<QTrack> {
        val isQ: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val pathCol: String =
            if (isQ) MediaStore.Audio.Media.RELATIVE_PATH else MediaStore.Audio.Media.DATA
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            pathCol,
        )
        val (sel: String, args: Array<String>) = selection(isQ, pathCol)
        val out = ArrayList<QTrack>()
        try {
            ctx.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, args, null)?.use { c: Cursor ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val albumFirst: HashMap<Long, Long> = HashMap()
                while (c.moveToNext()) {
                    val id: Long = c.getLong(iId)
                    val album: String = clean(c.getString(iAlbum))
                    val albumId: Long = c.getLong(iAlbumId)
                    // Mesma regra do scan(): a capa do álbum é a da primeira música dele
                    val coverId: Long =
                        if (album.isEmpty() || albumId == 0L) id else albumFirst.getOrPut(albumId) { id }
                    val title: String = clean(c.getString(iTitle))
                        .ifEmpty { c.getString(iName).orEmpty().substringBeforeLast('.') }
                    val custom: Long = CustomCovers.overrideFor(ctx, id)
                    out.add(QTrack(id, title, clean(c.getString(iArtist)), album, if (custom > 0) custom else coverId, c.getLong(iDur)))
                }
            }
        } catch (_: Exception) {
        }
        val collator = java.text.Collator.getInstance()
        out.sortWith { a: QTrack, b: QTrack -> collator.compare(a.title, b.title) }
        return out
    }

    /** Devolve true se terminou, false se foi cancelado. */
    @Suppress("DEPRECATION") // MediaStore.Audio.Media.DATA só é usado abaixo da API 29
    fun scan(cancelled: () -> Boolean, emit: (JSONObject) -> Unit): Boolean {
        val isQ: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val hasAA: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

        // RELATIVE_PATH (API 29+) ou DATA (API 26-28)
        val pathCol: String =
            if (isQ) MediaStore.Audio.Media.RELATIVE_PATH else MediaStore.Audio.Media.DATA

        val proj: ArrayList<String> = arrayListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ALBUM_ID,
        )
        proj.add(pathCol)
        if (hasAA) proj.add(MediaStore.Audio.Media.ALBUM_ARTIST)

        val (sel: String, args: Array<String>) = selection(isQ, pathCol)

        var finished = true
        val cursor: Cursor? = ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            proj.toTypedArray(),
            sel,
            args,
            null,
        )

        cursor?.use { c: Cursor ->
            val total: Int = c.count
            val iId: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iTrack: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iDur: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iSize: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val iMod: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
            val iAdd: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iName: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iMime: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val iAlbumId: Int = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iPath: Int = c.getColumnIndexOrThrow(pathCol)
            val iAA: Int =
                if (hasAA) c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ARTIST) else -1

            val albumFirst: HashMap<Long, Long> = HashMap()
            var items = JSONArray()
            while (c.moveToNext()) {
                if (cancelled()) {
                    finished = false
                    break
                }
                val id: Long = c.getLong(iId)
                val name: String = c.getString(iName).orEmpty()
                val album: String = clean(c.getString(iAlbum))
                val albumId: Long = c.getLong(iAlbumId)
                val coverId: Long =
                    if (album.isEmpty() || albumId == 0L) id
                    else albumFirst.getOrPut(albumId) { id }
                val rawPath: String = c.getString(iPath).orEmpty()
                val folder: String =
                    if (isQ) rawPath.trim('/')
                    else rawPath.substringBeforeLast('/', "")
                        .removePrefix("/storage/emulated/0/").trim('/')
                val title: String =
                    clean(c.getString(iTitle)).ifEmpty { name.substringBeforeLast('.') }
                items.put(
                    JSONObject()
                        .put("i", id).put("t", title)
                        .put("a", clean(c.getString(iArtist))).put("b", album)
                        .put("aa", if (iAA >= 0) clean(c.getString(iAA)) else "")
                        .put("n", c.getInt(iTrack) % 1000)
                        .put("d", (c.getLong(iDur) / 1000L).toInt())
                        .put("s", c.getLong(iSize)).put("m", c.getLong(iMod))
                        .put("da", c.getLong(iAdd))
                        .put("f", folder).put("nm", name)
                        .put("ty", c.getString(iMime).orEmpty())
                        .put("c", coverId),
                )
                if (items.length() >= 250) {
                    emit(JSONObject().put("total", total).put("items", items))
                    items = JSONArray()
                }
            }
            if (finished && items.length() > 0) {
                emit(JSONObject().put("total", total).put("items", items))
            }
        }
        return finished
    }
}
