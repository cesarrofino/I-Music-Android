package com.imusic.app

import android.content.Context
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Objeto exposto à página como window.AndroidNative.
 * Os métodos anotados correm numa thread própria do WebView, nunca na principal.
 */
class NativeBridge(private val act: MainActivity) {
    private val ctx: Context = act.applicationContext
    private val scanner = MediaScanner(ctx)
    private val io = Executors.newSingleThreadExecutor()
    private val audio: AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Volatile
    private var cancel = false

    @Volatile
    private var scanning = false

    // ------------------------------------------------------------------ permissões e biblioteca

    @JavascriptInterface
    fun hasPermission(): Boolean = act.hasAudioPermission()

    @JavascriptInterface
    fun requestPermission() {
        act.runOnUiThread { act.askPermissions() }
    }

    @JavascriptInterface
    fun scan() {
        if (scanning) return
        scanning = true
        cancel = false
        io.execute {
            try {
                val finished = scanner.scan({ cancel }) { chunk ->
                    Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onTracks($chunk)")
                }
                val end = JSONObject().put("cancelled", !finished)
                Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onScanEnd($end)")
            } catch (e: Exception) {
                val end = JSONObject().put("error", e.message ?: "scan")
                Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onScanEnd($end)")
            } finally {
                scanning = false
            }
        }
    }

    @JavascriptInterface
    fun cancelScan() {
        cancel = true
    }

    @JavascriptInterface
    fun pickFolder() {
        act.runOnUiThread { act.pickFolder() }
    }

    @JavascriptInterface
    fun getFolders(): String = scanner.foldersJson()

    @JavascriptInterface
    fun clearFolders() {
        scanner.clear()
    }

    // ------------------------------------------------------------------ leitor nativo

    /**
     * Define a fila e começa a tocar em [id] (_ID do MediaStore).
     * Sem [autoplay] e sem o serviço a correr, só guarda a fila (para os widgets) e não arranca nada.
     */
    @JavascriptInterface
    fun playerSetQueue(json: String, id: String, autoplay: Boolean, posMs: Double) {
        val list = try {
            QTrack.parseArray(json)
        } catch (_: Exception) {
            return
        }
        val sid = id.toLongOrNull() ?: -1L
        val pos = posMs.toLong()
        if (!autoplay && !MusicService.running) {
            QueueStore.saveQueue(ctx, list)
            QueueStore.saveCursor(ctx, sid, pos)
            return
        }
        PlayerHub.run(ctx) { it.setQueue(list, sid, autoplay, pos) }
    }

    /** Guarda a fila / posição quando o leitor nativo não está a correr (json vazio = só a posição). */
    @JavascriptInterface
    fun playerSave(json: String, id: String, posMs: Double) {
        if (MusicService.running) return
        if (json.isNotEmpty()) {
            try {
                QueueStore.saveQueue(ctx, QTrack.parseArray(json))
            } catch (_: Exception) {
                return
            }
        }
        val sid = id.toLongOrNull() ?: return
        QueueStore.saveCursor(ctx, sid, posMs.toLong())
    }

    @JavascriptInterface
    fun playerPlayId(id: String) {
        val v = id.toLongOrNull() ?: return
        PlayerHub.run(ctx) { it.playId(v) }
    }

    @JavascriptInterface
    fun playerPlay() {
        PlayerHub.run(ctx) { it.doPlay() }
    }

    @JavascriptInterface
    fun playerPause() {
        PlayerHub.ifRunning { it.doPause() }
    }

    @JavascriptInterface
    fun playerNext() {
        PlayerHub.run(ctx) { it.doNext() }
    }

    @JavascriptInterface
    fun playerPrev() {
        PlayerHub.run(ctx) { it.doPrev() }
    }

    @JavascriptInterface
    fun playerSeek(ms: Double) {
        val v = ms.toLong()
        PlayerHub.ifRunning { it.seekTo(v) }
    }

    @JavascriptInterface
    fun playerSetModes(shuffle: Boolean, repeat: Int) {
        QueueStore.saveModes(ctx, shuffle, repeat)
        PlayerHub.ifRunning { it.setModes(shuffle, repeat) }
    }

    @JavascriptInterface
    fun playerAdd(trackJson: String) {
        val t = try {
            QTrack.fromJson(JSONObject(trackJson))
        } catch (_: Exception) {
            null
        } ?: return
        PlayerHub.ifRunning { it.addTrack(t) }
    }

    @JavascriptInterface
    fun playerRemove(id: String) {
        val v = id.toLongOrNull() ?: return
        PlayerHub.ifRunning { it.removeId(v) }
    }

    @JavascriptInterface
    fun playerClearOthers() {
        PlayerHub.ifRunning { it.clearOthers() }
    }

    @JavascriptInterface
    fun playerStop() {
        PlayerHub.ifRunning { it.stopAll() }
        if (!MusicService.running) {
            QueueStore.clear(ctx)
            NowStore.save(ctx, null, false, -1)
            Widgets.update(ctx, full = false, refreshList = true)
        }
    }

    @JavascriptInterface
    fun playerSetEq(bass: Double, mid: Double, treble: Double) {
        QueueStore.saveEq(ctx, bass.toFloat(), mid.toFloat(), treble.toFloat())
        PlayerHub.ifRunning { it.setEq(bass.toFloat(), mid.toFloat(), treble.toFloat()) }
    }

    /** Posição atual em milissegundos (a página pergunta várias vezes por segundo). */
    @JavascriptInterface
    fun playerPosition(): Double = PlayerHub.position().toDouble()

    /** Estado guardado/atual: serve à página para se ligar ao leitor quando abre. */
    @JavascriptInterface
    fun playerState(): String {
        val running = MusicService.running && PlayerHub.service != null
        val q = QueueStore.loadQueue(ctx)
        val cur = QueueStore.cursor(ctx)
        val ids = JSONArray()
        q.forEach { ids.put(it.id.toString()) }
        val id = if (running && PlayerHub.snapId >= 0) PlayerHub.snapId else cur.id
        return JSONObject()
            .put("running", running)
            .put("hasQueue", q.isNotEmpty())
            .put("ids", ids)
            .put("id", id.toString())
            .put("pos", if (running) PlayerHub.position() else cur.posMs)
            .put("playing", running && PlayerHub.snapIntent)
            .put("buffering", running && PlayerHub.snapBuffering)
            .put("dur", PlayerHub.snapDur)
            .put("shuffle", cur.shuffle)
            .put("repeat", cur.repeat)
            .toString()
    }

    // ------------------------------------------------------------------ volume do sistema

    private val maxVol: Int get() = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    /** Volume de multimédia do telemóvel, de 0 a 1. */
    fun currentVolume(): Float = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol

    @JavascriptInterface
    fun getVolume(): Double = currentVolume().toDouble()

    @JavascriptInterface
    fun setVolume(v: Double) {
        val idx = Math.round(v.coerceIn(0.0, 1.0) * maxVol).toInt()
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0)
        } catch (_: Exception) {
        }
    }

    /** Vibração curta (como os botões de volume do sistema) ao mudar de nível. */
    @JavascriptInterface
    fun tick() {
        act.runOnUiThread {
            try {
                act.window.decorView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ capas e partilha

    /** Abre a galeria para escolher uma imagem; o resultado volta em IMusicNativeHost.onCoverPicked(key, id). */
    @JavascriptInterface
    fun pickCover(key: String) {
        act.runOnUiThread { act.pickCover(key) }
    }

    /** [json]: lista de {i: id da música, c: id da capa nova}. c < BASE remove a capa personalizada. */
    @JavascriptInterface
    fun setCoverOverride(json: String) {
        val pairs = try {
            val a = JSONArray(json)
            (0 until a.length()).mapNotNull {
                val o = a.getJSONObject(it)
                val t = o.optString("i").toLongOrNull()
                val c = o.optString("c").toLongOrNull() ?: 0L
                if (t == null) null else Pair(t, c)
            }
        } catch (_: Exception) {
            return
        }
        CustomCovers.setOverrides(ctx, pairs)
        PlayerHub.ifRunning { it.updateCovers(pairs) }
        Widgets.update(ctx, full = false, refreshList = true)
    }

    /** Abre o menu de partilha do Android com os ficheiros de música (máx. 50). */
    @JavascriptInterface
    fun shareTracks(idsJson: String) {
        val ids = try {
            val a = JSONArray(idsJson)
            (0 until a.length()).mapNotNull { a.optString(it).toLongOrNull() }.take(50)
        } catch (_: Exception) {
            return
        }
        if (ids.isEmpty()) return
        act.runOnUiThread { act.shareTracks(ids) }
    }

    // ------------------------------------------------------------------ aparência

    @JavascriptInterface
    fun setTheme(hex: String) {
        val color = try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            return
        }
        act.runOnUiThread { act.applyTheme(color) }
    }

    /** Usado pela atividade depois do seletor de pastas do sistema. */
    fun addFolder(tree: Uri) {
        scanner.addFolder(tree)
    }
}
