package com.imusic.app

import android.graphics.Color
import android.net.Uri
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Objeto exposto à página como window.AndroidNative.
 * Os métodos anotados correm numa thread própria do WebView, nunca na principal.
 */
class NativeBridge(private val act: MainActivity) {
    private val scanner = MediaScanner(act.applicationContext)
    private val io = Executors.newSingleThreadExecutor()

    @Volatile
    private var cancel = false

    @Volatile
    private var scanning = false

    @JavascriptInterface
    fun hasPermission(): Boolean = act.hasAudioPermission()

    @JavascriptInterface
    fun requestPermission() {
        act.runOnUiThread { act.askPermissions() }
    }

    @JavascriptInterface
    fun scan() {
        if (scanning) return
        scanning = true
        cancel = false
        io.execute {
            try {
                val finished = scanner.scan({ cancel }) { chunk ->
                    Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onTracks($chunk)")
                }
                val end = JSONObject().put("cancelled", !finished)
                Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onScanEnd($end)")
            } catch (e: Exception) {
                val end = JSONObject().put("error", e.message ?: "scan")
                Dispatch.js("window.IMusicNativeHost&&IMusicNativeHost.onScanEnd($end)")
            } finally {
                scanning = false
            }
        }
    }

    @JavascriptInterface
    fun cancelScan() {
        cancel = true
    }

    @JavascriptInterface
    fun pickFolder() {
        act.runOnUiThread { act.pickFolder() }
    }

    @JavascriptInterface
    fun getFolders(): String = scanner.foldersJson()

    @JavascriptInterface
    fun clearFolders() {
        scanner.clear()
    }

    /** Chamado pela página quando muda a música, o estado ou a posição. */
    @JavascriptInterface
    fun updateSession(json: String) {
        val info = try {
            SessionInfo.fromJson(json)
        } catch (_: Exception) {
            return
        }
        // Não arranca o serviço só por restaurar a sessão em pausa
        if (!MusicService.running && !info.playing) return
        MusicService.update(act.applicationContext, info)
    }

    @JavascriptInterface
    fun clearSession() {
        MusicService.clear(act.applicationContext)
    }

    @JavascriptInterface
    fun setTheme(hex: String) {
        val color = try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            return
        }
        act.runOnUiThread { act.applyTheme(color) }
    }

    /** Usado pela atividade depois do seletor de pastas do sistema. */
    fun addFolder(tree: Uri) {
        scanner.addFolder(tree)
    }
}
