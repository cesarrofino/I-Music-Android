/**
 * I-Music · native.js
 * Ponte com o app Android nativo (window.AndroidNative). Fora do app nativo não faz nada.
 *  - recebe da camada nativa as músicas, a pasta escolhida e a permissão;
 *  - recebe os eventos do leitor nativo (música, estado, erros) e o volume do telemóvel;
 *  - a música, a notificação, o ecrã bloqueado e os widgets são tratados pelo MusicService:
 *    o player.js só envia comandos e mostra o estado.
 */
(function (global) {
  'use strict';
  const IMusic = (global.IMusic = global.IMusic || {});
  const N = global.AndroidNative;
  if (!N) { IMusic.Native = { available: false }; return; }

  const Player = IMusic.Player, Library = IMusic.Library;
  const call = (fn, arg) => { try { return arg === undefined ? N[fn]() : N[fn](arg); } catch (_) { return null; } };
  const parse = (v) => (typeof v === 'string' ? JSON.parse(v) : v);

  /* ------------------------ Nativo → página ------------------------ */
  global.IMusicNativeHost = {
    onTracks(p) { Library.nativeIngest(parse(p)); },
    onScanEnd(p) { Library.nativeDone(p ? parse(p) : {}); },
    onFolderPicked() { Library.rescan({ request: true }); },
    onPermission(granted) { if (granted) Library.rescan({ request: true }); else Library.checkPermissions(); },
    onPlayer(e) { try { Player.nativeEvent(parse(e)); } catch (err) { console.error('[native] player', err); } },
    onVolume(v) { Player.nativeVolume(Number(v)); },
    onCoverPicked(key, id) { if (typeof IMusic.onCoverPicked === 'function') IMusic.onCoverPicked(String(key), String(id || '')); },
  };

  /* ------------------ Cor das barras do sistema ------------------ */
  let lastTheme = "";
  function syncTheme() {
    try {
      const m = getComputedStyle(document.body).backgroundColor.match(/\d+/g);
      if (!m || m.length < 3) return;
      const hex = '#' + m.slice(0, 3).map((n) => Number(n).toString(16).padStart(2, '0')).join('');
      if (hex === lastTheme) return;
      lastTheme = hex;
      call('setTheme', hex);
    } catch (_) { /* ignora */ }
  }
  const mo = new MutationObserver(syncTheme);
  mo.observe(document.documentElement, { attributes: true });
  document.addEventListener('DOMContentLoaded', () => { mo.observe(document.body, { attributes: true }); syncTheme(); });
  global.addEventListener('load', syncTheme);

  /* Sem seleção de texto nem menu de contexto (exceto nos campos de escrita) */
  const isField = (el) => !!(el && el.closest && el.closest('input, textarea, [contenteditable="true"]'));
  document.addEventListener('contextmenu', (e) => { if (!isField(e.target)) e.preventDefault(); });
  document.addEventListener('selectstart', (e) => { if (!isField(e.target)) e.preventDefault(); });

  /** Vibração curta ao mudar de nível no controlo de volume. */
  IMusic.Native = { available: true, tick: () => call('tick') };
})(window);
