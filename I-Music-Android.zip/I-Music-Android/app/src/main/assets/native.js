/**
 * I-Music · native.js
 * Ponte com o app Android nativo (window.AndroidNative). Fora do app nativo não faz nada.
 *  - recebe da camada nativa as músicas, a pasta escolhida e a permissão;
 *  - recebe os botões da notificação / ecrã bloqueado / auscultadores (play, pausa, seguinte, anterior, seek);
 *  - envia à camada nativa a música atual e o estado para a notificação com controlo no ecrã bloqueado.
 */
(function (global) {
  'use strict';
  const IMusic = (global.IMusic = global.IMusic || {});
  const N = global.AndroidNative;
  if (!N) { IMusic.Native = { available: false }; return; }

  const Player = IMusic.Player, Library = IMusic.Library;
  const call = (fn, arg) => { try { return arg === undefined ? N[fn]() : N[fn](arg); } catch (_) { return null; } };
  const parse = (v) => (typeof v === 'string' ? JSON.parse(v) : v);

  /* ------------------------ Nativo → página ------------------------ */
  global.IMusicNativeHost = {
    onTracks(p) { Library.nativeIngest(parse(p)); },
    onScanEnd(p) { Library.nativeDone(p ? parse(p) : {}); },
    onFolderPicked() { Library.rescan({ request: true }); },
    onPermission(granted) { if (granted) Library.rescan({ request: true }); else Library.checkPermissions(); },
    onAction(action, arg) {
      switch (action) {
        case 'play': Player.play(); break;
        case 'pause': Player.pause(); break;
        case 'toggle': Player.toggle(); break;
        case 'next': Player.next(); break;
        case 'prev': Player.prev(); break;
        case 'seek': Player.seek((Number(arg) || 0) / 1000); break;
        case 'stop': Player.pause(); break;
        default: break;
      }
    },
  };

  /* ------------------------ Página → nativo ------------------------ */
  let lastKey = '', lastPos = 0, lastAt = 0, lastPlaying = false;

  function push(force) {
    const st = Player.getState(), tr = st.current;
    if (!tr) { if (lastKey) call('clearSession'); lastKey = ''; return; }
    const tm = Player.getTime();
    const dur = Math.round((tm.duration || tr.dur || 0) * 1000);
    const key = `${tr.id}|${st.playing ? 1 : 0}|${dur}`;
    if (!force && key === lastKey) return;
    lastKey = key; lastPos = tm.current || 0; lastAt = Date.now(); lastPlaying = !!st.playing;
    call('updateSession', JSON.stringify({
      id: String(tr.id), title: tr.title || '', artist: tr.artistName || tr.artist || '',
      album: tr.albumName || tr.album || '', cover: tr.cover ? String(tr.cover).replace(/^n:/, '') : '',
      playing: !!st.playing, pos: Math.round(lastPos * 1000), dur,
    }));
  }

  Player.on('trackchange', () => push(true));
  Player.on('state', () => push(false));
  Player.on('time', () => {
    const st = Player.getState();
    if (!st.current) return;
    const tm = Player.getTime();
    const expected = lastPos + (lastPlaying ? (Date.now() - lastAt) / 1000 : 0);
    if (Math.abs((tm.current || 0) - expected) > 1.5 || Math.round((tm.duration || 0) * 1000) !== Number(lastKey.split('|')[2])) push(true);
  });

  /* ------------------ Cor das barras do sistema ------------------ */
  let lastTheme = "";
  function syncTheme() {
    try {
      const m = getComputedStyle(document.body).backgroundColor.match(/\d+/g);
      if (!m || m.length < 3) return;
      const hex = '#' + m.slice(0, 3).map((n) => Number(n).toString(16).padStart(2, '0')).join('');
      if (hex === lastTheme) return;
      lastTheme = hex;
      call('setTheme', hex);
    } catch (_) { /* ignora */ }
  }
  const mo = new MutationObserver(syncTheme);
  mo.observe(document.documentElement, { attributes: true });
  document.addEventListener('DOMContentLoaded', () => { mo.observe(document.body, { attributes: true }); syncTheme(); });
  global.addEventListener('load', syncTheme);

  IMusic.Native = { available: true, pushSession: push };
})(window);
