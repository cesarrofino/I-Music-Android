/**
 * I-Music · app.js
 * Interface: navegação sem recarregar, telas, componentes visuais e a ligação
 * entre Library (músicas locais), Player (áudio) e Storage (favoritos/playlists).
 *
 * Organização deste arquivo:
 *   1 Configuração da interface     5 Componentes (capa, linha, card, avisos)
 *   2 Utilitários e ícones          6 Telas (início, busca, favoritos...)
 *   3 Estado e roteador             7 Player (fixo, expandido, fila)
 *   4 Ações de reprodução           8 Inicialização
 */
(function () {
  'use strict';

  const { Library, Storage, Player } = window.IMusic;

  /* ==========================================================================
     1. Configuração da interface
     ========================================================================== */

  const UI = {
    routes: ['home', 'search', 'songs', 'collection', 'favorites', 'recent', 'library', 'playlist'],
    cardsPerRow: 20,
    searchDebounceMs: 160,
    appVersion: '1.0.0',
  };

  /* ==========================================================================
     2. Utilitários e ícones
     ========================================================================== */

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  /** Cria elementos DOM sem usar innerHTML com texto de terceiros (evita XSS) */
  function h(tag, props, ...children) {
    const el = document.createElement(tag);
    Object.entries(props || {}).forEach(([key, value]) => {
      if (value === null || value === undefined || value === false) return;
      if (key === 'class') el.className = value;
      else if (key === 'dataset') Object.assign(el.dataset, value);
      else if (key === 'html') el.innerHTML = value;
      else if (key.startsWith('on') && typeof value === 'function') el.addEventListener(key.slice(2).toLowerCase(), value);
      else el.setAttribute(key, value === true ? '' : value);
    });
    children.flat().forEach((child) => {
      if (child === null || child === undefined || child === false) return;
      el.append(child.nodeType ? child : document.createTextNode(String(child)));
    });
    return el;
  }

  // Ícones no estilo Lucide (traço 2px), embutidos no código
  const ICONS = {
    home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    heart: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    library: '<path d="m16 6 4 14"/><path d="M12 6v14"/><path d="M8 8v12"/><path d="M4 4v16"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    play: '<polygon points="6 3 20 12 6 21 6 3"/>',
    pause: '<rect x="14" y="4" width="4" height="16" rx="1"/><rect x="6" y="4" width="4" height="16" rx="1"/>',
    prev: '<polygon points="19 20 9 12 19 4 19 20"/><line x1="5" x2="5" y1="19" y2="5"/>',
    next: '<polygon points="5 4 15 12 5 20 5 4"/><line x1="19" x2="19" y1="5" y2="19"/>',
    shuffle: '<path d="M2 18h1.4c1.3 0 2.5-.6 3.3-1.7l6.1-8.6c.7-1.1 2-1.7 3.3-1.7H22"/><path d="m18 2 4 4-4 4"/><path d="M2 6h1.9c1.5 0 2.9.9 3.6 2.2"/><path d="M22 18h-5.9c-1.3 0-2.6-.7-3.3-1.8l-.5-.8"/><path d="m18 14 4 4-4 4"/>',
    repeat: '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
    repeat1: '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/><path d="M11 10h1v4"/>',
    volume2: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>',
    volume1: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>',
    volumeX: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="22" x2="16" y1="9" y2="15"/><line x1="16" x2="22" y1="9" y2="15"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    chevronUp: '<path d="m18 15-6-6-6 6"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    queue: '<path d="M21 15V6"/><path d="M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"/><path d="M12 12H3"/><path d="M16 6H3"/><path d="M12 18H3"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    alert: '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
    wifiOff: '<path d="M12 20h.01"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/><path d="M5 12.859a10 10 0 0 1 5.17-2.69"/><path d="M19 12.859a10 10 0 0 0-2.007-1.523"/><path d="M2 8.82a15 15 0 0 1 4.177-2.643"/><path d="M22 8.82a15 15 0 0 0-11.288-3.764"/><path d="m2 2 20 20"/>',
    compass: '<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>',
    trendUp: '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
    moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" x2="15.4" y1="10.5" y2="6.5"/><line x1="8.6" x2="15.4" y1="13.5" y2="17.5"/>',
    rotateLeft: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 3v5h5"/>',
    image: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
    disc: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>',
    more: '<circle cx="12" cy="5" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="19" r="1.6" fill="currentColor" stroke="none"/>',
    sliders: '<line x1="4" x2="4" y1="21" y2="14"/><line x1="4" x2="4" y1="10" y2="3"/><line x1="12" x2="12" y1="21" y2="12"/><line x1="12" x2="12" y1="8" y2="3"/><line x1="20" x2="20" y1="21" y2="16"/><line x1="20" x2="20" y1="12" y2="3"/><line x1="2" x2="6" y1="14" y2="14"/><line x1="10" x2="14" y1="8" y2="8"/><line x1="18" x2="22" y1="16" y2="16"/>',
    data: '<path d="M3 20h.01"/><path d="M7 20v-3"/><path d="M11 20v-7"/><path d="M15 20V9"/><path d="M19 20V4"/>',
    listPlus: '<path d="M11 12H3"/><path d="M16 6H3"/><path d="M16 18H3"/><path d="M18 9v6"/><path d="M21 12h-6"/>',
    edit: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
    folder: '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
    sort: '<path d="m3 16 4 4 4-4"/><path d="M7 20V4"/><path d="M11 4h10"/><path d="M11 8h7"/><path d="M11 12h4"/>',
  };

  function icon(name, cls) {
    return `<svg class="i ${cls || ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICONS[name] || ''}</svg>`;
  }

  const iconEl = (name, cls) => h('span', { class: 'ico', html: icon(name, cls) });

  /** Preenche os <span data-icon="..."> escritos no HTML */
  function hydrateIcons(root = document) {
    $$('[data-icon]', root).forEach((node) => { node.innerHTML = icon(node.dataset.icon, node.dataset.iconClass); });
  }

  /* ==========================================================================
     2b. Internacionalização (idioma da interface: pt / en)
     ========================================================================== */

  const STRINGS = {
    pt: {
      'nav.home': 'Início', 'nav.search': 'Pesquisar', 'nav.songs': 'Músicas', 'nav.favorites': 'Favoritos',
      'nav.recent': 'Recentes', 'nav.library': 'Biblioteca', 'nav.settings': 'Configurações',
      'search.placeholder': 'Buscar músicas, artistas ou álbuns',
      'search.recentSearches': 'Pesquisas recentes', 'search.explore': 'Na sua biblioteca',
      'home.recent': 'Ouvidas recentemente', 'home.added': 'Adicionadas recentemente', 'home.albums': 'Álbuns',
      'hero.continue': 'Continuar a ouvir', 'hero.featured': 'Para ouvir agora', 'action.playNow': 'Tocar agora',
      'action.seeAll': 'Ver tudo', 'action.playAll': 'Tocar tudo', 'action.sort': 'Ordenar',
      'action.shuffle': 'Aleatório', 'action.clearHistory': 'Limpar histórico', 'action.tryAgain': 'Tentar novamente',
      'favorites.title': 'Meus favoritos', 'library.title': 'Sua biblioteca',
      'library.subtitle': 'Tudo o que você guardou neste dispositivo.',
      'library.queueTitle': 'Fila de reprodução', 'library.clearQueue': 'Limpar fila', 'library.inQueue': 'Na fila',
      'songs.tracks': 'Músicas', 'songs.albums': 'Álbuns', 'songs.artists': 'Artistas', 'songs.folders': 'Pastas',
      'sort.title': 'Título', 'sort.artist': 'Artista', 'sort.album': 'Álbum', 'sort.duration': 'Duração', 'sort.added': 'Data de adição',
      'sort.asc': 'Ordem crescente', 'sort.desc': 'Ordem decrescente', 'sort.by': 'Ordenar por',
      'lib.empty.title': 'A sua biblioteca está vazia', 'lib.empty.text': 'Escolha a pasta onde estão as suas músicas. O I-Music guarda o acesso e lê a pasta sozinho sempre que abre.',
      'lib.pickFolder': 'Escolher pasta de músicas', 'lib.pickFiles': 'Adicionar ficheiros',
      'lib.noPicker': 'Este navegador não deixa guardar acesso a pastas. Escolha os ficheiros: uma cópia fica guardada no app.',
      'lib.permTitle': 'Reative o acesso às suas músicas', 'lib.permText': 'O navegador pediu para confirmar o acesso à pasta de músicas.',
      'lib.permAction': 'Ativar acesso', 'lib.permBanner': 'Acesso à pasta desligado. Toque para reativar.',
      'lib.scanning': 'A ler as suas músicas… {done}/{total} · {found} encontradas', 'lib.collecting': 'A procurar músicas nas pastas…',
      'lib.scanDone': '{n} músicas na biblioteca', 'lib.added': '{n} novas', 'lib.removed': '{n} removidas', 'lib.updated': '{n} atualizadas',
      'lib.noChanges': 'Biblioteca atualizada, sem alterações', 'lib.noneFound': 'Nenhuma música encontrada nesta pasta.',
      'lib.error': 'Não foi possível ler a pasta. Tente escolher outra.', 'lib.rootMissing': 'A pasta "{name}" já não existe.',
      'lib.filesDone': '{n} adicionadas', 'lib.filesDup': '{n} já existiam', 'lib.filesBad': '{n} ilegíveis', 'lib.full': 'Sem espaço no armazenamento do app.',
      'lib.cancel': 'Cancelar', 'lib.removed1': 'Removida da biblioteca', 'lib.remove': 'Remover da biblioteca',
      'lib.removeConfirm': 'Remover "{title}" da biblioteca? O ficheiro não é apagado do telemóvel.',
      'lib.gotoAlbum': 'Ir para o álbum', 'lib.gotoArtist': 'Ir para o artista',
      'cover.change': 'Mudar capa', 'cover.remove': 'Remover capa personalizada', 'cover.done': 'Capa atualizada.', 'cover.error': 'Não foi possível usar essa imagem.',
      'share.action': 'Partilhar', 'share.file': 'Partilhar ficheiro', 'action.pause': 'Pausar', 'share.nothing': 'Nada para partilhar.', 'share.err': 'Não foi possível partilhar.',

      'lib.oneTrack': '1 música', 'lib.folderCount': '{n} pastas ligadas', 'lib.folderOne': '1 pasta ligada', 'lib.noFolder': 'Nenhuma pasta ligada',
      'lib.cleared': 'Biblioteca esvaziada', 'lib.clearConfirm': 'Esvaziar a biblioteca? Remove a lista e as cópias guardadas no app. Não apaga nada do telemóvel.',
      'settings.title': 'Configurações', 'settings.close': 'Fechar configurações',
      'settings.preferences': 'Preferências', 'settings.theme': 'Tema', 'settings.themeHint': 'Escolha a aparência do aplicativo',
      'settings.darkTheme': 'Tema escuro', 'settings.language': 'Idioma', 'settings.languageHint': 'Idioma da interface do aplicativo',
      'settings.library': 'Biblioteca de músicas', 'settings.addFolder': 'Escolher pasta de músicas',
      'settings.addFolderHint': 'O app lê a pasta sozinho sempre que abre e acompanha músicas novas ou apagadas.',
      'settings.addFiles': 'Adicionar ficheiros de áudio', 'settings.addFilesHint': 'Escolha ficheiros ou uma pasta. Fica guardada uma cópia dentro do app.',
      'settings.rescan': 'Atualizar biblioteca', 'settings.rescanHint': 'Procura músicas novas e remove as apagadas.',
      'settings.hideShort': 'Ocultar áudios curtos', 'settings.hideShortHint': 'Esconde ficheiros com menos de 30 segundos (notas de voz, toques).',
      'settings.clearLibrary': 'Esvaziar biblioteca', 'settings.clearLibraryHint': 'Remove a lista e as cópias guardadas no app. Não apaga nada do telemóvel.',
      'settings.audio': 'Reprodução', 'settings.resume': 'Retomar ao abrir', 'settings.resumeHint': 'Volta à última música e à posição onde parou.',
      'settings.storage': 'Armazenamento do app', 'settings.storageUsed': 'Usado {used} de {quota} disponíveis', 'settings.storageNA': 'Indisponível neste navegador',
      'settings.data': 'Dados neste dispositivo', 'settings.history': 'Histórico', 'settings.historyHint': 'Limpar as músicas ouvidas recentemente',
      'settings.favorites': 'Favoritos', 'settings.favoritesHint': 'Apagar todas as músicas favoritas', 'settings.clear': 'Limpar',
      'settings.more': 'Mais', 'settings.off': 'Desligado',
      'settings.sleepTimer': 'Temporizador para pausar', 'settings.sleepTimerHint': 'Pausa a música automaticamente',
      'settings.sleepTimerSet': 'Vai pausar em {min} min', 'settings.sleepTimerCancelled': 'Temporizador cancelado',
      'settings.reset': 'Restaurar predefinições', 'settings.resetHint': 'Volta o tema, idioma e temporizador ao padrão', 'settings.resetAction': 'Restaurar',
      'settings.resetDone': 'Configurações restauradas',
      'settings.about': 'Sobre', 'settings.version': 'Versão', 'settings.developer': 'Desenvolvedor',
      'settings.equalizer': 'Equalizador', 'settings.equalizerHint': 'Ajuste os graves, médios e agudos ou escolha um predefinido',
      'eq.flat': 'Padrão', 'eq.bass': 'Grave reforçado', 'eq.treble': 'Agudo reforçado', 'eq.vocal': 'Voz em destaque',
      'eq.rock': 'Rock', 'eq.pop': 'Pop', 'eq.loudness': 'Impacto', 'eq.custom': 'Personalizado',
      'eq.bassLabel': 'Graves', 'eq.midLabel': 'Médios', 'eq.trebleLabel': 'Agudos',
      'eq.unavailable': 'O equalizador não funciona dentro deste navegador embutido (ex.: Messenger, Instagram, TikTok). Abra o I-Music no Chrome ou Safari para usá-lo.',
      'library.playlists': 'Playlists', 'library.newPlaylist': 'Nova playlist', 'library.noPlaylists': 'Você ainda não criou nenhuma playlist.',
      'playlist.namePrompt': 'Nome da playlist', 'playlist.namePlaceholder': 'Ex.: Treino, Foco, Road trip…',
      'playlist.create': 'Criar', 'playlist.cancel': 'Cancelar', 'playlist.created': 'Playlist "{name}" criada',
      'playlist.addTo': 'Adicionar à playlist', 'playlist.addedTo': 'Adicionada à "{name}"', 'playlist.alreadyIn': 'Essa música já está na "{name}"',
      'playlist.emptyState': 'Nenhuma música nesta playlist ainda.', 'playlist.delete': 'Excluir playlist',
      'playlist.deleteConfirm': 'Excluir a playlist "{name}"? Essa ação não pode ser desfeita.', 'playlist.deleted': 'Playlist excluída',
      'playlist.rename': 'Renomear', 'playlist.removeFrom': 'Remover da playlist', 'playlist.oneTrack': '1 música',
      'playlist.createNew': '+ Criar nova playlist', 'playlist.moveUp': 'Mover para cima', 'playlist.moveDown': 'Mover para baixo',
      'playlist.addAll': 'Adicionar tudo a uma playlist',
      'ob.welcomeTitle': 'Bem-vindo ao I-Music', 'ob.welcomeText': 'A sua música, no seu telemóvel. Biblioteca automática, playlists, favoritos e fila.',
      'ob.nameTitle': 'Como podemos te chamar?', 'ob.nameText': 'Usamos seu nome só para personalizar sua experiência neste dispositivo.',
      'ob.nameLabel': 'Seu nome', 'ob.namePlaceholder': 'Digite seu nome',
      'ob.libTitle': 'Onde estão as suas músicas?', 'ob.libText': 'Escolha a pasta de músicas do telemóvel. O I-Music guarda o acesso, lê a pasta sozinho sempre que abre.',
      'ob.pickFolder': 'Escolher pasta de músicas', 'ob.pickFiles': 'Escolher ficheiros', 'ob.libHint': 'Pode fazer isto mais tarde em Configurações.',
      'ob.libFound': '{n} músicas encontradas. Tudo pronto!',
      'ob.continue': 'Continuar', 'ob.proceed': 'Entrar',
      'greet.dawn': 'Boa madrugada', 'greet.morning': 'Bom dia', 'greet.afternoon': 'Boa tarde', 'greet.night': 'Boa noite',
      'player.nothing': 'Nada tocando', 'player.choose': 'Escolha uma música',
      'toast.chooseTrack': 'Escolha uma música para começar.',
      'toast.addedQueue': 'Adicionar à fila', 'toast.queued': 'Adicionada à fila', 'toast.alreadyQueue': 'Essa música já está na fila',
      'toast.noPlayable': 'Nenhuma música disponível para tocar.',
      'toast.historyCleared': 'Histórico limpo', 'toast.favoritesCleared': 'Favoritos apagados',
      'toast.confirmClearFavs': 'Apagar todos os favoritos? Essa ação não pode ser desfeita.',
      'toast.pressPlay': 'Toque em play para iniciar a reprodução.', 'toast.unavailable': 'Este ficheiro já não está disponível.',
      'empty.favTitle': 'Você ainda não tem favoritos', 'empty.favText': 'Toque no coração de uma música para guardá-la aqui. Seus favoritos ficam salvos neste dispositivo.',
      'empty.goSongs': 'Ver as minhas músicas',
      'empty.recentTitle': 'Nada ouvido ainda', 'empty.recentText': 'As músicas que você tocar aparecem aqui, da mais recente para a mais antiga.',
      'empty.queueTitle': 'Sua fila está vazia', 'empty.queueText': 'Toque em uma música ou use o menu ⋮ para adicionar faixas à fila.',
      'search.noResults': 'Nada encontrado para "{q}"', 'search.noResultsHint': 'Confira a grafia ou tente buscar por outro artista, música ou álbum.',
      'search.resultsFor': 'Resultados para "{q}"', 'search.oneResult': '1 música encontrada', 'search.nResults': '{n} músicas encontradas',
      'search.idle': 'Pesquise por título, artista ou álbum.',
      'stat.oneTrack': '1 música', 'stat.nTracks': '{n} músicas',
      'favorites.empty': 'Nada por aqui ainda', 'recent.empty': 'Seu histórico está vazio',
      'err.trackMissing': '"{title}" já não está no armazenamento.', 'err.permission': 'Sem acesso à pasta de músicas. Ative-o nas Configurações.',
      'err.trackFailed': 'Não foi possível reproduzir "{title}".', 'err.skipping': 'Pulando para a próxima.',
      'err.storage': 'O navegador bloqueou o armazenamento local (modo privado?). O I-Music precisa dele para guardar a biblioteca.',
    },
    en: {
      'nav.home': 'Home', 'nav.search': 'Search', 'nav.songs': 'Songs', 'nav.favorites': 'Favorites',
      'nav.recent': 'Recent', 'nav.library': 'Library', 'nav.settings': 'Settings',
      'search.placeholder': 'Search songs, artists or albums',
      'search.recentSearches': 'Recent searches', 'search.explore': 'In your library',
      'home.recent': 'Recently played', 'home.added': 'Recently added', 'home.albums': 'Albums',
      'hero.continue': 'Continue listening', 'hero.featured': 'Listen now', 'action.playNow': 'Play now',
      'action.seeAll': 'See all', 'action.playAll': 'Play all', 'action.sort': 'Sort',
      'action.shuffle': 'Shuffle', 'action.clearHistory': 'Clear history', 'action.tryAgain': 'Try again',
      'favorites.title': 'My favorites', 'library.title': 'Your library',
      'library.subtitle': 'Everything you saved on this device.',
      'library.queueTitle': 'Play queue', 'library.clearQueue': 'Clear queue', 'library.inQueue': 'In queue',
      'songs.tracks': 'Songs', 'songs.albums': 'Albums', 'songs.artists': 'Artists', 'songs.folders': 'Folders',
      'sort.title': 'Title', 'sort.artist': 'Artist', 'sort.album': 'Album', 'sort.duration': 'Duration', 'sort.added': 'Date added',
      'sort.asc': 'Ascending order', 'sort.desc': 'Descending order', 'sort.by': 'Sort by',
      'lib.empty.title': 'Your library is empty', 'lib.empty.text': 'Choose the folder where your music is. I-Music keeps the access and reads the folder on its own every time it opens.',
      'lib.pickFolder': 'Choose music folder', 'lib.pickFiles': 'Add files',
      'lib.noPicker': "This browser can't keep folder access. Choose the files: a copy is stored inside the app.",
      'lib.permTitle': 'Re-enable access to your music', 'lib.permText': 'The browser asked to confirm access to your music folder.',
      'lib.permAction': 'Enable access', 'lib.permBanner': 'Folder access is off. Tap to re-enable.',
      'lib.scanning': 'Reading your music… {done}/{total} · {found} found', 'lib.collecting': 'Looking for music in your folders…',
      'lib.scanDone': '{n} songs in your library', 'lib.added': '{n} new', 'lib.removed': '{n} removed', 'lib.updated': '{n} updated',
      'lib.noChanges': 'Library up to date, no changes', 'lib.noneFound': 'No music found in this folder.',
      'lib.error': "Couldn't read the folder. Try another one.", 'lib.rootMissing': 'The folder "{name}" no longer exists.',
      'lib.filesDone': '{n} added', 'lib.filesDup': '{n} already there', 'lib.filesBad': '{n} unreadable', 'lib.full': 'Not enough app storage space.',
      'lib.cancel': 'Cancel', 'lib.removed1': 'Removed from library', 'lib.remove': 'Remove from library',
      'lib.removeConfirm': 'Remove "{title}" from the library? The file is not deleted from your phone.',
      'lib.gotoAlbum': 'Go to album', 'lib.gotoArtist': 'Go to artist',
      'cover.change': 'Change cover', 'cover.remove': 'Remove custom cover', 'cover.done': 'Cover updated.', 'cover.error': 'Could not use that image.',
      'share.action': 'Share', 'share.file': 'Share file', 'action.pause': 'Pause', 'share.nothing': 'Nothing to share.', 'share.err': 'Could not share.',

      'lib.oneTrack': '1 song', 'lib.folderCount': '{n} linked folders', 'lib.folderOne': '1 linked folder', 'lib.noFolder': 'No linked folder',
      'lib.cleared': 'Library cleared', 'lib.clearConfirm': 'Clear the library? This removes the list and the copies stored in the app. Nothing is deleted from your phone.',
      'settings.title': 'Settings', 'settings.close': 'Close settings',
      'settings.preferences': 'Preferences', 'settings.theme': 'Theme', 'settings.themeHint': 'Choose the app appearance',
      'settings.darkTheme': 'Dark theme', 'settings.language': 'Language', 'settings.languageHint': 'Interface language',
      'settings.library': 'Music library', 'settings.addFolder': 'Choose music folder',
      'settings.addFolderHint': 'The app reads the folder by itself every time it opens and follows new or deleted songs.',
      'settings.addFiles': 'Add audio files', 'settings.addFilesHint': 'Pick files or a folder. A copy is stored inside the app.',
      'settings.rescan': 'Refresh library', 'settings.rescanHint': 'Looks for new songs and removes deleted ones.',
      'settings.hideShort': 'Hide short audio', 'settings.hideShortHint': 'Hides files shorter than 30 seconds (voice notes, ringtones).',
      'settings.clearLibrary': 'Clear library', 'settings.clearLibraryHint': 'Removes the list and the copies stored in the app. Nothing is deleted from your phone.',
      'settings.audio': 'Playback', 'settings.resume': 'Resume on open', 'settings.resumeHint': 'Goes back to the last song and position.',
      'settings.storage': 'App storage', 'settings.storageUsed': 'Using {used} of {quota} available', 'settings.storageNA': 'Not available in this browser',
      'settings.data': 'Data on this device', 'settings.history': 'History', 'settings.historyHint': 'Clear your recently played tracks',
      'settings.favorites': 'Favorites', 'settings.favoritesHint': 'Remove every favorited track', 'settings.clear': 'Clear',
      'settings.more': 'More', 'settings.off': 'Off',
      'settings.sleepTimer': 'Sleep timer', 'settings.sleepTimerHint': 'Pause playback automatically',
      'settings.sleepTimerSet': 'Will pause in {min} min', 'settings.sleepTimerCancelled': 'Sleep timer cancelled',
      'settings.reset': 'Restore defaults', 'settings.resetHint': 'Resets theme, language and sleep timer', 'settings.resetAction': 'Restore',
      'settings.resetDone': 'Settings restored',
      'settings.about': 'About', 'settings.version': 'Version', 'settings.developer': 'Developer',
      'settings.equalizer': 'Equalizer', 'settings.equalizerHint': 'Adjust bass, mid and treble or pick a preset',
      'eq.flat': 'Default', 'eq.bass': 'Bass boost', 'eq.treble': 'Treble boost', 'eq.vocal': 'Vocal boost',
      'eq.rock': 'Rock', 'eq.pop': 'Pop', 'eq.loudness': 'Loudness', 'eq.custom': 'Custom',
      'eq.bassLabel': 'Bass', 'eq.midLabel': 'Mid', 'eq.trebleLabel': 'Treble',
      'eq.unavailable': "The equalizer doesn't work inside this in-app browser (e.g. Messenger, Instagram, TikTok). Open I-Music in Chrome or Safari to use it.",
      'library.playlists': 'Playlists', 'library.newPlaylist': 'New playlist', 'library.noPlaylists': "You haven't created any playlists yet.",
      'playlist.namePrompt': 'Playlist name', 'playlist.namePlaceholder': 'E.g. Workout, Focus, Road trip…',
      'playlist.create': 'Create', 'playlist.cancel': 'Cancel', 'playlist.created': '"{name}" created',
      'playlist.addTo': 'Add to playlist', 'playlist.addedTo': 'Added to "{name}"', 'playlist.alreadyIn': 'This song is already in "{name}"',
      'playlist.emptyState': 'No songs in this playlist yet.', 'playlist.delete': 'Delete playlist',
      'playlist.deleteConfirm': 'Delete the playlist "{name}"? This action cannot be undone.', 'playlist.deleted': 'Playlist deleted',
      'playlist.rename': 'Rename', 'playlist.removeFrom': 'Remove from playlist', 'playlist.oneTrack': '1 song',
      'playlist.createNew': '+ Create new playlist', 'playlist.moveUp': 'Move up', 'playlist.moveDown': 'Move down',
      'playlist.addAll': 'Add all to a playlist',
      'ob.welcomeTitle': 'Welcome to I-Music', 'ob.welcomeText': 'Your music, on your phone. Automatic library, playlists, favorites and queue.',
      'ob.nameTitle': 'What should we call you?', 'ob.nameText': 'We only use your name to personalize your experience on this device.',
      'ob.nameLabel': 'Your name', 'ob.namePlaceholder': 'Enter your name',
      'ob.libTitle': 'Where is your music?', 'ob.libText': 'Choose the music folder on your phone. I-Music keeps the access, reads the folder on its own every time it opens.',
      'ob.pickFolder': 'Choose music folder', 'ob.pickFiles': 'Choose files', 'ob.libHint': 'You can do this later in Settings.',
      'ob.libFound': '{n} songs found. All set!',
      'ob.continue': 'Continue', 'ob.proceed': 'Enter',
      'greet.dawn': 'Good night', 'greet.morning': 'Good morning', 'greet.afternoon': 'Good afternoon', 'greet.night': 'Good evening',
      'player.nothing': 'Nothing playing', 'player.choose': 'Choose a song',
      'toast.chooseTrack': 'Choose a song to get started.',
      'toast.addedQueue': 'Add to queue', 'toast.queued': 'Added to queue', 'toast.alreadyQueue': 'This song is already in the queue',
      'toast.noPlayable': 'No songs available to play.',
      'toast.historyCleared': 'History cleared', 'toast.favoritesCleared': 'Favorites cleared',
      'toast.confirmClearFavs': 'Remove all favorites? This action cannot be undone.',
      'toast.pressPlay': 'Tap play to start playback.', 'toast.unavailable': 'This file is no longer available.',
      'empty.favTitle': "You don't have any favorites yet", 'empty.favText': 'Tap the heart on a song to save it here. Your favorites stay on this device.',
      'empty.goSongs': 'See my songs',
      'empty.recentTitle': 'Nothing played yet', 'empty.recentText': 'Songs you play show up here, most recent first.',
      'empty.queueTitle': 'Your queue is empty', 'empty.queueText': 'Tap a song or use the ⋮ menu to add tracks to the queue.',
      'search.noResults': 'Nothing found for "{q}"', 'search.noResultsHint': 'Check the spelling or try another artist, song or album.',
      'search.resultsFor': 'Results for "{q}"', 'search.oneResult': '1 song found', 'search.nResults': '{n} songs found',
      'search.idle': 'Search by title, artist or album.',
      'stat.oneTrack': '1 song', 'stat.nTracks': '{n} songs',
      'favorites.empty': 'Nothing here yet', 'recent.empty': 'Your history is empty',
      'err.trackMissing': '"{title}" is no longer in storage.', 'err.permission': 'No access to the music folder. Enable it in Settings.',
      'err.trackFailed': 'Could not play "{title}".', 'err.skipping': 'Skipping to the next one.',
      'err.storage': 'The browser blocked local storage (private mode?). I-Music needs it to keep your library.',
    },
  };

  // No app Android nativo a biblioteca vem do sistema: textos próprios
  if (window.AndroidNative) {
    Object.assign(STRINGS.pt, {
      'ob.pickFiles': 'Usar todas as músicas do telemóvel', 'lib.pickFiles': 'Usar todas as músicas do telemóvel',
      'ob.libText': 'Use todas as músicas do telemóvel ou escolha uma pasta. O I-Music acompanha as músicas novas e apagadas sozinho.',
      'lib.empty.text': 'Use todas as músicas do telemóvel ou escolha uma pasta específica.',
      'lib.permTitle': 'Permita o acesso às suas músicas', 'lib.permText': 'O I-Music precisa de permissão para ler os áudios do telemóvel.',
      'lib.permBanner': 'Sem permissão para ler as músicas. Toque para permitir.', 'lib.permAction': 'Permitir',
      'settings.addFolderHint': 'Escolha uma pasta do telemóvel. Só as músicas dessa pasta aparecem.',
      'settings.addFiles': 'Usar todas as músicas do telemóvel', 'settings.addFilesHint': 'Lê todas as músicas guardadas no telemóvel.',
    });
    if (STRINGS.en) Object.assign(STRINGS.en, {
      'ob.pickFiles': 'Use all music on this phone', 'lib.pickFiles': 'Use all music on this phone',
      'ob.libText': 'Use all the music on your phone or pick a folder. I-Music follows new and deleted songs on its own.',
      'lib.empty.text': 'Use all the music on your phone or pick a specific folder.',
      'lib.permTitle': 'Allow access to your music', 'lib.permText': 'I-Music needs permission to read the audio files on your phone.',
      'lib.permBanner': 'No permission to read your music. Tap to allow.', 'lib.permAction': 'Allow',
      'settings.addFolderHint': 'Pick a folder on your phone. Only songs in that folder are shown.',
      'settings.addFiles': 'Use all music on this phone', 'settings.addFilesHint': 'Reads all the music stored on your phone.',
    });
  }

  function currentLang() {
    const lang = Storage.getSettings().lang;
    return STRINGS[lang] ? lang : 'pt';
  }

  function t(key, vars) {
    const dict = STRINGS[currentLang()] || STRINGS.pt;
    let text = dict[key] || STRINGS.pt[key] || key;
    if (vars) Object.keys(vars).forEach((k) => { text = text.replace(`{${k}}`, vars[k]); });
    return text;
  }

  /** Aplica o idioma atual a todo texto estático marcado com data-i18n(-placeholder/-aria) */
  function applyI18n(root = document) {
    $$('[data-i18n]', root).forEach((node) => { node.textContent = t(node.dataset.i18n); });
    $$('[data-i18n-placeholder]', root).forEach((node) => { node.placeholder = t(node.dataset.i18nPlaceholder); });
    $$('[data-i18n-aria]', root).forEach((node) => { node.setAttribute('aria-label', t(node.dataset.i18nAria)); });
    document.documentElement.lang = currentLang() === 'en' ? 'en' : 'pt-BR';
  }

  function formatTime(sec) {
    const total = Number.isFinite(sec) && sec > 0 ? Math.floor(sec) : 0;
    const hh = Math.floor(total / 3600);
    const mm = Math.floor((total % 3600) / 60);
    const ss = total % 60;
    const pad = (n) => String(n).padStart(2, '0');
    return hh ? `${hh}:${pad(mm)}:${pad(ss)}` : `${mm}:${pad(ss)}`;
  }

  function formatCount(n) {
    try { return new Intl.NumberFormat('pt-BR', { notation: 'compact', maximumFractionDigits: 1 }).format(n); }
    catch (_) { return String(n); }
  }

  const nz = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  function formatBytes(b) {
    if (!b) return '0 MB';
    return b > 1073741824 ? `${(b / 1073741824).toFixed(1)} GB` : `${Math.max(1, Math.round(b / 1048576))} MB`;
  }

  function debounce(fn, ms) {
    let timer;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
  }

  /** Reinicia uma animação CSS (remove a classe, força o reflow e recoloca) */
  function restartAnimation(el, cls) {
    if (!el) return;
    el.classList.remove(cls);
    void el.offsetWidth;
    el.classList.add(cls);
  }

  const pulse = (el) => restartAnimation(el, 'pulse');

  function greeting() {
    const hour = new Date().getHours();
    const key = hour < 5 ? 'greet.dawn' : hour < 12 ? 'greet.morning' : hour < 18 ? 'greet.afternoon' : 'greet.night';
    const name = (Storage.getProfile().name || '').trim();
    return name ? `${t(key)}, ${name}` : t(key);
  }

  /* ==========================================================================
     3. Estado e roteador (hash: #/home, #/search?q=...)
     ========================================================================== */

  const state = {
    route: '',
    drawerOpen: false,
    seeking: false,
    lastFocus: null,
    playlistId: '',
    songsTab: 'tracks',
    colType: '',
    colKey: '',
  };

  const search = { q: '', results: [] };
  const SONG_TABS = ['tracks', 'albums', 'artists', 'folders'];

  function parseHash() {
    const raw = location.hash.replace(/^#\/?/, '');
    const [path, qs = ''] = raw.split('?');
    return { name: UI.routes.includes(path) ? path : 'home', params: new URLSearchParams(qs) };
  }

  function navigate(name, params = {}, { replace = false } = {}) {
    const qs = new URLSearchParams(params).toString();
    const hash = `#/${name}${qs ? `?${qs}` : ''}`;
    if (location.hash === hash) { onRoute(); return; }
    if (replace) {
      try { history.replaceState(null, '', hash); } catch (_) { location.replace(hash); return; }
      onRoute();
    } else {
      location.hash = hash; // dispara 'hashchange' → onRoute
    }
  }

  function onRoute() {
    const { name, params } = parseHash();
    const changed = name !== state.route || name === 'collection';
    state.route = name;

    $$('.view').forEach((view) => { view.hidden = view.dataset.view !== name; });
    const navName = name === 'playlist' ? 'library' : name === 'collection' ? 'songs' : name;
    $$('[data-route]').forEach((link) => {
      const active = link.dataset.route === navName;
      link.classList.toggle('active', active);
      if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
    });
    if (changed) window.scrollTo({ top: 0 });

    switch (name) {
      case 'home': loadHome(); break;
      case 'search': enterSearch(params.get('q') || ''); break;
      case 'songs': state.songsTab = SONG_TABS.includes(params.get('tab')) ? params.get('tab') : state.songsTab; renderSongs(); break;
      case 'collection': renderCollection(params.get('type') || '', params.get('key') || ''); break;
      case 'favorites': renderFavorites(); break;
      case 'recent': renderRecent(); break;
      case 'library': renderLibrary(); break;
      case 'playlist': renderPlaylistDetail(params.get('id') || ''); break;
      default: break;
    }
  }

  /* ==========================================================================
     4. Ações de reprodução
     ========================================================================== */

  /** Toca uma música de uma lista; a lista inteira vira a fila */
  function playFromList(list, index) {
    const track = list[index];
    if (!track) return;
    if (!playable(track)) {
      toast(t('toast.unavailable'), { type: 'warn', icon: 'alert' });
      return;
    }
    const st = Player.getState();
    if (st.current && st.current.id === track.id) { Player.toggle(); return; }
    Player.setQueue(list, index);
  }

  function playAll(list, { shuffle = false } = {}) {
    const playable_ = list.filter(playable);
    if (!playable_.length) { toast(t('toast.noPlayable'), { type: 'warn', icon: 'alert' }); return; }
    if (shuffle) Player.setShuffle(true);
    Player.setQueue(playable_, shuffle ? Math.floor(Math.random() * playable_.length) : 0);
  }

  function addToQueue(track) {
    if (!playable(track)) {
      toast(t('toast.unavailable'), { type: 'warn', icon: 'alert' });
      return;
    }
    if (!Player.getState().current) { Player.setQueue([track], 0); queuedByUser.add(track.id); paintQueueButtons(); return; }
    const result = Player.addToQueue(track);
    queuedByUser.add(track.id);
    paintQueueButtons();
    toast(result === 'added' ? t('toast.queued') : t('toast.alreadyQueue'), { icon: 'queue' });
  }

  function toggleFavorite(track, button) {
    Storage.toggleFavorite(track);
    if (button) pulse(button);
  }

  /* ==========================================================================
     5. Componentes
     ========================================================================== */

  /* ---- Avisos (toasts) ---- */
  function toast(message, { type = 'info', icon: iconName = 'check', duration = 3200 } = {}) {
    const box = $('#toasts');
    const el = h('div', { class: `toast toast-${type}`, role: 'status' }, iconEl(iconName), h('span', {}, message));
    box.append(el);
    while (box.children.length > 3) box.firstElementChild.remove();
    setTimeout(() => {
      el.classList.add('leaving');
      setTimeout(() => el.remove(), 320);
    }, duration);
  }

  function stateBlock({ icon: iconName, title, text, actionLabel, actionIcon, onAction }) {
    return h('div', { class: 'state' },
      h('span', { class: 'state-icon' }, iconEl(iconName)),
      h('h3', {}, title),
      text ? h('p', {}, text) : null,
      actionLabel ? h('button', { class: 'btn', type: 'button', onclick: onAction }, actionIcon ? iconEl(actionIcon) : null, actionLabel) : null);
  }


  /* ---- Skeletons ---- */
  function skeletonRows(n) {
    return h('div', { class: 'track-list', 'aria-hidden': 'true' },
      Array.from({ length: n }, () => h('div', { class: 'row row-skeleton' },
        h('span', { class: 'cover cover-sm skeleton' }),
        h('span', { class: 'row-text', style: 'margin-left:14px' },
          h('span', { class: 'sk-line skeleton w60' }),
          h('span', { class: 'sk-line skeleton w35' })))));
  }

  function skeletonCards(n) {
    return Array.from({ length: n }, () => h('div', { class: 'card', 'aria-hidden': 'true' },
      h('span', { class: 'cover cover-card skeleton' }),
      h('div', { class: 'card-info' },
        h('span', { class: 'sk-line skeleton w80' }),
        h('span', { class: 'sk-line skeleton w35', style: 'margin-top:8px' }))));
  }

  /* ---- Capa ---- */
  function createCover(track, size, extraClass, hooks) {
    const img = h('img', { alt: '', decoding: 'async', draggable: 'false' });
    if (size !== 'large') img.loading = 'lazy';
    const wrap = h('span', { class: `cover ${extraClass || ''}`.trim() },
      h('span', { class: 'ph', 'aria-hidden': 'true' }, iconEl('music')), img);
    Library.loadCover(img, track, hooks || {});
    return wrap;
  }

  const eqBars = () => h('span', { class: 'eq', 'aria-hidden': 'true' }, h('i'), h('i'), h('i'));

  function markCurrent(el, id) {
    const cur = Player.getState().current;
    el.classList.toggle('is-current', !!cur && cur.id === id);
  }

  /* ---- Botões de favorito e fila ---- */
  function paintFav(btn) {
    const on = Storage.isFavorite(btn.dataset.favId || '');
    btn.classList.toggle('is-fav', on);
    btn.setAttribute('aria-pressed', String(on));
    btn.setAttribute('aria-label', on ? 'Remover dos favoritos' : 'Adicionar aos favoritos');
    btn.title = on ? 'Remover dos favoritos' : 'Adicionar aos favoritos';
  }

  function favButton(track, extraClass) {
    const btn = h('button', {
      class: `icon-btn fav-btn ${extraClass || ''}`.trim(), type: 'button', dataset: { favId: track.id },
      onclick: (e) => { e.stopPropagation(); toggleFavorite(track, btn); },
    }, iconEl('heart'));
    paintFav(btn);
    return btn;
  }

  /* Músicas que a pessoa adicionou à fila com o "+" (mostram um visto enquanto estiverem na fila) */
  const queuedByUser = new Set();

  function paintQueue(btn) {
    const id = btn.dataset.queueId || '';
    const on = queuedByUser.has(id);
    btn.classList.toggle('is-queued', on);
    btn.setAttribute('aria-pressed', String(on));
    btn.title = on ? t('library.inQueue') : 'Adicionar à fila';
    btn.replaceChildren(iconEl(on ? 'check' : 'plus'));
  }

  function paintQueueButtons() {
    const inQueue = new Set(Player.getState().queue.map((x) => x.id));
    queuedByUser.forEach((id) => { if (!inQueue.has(id)) queuedByUser.delete(id); });
    document.querySelectorAll('[data-queue-id]').forEach(paintQueue);
  }

  function queueAddButton(track, extraClass) {
    const btn = h('button', {
      class: `icon-btn ${extraClass || ''}`.trim(), type: 'button', dataset: { queueId: track.id },
      'aria-label': `Adicionar ${track.title} à fila`,
      onclick: (e) => { e.stopPropagation(); addToQueue(track); pulse(btn); },
    }, iconEl('plus'));
    paintQueue(btn);
    return btn;
  }

  /* ---- Menu de ações da música (fila / playlist) ---- */

  let activeSheet = null;

  function closeSheet() {
    if (!activeSheet) return;
    const { root } = activeSheet;
    root.classList.remove('open');
    root.setAttribute('aria-hidden', 'true');
    setTimeout(() => root.remove(), 320);
    activeSheet = null;
  }

  /** Monta a "casca" do painel (fila/menu/formulário): cabeçalho com título +
   *  fechar, e o conteúdo passado. Usado por openSheet (lista) e
   *  openPromptSheet (campo de texto). */
  function mountSheet(title, bodyNode) {
    closeSheet();
    const root = h('aside', { class: 'queue-drawer sheet', 'aria-hidden': 'false', 'aria-label': title },
      h('div', { class: 'qd-scrim', onclick: closeSheet }),
      h('div', { class: 'qd-panel', role: 'dialog', 'aria-modal': 'true' },
        h('header', { class: 'qd-head' },
          h('h2', {}, title),
          h('button', { class: 'icon-btn', type: 'button', 'aria-label': t('settings.close'), onclick: closeSheet }, iconEl('x'))),
        bodyNode));
    document.body.append(root);
    activeSheet = { root };
    requestAnimationFrame(() => root.classList.add('open'));
    return root;
  }

  /** Painel deslizante genérico (reaproveita o visual da fila de reprodução):
   *  título + lista de linhas clicáveis. Usado para o menu "mais ações" da
   *  música e para o seletor de playlist. */
  function openSheet(title, rows) {
    mountSheet(title, h('div', { class: 'qd-list sheet-list' }, ...rows));
  }

  /** Painel com um campo de texto + Cancelar/Confirmar — substitui os
   *  prompt()/confirm() nativos do navegador (sem estilo próprio) por algo
   *  consistente com o resto do app. Usado para nomear/renomear playlists. */
  function openPromptSheet(title, { value = '', placeholder = '', confirmLabel } = {}, onConfirm) {
    const input = h('input', { type: 'text', value, placeholder, maxlength: '80', 'aria-label': title });
    const confirm = () => {
      const clean = input.value.trim();
      if (!clean) { input.focus(); return; }
      closeSheet();
      onConfirm(clean);
    };
    const body = h('div', {},
      h('div', { class: 'sheet-field' }, input),
      h('div', { class: 'sheet-foot' },
        h('button', { class: 'btn', type: 'button', onclick: closeSheet }, t('playlist.cancel')),
        h('button', { class: 'btn primary', type: 'button', onclick: confirm }, confirmLabel || t('playlist.create'))));
    mountSheet(title, body);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); confirm(); } });
    requestAnimationFrame(() => { input.focus(); input.select(); });
  }

  /** Painel de confirmação (substitui confirm() nativo) — usado para ações
   *  destrutivas como excluir uma playlist. */
  function openConfirmSheet(title, message, { confirmLabel, danger = true } = {}, onConfirm) {
    const body = h('div', {},
      h('p', { class: 'sheet-message' }, message),
      h('div', { class: 'sheet-foot' },
        h('button', { class: 'btn', type: 'button', onclick: closeSheet }, t('playlist.cancel')),
        h('button', { class: `btn${danger ? ' danger' : ' primary'}`, type: 'button', onclick: () => { closeSheet(); onConfirm(); } }, confirmLabel)));
    mountSheet(title, body);
  }

  function sheetRow(iconName, label, onClick, extraClass) {
    return h('button', { class: `sp-row sheet-row ${extraClass || ''}`.trim(), type: 'button', onclick: onClick },
      h('span', { class: 'ico' }, iconEl(iconName)),
      h('span', { class: 'sp-row-text' }, h('strong', {}, label)));
  }

  function addTrackToPlaylistFlow(id, track) {
    const pl = Storage.getPlaylist(id);
    if (!pl) return;
    const result = Storage.addToPlaylist(id, track);
    toast(result === 'added' ? t('playlist.addedTo', { name: pl.name }) : t('playlist.alreadyIn', { name: pl.name }), { icon: result === 'added' ? 'check' : 'alert' });
  }

  /** Pede o nome pelo painel do app (aceita qualquer nome). Se `track` for
   *  informado, a música já entra na playlist recém-criada. */
  function promptCreatePlaylist(track, onDone) {
    openPromptSheet(t('library.newPlaylist'), { placeholder: t('playlist.namePlaceholder'), confirmLabel: t('playlist.create') }, (clean) => {
      const pl = Storage.createPlaylist(clean, track ? [track] : []);
      if (!pl) return;
      toast(t('playlist.created', { name: pl.name }), { icon: 'check' });
      if (onDone) onDone(pl);
    });
  }

  function openPlaylistPicker(track) {
    const playlists = Storage.getPlaylists();
    const rows = playlists.map((pl) => sheetRow('library', `${pl.name} · ${pl.tracks.length ? plural(pl.tracks.length) : t('favorites.empty')}`, () => { addTrackToPlaylistFlow(pl.id, track); closeSheet(); }));
    rows.push(sheetRow('plus', t('playlist.createNew'), () => promptCreatePlaylist(track, () => { if (state.route === 'library') renderPlaylists(); })));
    openSheet(t('playlist.addTo'), rows);
  }

  function openTrackActionsSheet(track, { mode, playlistId } = {}) {
    const rows = [sheetRow('queue', t('toast.addedQueue'), () => { addToQueue(track); closeSheet(); })];
    rows.push(sheetRow('listPlus', t('playlist.addTo'), () => openPlaylistPicker(track)));
    rows.push(sheetRow('share', t('share.file'), () => { closeSheet(); shareTracks([track]); }));
    if (window.AndroidNative && track.src === 'native') {
      rows.push(sheetRow('image', t('cover.change'), () => { closeSheet(); changeCover([track]); }));
      if (track.ucover) rows.push(sheetRow('x', t('cover.remove'), () => { closeSheet(); resetCover([track]); }));
    }
    rows.push(sheetRow('disc', t('lib.gotoAlbum'), () => { closeSheet(); navigate('collection', { type: 'album', key: `${track.albumName}¦${track.albumArtist || ''}` }); }));
    rows.push(sheetRow('music', t('lib.gotoArtist'), () => { closeSheet(); navigate('collection', { type: 'artist', key: track.artistName }); }));
    if (mode === 'playlist' && playlistId) {
      rows.push(sheetRow('chevronUp', t('playlist.moveUp'), () => { Storage.moveInPlaylist(playlistId, track.id, -1); closeSheet(); }));
      rows.push(sheetRow('chevronDown', t('playlist.moveDown'), () => { Storage.moveInPlaylist(playlistId, track.id, 1); closeSheet(); }));
      rows.push(sheetRow('x', t('playlist.removeFrom'), () => {
        Storage.removeFromPlaylist(playlistId, track.id);
        closeSheet();
        if (state.route === 'playlist') renderPlaylistDetail(playlistId);
      }, 'danger'));
    }
    rows.push(sheetRow('trash', t('lib.remove'), () => {
      openConfirmSheet(t('lib.remove'), t('lib.removeConfirm', { title: track.title }), { confirmLabel: t('lib.remove') }, async () => {
        Player.dropTrack(track.id);
        await Library.hideTrack(track.id);
        toast(t('lib.removed1'), { icon: 'check' });
      });
    }, 'danger'));
    openSheet(track.title, rows);
  }

  /* ---- Capas personalizadas e partilha ---- */
  let coverReq = null;

  function changeCover(tracks) {
    const list = tracks.filter((x) => x.src === 'native');
    if (!window.AndroidNative || !list.length) return;
    coverReq = { key: `c${Date.now()}`, tracks: list };
    try { window.AndroidNative.pickCover(coverReq.key); } catch (_) { coverReq = null; }
  }

  async function applyCover(list, nativeId) {
    const pairs = await Library.setCustomCover(list, nativeId);
    try { window.AndroidNative.setCoverOverride(JSON.stringify(pairs)); } catch (_) { /* ok */ }
    repaintCurrentCover();
    if (state.route === 'collection') renderCollection(state.colType, state.colKey);
  }

  function resetCover(list) { applyCover(list, '').then(() => toast(t('cover.done'), { icon: 'check' })); }

  window.IMusic.onCoverPicked = (key, id) => {
    const req = coverReq;
    if (!req || req.key !== key) return;
    coverReq = null;
    if (!id) { if (id === '' && req) { /* cancelado ou falhou: sem aviso se cancelou */ } return; }
    applyCover(req.tracks, id).then(() => toast(t('cover.done'), { icon: 'check' }));
  };

  function repaintCurrentCover() {
    const tr = Player.getState().current;
    if (!tr) return;
    const backdrop = $('#fpBackdrop');
    Library.loadCover($('#miniCover'), tr);
    Library.loadCover($('#fpCover'), tr, {
      onLoad: (src) => { backdrop.style.backgroundImage = `url("${src}")`; backdrop.classList.add('on'); },
      onFail: () => backdrop.classList.remove('on'),
    });
  }

  async function shareTracks(tracks) {
    const list = (tracks || []).filter(Boolean);
    if (!list.length) { toast(t('share.nothing'), { icon: 'alert' }); return; }
    if (window.AndroidNative) {
      try { window.AndroidNative.shareTracks(JSON.stringify(list.slice(0, 50).map((x) => String(x.id).replace(/^n:/, '')))); }
      catch (_) { toast(t('share.err'), { type: 'error', icon: 'alert' }); }
      return;
    }
    try {
      const files = [];
      for (const tr of list.slice(0, 10)) { const b = await Library.getFile(tr); files.push(new File([b], tr.name || `${tr.title}.mp3`, { type: b.type || 'audio/mpeg' })); }
      if (navigator.canShare && navigator.canShare({ files })) await navigator.share({ files, title: list[0].title });
      else toast(t('share.err'), { type: 'error', icon: 'alert' });
    } catch (err) { if (!err || err.name !== 'AbortError') toast(t('share.err'), { type: 'error', icon: 'alert' }); }
  }

  function moreButton(track, opts, extraClass) {
    return h('button', {
      class: `icon-btn ${extraClass || ''}`.trim(), type: 'button', title: t('playlist.addTo'), 'aria-label': `${t('playlist.addTo')}: ${track.title}`,
      onclick: (e) => { e.stopPropagation(); openTrackActionsSheet(track, opts); },
    }, iconEl('more'));
  }

  /* ---- Linha de música (lista) ---- */
  function trackRow(track, { list, index, mode = 'list', playlistId } = {}) {
    const available = playable(track);
    const cover = createCover(track, 'small', 'cover-sm');
    cover.append(h('span', { class: 'row-over', 'aria-hidden': 'true' }, eqBars(), h('span', { class: 'play-ico' }, iconEl('play', 'fill'))));

    const onPlay = () => (mode === 'queue' ? Player.playAt(index) : playFromList(list, index));

    const row = h('div', { class: `row${available ? '' : ' is-unavailable is-missing'}`, role: 'listitem', dataset: { trackId: track.id } },
      h('button', { class: 'row-main', type: 'button', onclick: onPlay, 'aria-label': `Tocar ${track.title}, de ${track.artistName}` },
        cover,
        h('span', { class: 'row-text' },
          h('span', { class: 'title' }, track.title),
          h('span', { class: 'artist' }, `${track.artistName} · ${track.albumName}`))),
      h('span', { class: 'row-time' }, track.dur ? formatTime(track.dur) : ''),
      favButton(track),
      mode === 'queue'
        ? [moreButton(track, { mode }), h('button', { class: 'icon-btn', type: 'button', title: 'Remover da fila', 'aria-label': `Remover ${track.title} da fila`, onclick: (e) => { e.stopPropagation(); Player.removeFromQueue(track.id); } }, iconEl('x'))]
        : moreButton(track, { mode, playlistId }));

    markCurrent(row, track.id);
    return row;
  }

  function trackList(tracks, { mode = 'list', twoCol = false, playlistId } = {}) {
    const box = h('div', { class: `track-list${twoCol ? ' two-col' : ''}`, role: 'list' });
    appendChunked(box, tracks, (track, i) => trackRow(track, { list: tracks, index: i, mode, playlistId }));
    return box;
  }

  /* ---- Card de música (grade) ---- */
  function trackCard(track, { list, index }) {
    const available = playable(track);
    const card = h('article', { class: `card${available ? '' : ' is-unavailable'}`, role: 'listitem', dataset: { trackId: track.id } },
      h('div', { class: 'card-art' },
        h('button', { class: 'card-play', type: 'button', 'aria-label': `Tocar ${track.title}, de ${track.artistName}`, onclick: () => playFromList(list, index) },
          createCover(track, 'medium', 'cover-card')),
        h('span', { class: 'fab', 'aria-hidden': 'true' }, iconEl('play', 'fill')),
        eqBars(),
        favButton(track, 'card-fav')),
      h('div', { class: 'card-info' },
        h('span', { class: 'title' }, track.title),
        h('span', { class: 'artist' }, track.artistName)));
    markCurrent(card, track.id);
    return card;
  }

  /* ---- Sincronização visual ---- */
  function syncPlayingUI() {
    const cur = Player.getState().current;
    const id = cur ? cur.id : null;
    $$('[data-track-id]').forEach((el) => el.classList.toggle('is-current', el.dataset.trackId === id));
    syncHero();
  }

  function syncFavoriteUI() {
    $$('[data-fav-id]').forEach(paintFav);
  }

  /* ==========================================================================
     6. Telas
     ========================================================================== */

  /* ---------------------------- Utilidades de listas -------------------------- */

  const playable = (track) => !!track && !track.missing;

  /** Acrescenta itens em blocos conforme o utilizador desce (listas com milhares de músicas) */
  function appendChunked(box, items, make, size = 60) {
    let n = 0, io = null;
    const sentinel = h('div', { class: 'sentinel', 'aria-hidden': 'true', style: 'height:1px;grid-column:1/-1' });
    box.append(sentinel);
    const more = () => {
      const end = Math.min(items.length, n + size);
      const frag = document.createDocumentFragment();
      for (; n < end; n++) frag.append(make(items[n], n));
      sentinel.before(frag);
      if (n >= items.length) { if (io) io.disconnect(); sentinel.remove(); return; }
      if (io) { io.unobserve(sentinel); io.observe(sentinel); }
    };
    if ('IntersectionObserver' in window) io = new IntersectionObserver((e) => { if (e[0].isIntersecting) more(); }, { rootMargin: '900px 0px' });
    more();
    if (!io) { while (n < items.length) more(); }
  }

  function groupCover(g, cls) {
    return createCover(g.coverTrack || g.tracks[0] || { cover: '' }, 'small', cls);
  }

  /** Cartão de álbum / artista / pasta */
  function groupCard(g, type) {
    const sub = type === 'artist' ? plural(g.tracks.length) : (g.sub || plural(g.tracks.length));
    return h('article', { class: 'card is-group', role: 'listitem' },
      h('div', { class: 'card-art' },
        h('button', {
          class: 'card-play', type: 'button', 'aria-label': g.name,
          onclick: () => navigate('collection', { type, key: g.key }),
        }, groupCover(g, 'cover-card'))),
      h('div', { class: 'card-info' }, h('span', { class: 'title' }, g.name), h('span', { class: 'artist' }, sub)));
  }

  function groupRow(g, type, iconName) {
    const cover = groupCover(g, 'cover-sm');
    return h('div', { class: 'row', role: 'listitem' },
      h('button', { class: 'row-main', type: 'button', onclick: () => navigate('collection', { type, key: g.key }), 'aria-label': g.name },
        cover,
        h('span', { class: 'row-text' }, h('span', { class: 'title' }, g.name), h('span', { class: 'artist' }, `${plural(g.tracks.length)}${type === 'album' && g.sub ? ` · ${g.sub}` : ''}`))),
      h('span', { class: 'ico chev' }, iconEl(iconName || 'chevronRight')));
  }

  /* ---------------------------- Biblioteca vazia / acesso -------------------- */

  async function pickFolder() {
    if (!Library.hasPicker) {
      $('#dirInput').click();
      return;
    }
    try { await Library.addFolder(); }
    catch (err) {
      if (err && err.name === 'AbortError') return;
      toast(t('lib.error'), { type: 'error', icon: 'alert' });
    }
  }

  function pickFiles() {
    if (window.AndroidNative) { notifyScan = true; Library.useAll(); return; }
    $('#fileInput').click();
  }

  async function reconnectLibrary() {
    try { await Library.reconnect(); }
    catch (err) { if (!err || err.name !== 'AbortError') toast(t('lib.error'), { type: 'error', icon: 'alert' }); }
  }

  function emptyLibraryState() {
    if (Library.hasRoots() && Library.status.needsPermission) {
      return stateBlock({ icon: 'folder', title: t('lib.permTitle'), text: t('lib.permText'), actionLabel: t('lib.permAction'), actionIcon: 'refresh', onAction: reconnectLibrary });
    }
    const box = stateBlock({ icon: 'music', title: t('lib.empty.title'), text: t('lib.empty.text'), actionLabel: t('lib.pickFolder'), actionIcon: 'folder', onAction: pickFolder });
    box.append(h('button', { class: 'btn', type: 'button', onclick: pickFiles }, iconEl('plus'), t('lib.pickFiles')));
    return box;
  }

  /* ---------------------------------- Início --------------------------------- */

  function loadHome() {
    $('#homeGreeting').textContent = greeting();
    renderHome();
  }

  function renderHome() {
    const n = Library.count();
    const empty = $('#homeEmpty');
    const blocks = ['#homeHero', '#recentAddedBlock', '#recentPreview', '#albumsBlock'];
    if (!n) {
      empty.replaceChildren(emptyLibraryState());
      blocks.forEach((s) => { $(s).hidden = true; });
      return;
    }
    empty.replaceChildren();

    const all = Library.all();
    const history = Storage.getHistory();
    renderHero(history[0] || all[0], !!history[0]);

    const added = all.slice().sort((a, b) => b.added - a.added).slice(0, UI.cardsPerRow);
    $('#recentAddedBlock').hidden = !added.length;
    $('#recentAddedList').replaceChildren(...added.map((tr, i) => trackCard(tr, { list: added, index: i })));

    renderRecentPreview();

    const albums = Library.groups('album').filter((g) => g.tracks.length > 1 || Library.groups('album').length < 12).slice(0, UI.cardsPerRow);
    $('#albumsBlock').hidden = !albums.length;
    $('#albumsList').replaceChildren(...albums.map((g) => groupCard(g, 'album')));
  }

  function renderHero(track, isContinue) {
    const box = $('#homeHero');
    box.hidden = !track;
    if (!track) return;

    const bg = h('div', { class: 'hero-bg', 'aria-hidden': 'true' });
    const cover = createCover(track, 'large', 'cover-hero', {
      onLoad: (src) => { bg.style.backgroundImage = `url("${src}")`; bg.classList.add('on'); },
    });
    const list = Library.all();
    const index = Math.max(0, list.findIndex((x) => x.id === track.id));

    box.className = 'hero';
    box.dataset.trackId = track.id;
    box.replaceChildren(
      bg,
      h('div', { class: 'hero-cover' }, cover),
      h('div', { class: 'hero-text' },
        h('p', { class: 'hero-kicker' }, iconEl('music'), t(isContinue ? 'hero.continue' : 'hero.featured')),
        h('h2', { class: 'hero-title' }, track.title),
        h('p', { class: 'hero-artist' }, track.artistName),
        h('p', { class: 'hero-plays' }, `${track.albumName} · ${formatTime(track.dur)}`)),
      h('div', { class: 'hero-actions' },
        h('button', {
          class: 'btn primary lg hero-play', type: 'button',
          onclick: () => {
            const st = Player.getState();
            if (st.current && st.current.id === track.id) togglePlay(); else playFromList(list, index);
          },
        }, iconEl('play', 'fill'), h('span', { class: 'hero-play-label' }, t('action.playNow'))),
        favButton(track, 'btn-round'),
        queueAddButton(track, 'btn-round')));
    syncHero();
  }

  /** O botão grande do cartão inicial mostra pausa/tocar conforme a música em curso. */
  function syncHero() {
    const box = $('#homeHero');
    const btn = box && box.querySelector('.hero-play');
    if (!btn) return;
    const st = Player.getState();
    const playing = !!(st.current && st.current.id === box.dataset.trackId && st.playing);
    setIcon(btn, playing ? 'pause' : 'play', 'fill');
    const label = btn.querySelector('.hero-play-label');
    if (label) label.textContent = playing ? t('action.pause') : t('action.playNow');
  }

  function renderRecentPreview() {
    const history = Storage.getHistory().slice(0, 12);
    $('#recentPreview').hidden = !history.length;
    if (!history.length) return;
    $('#recentPreviewList').replaceChildren(...history.map((tr, i) => trackCard(tr, { list: history, index: i })));
  }

  /* -------------------------------- Pesquisa -------------------------------- */

  function enterSearch(q) {
    const input = $('#searchInput');
    // Não sobrescreve o que a pessoa está digitando; só sincroniza quando a URL muda por fora (voltar, link)
    if (document.activeElement !== input && input.value.trim() !== q) input.value = q;
    $('#searchClear').hidden = !input.value;
    runSearch(q);
  }

  function renderSearchIdle() {
    $('#searchIdle').hidden = false;
    $('#searchResults').replaceChildren();
    const recents = Storage.getSearches();
    $('#recentSearchesBlock').hidden = !recents.length;
    $('#recentSearches').replaceChildren(...recents.map((q) => h('button', { class: 'chip', type: 'button', onclick: () => searchFor(q) }, q)));

    const names = [];
    Library.groups('artist').slice(0, 10).forEach((g) => names.push(g.name));
    Library.groups('album').slice(0, 10).forEach((g) => names.push(g.name));
    const uniq = Array.from(new Set(names)).filter((n) => !/desconhecid/i.test(n));
    $('#exploreChips').closest('.block').hidden = !uniq.length;
    $('#exploreChips').replaceChildren(...uniq.map((q) => h('button', { class: 'chip', type: 'button', onclick: () => searchFor(q) }, q)));
  }

  function searchFor(q) {
    $('#searchInput').value = q;
    $('#searchClear').hidden = false;
    navigate('search', { q }, { replace: state.route === 'search' });
  }

  function runSearch(q) {
    search.q = q;
    if (!q) { search.results = []; renderSearchIdle(); return; }
    $('#searchIdle').hidden = true;
    search.results = Library.search(q);
    renderSearchResults();
  }

  function renderSearchResults() {
    const box = $('#searchResults');
    const n = search.results.length;
    const words = search.q.toLowerCase();
    const wanted = Library.search.length ? null : null; // (mantido por clareza: grupos pesquisados abaixo)
    const match = (g) => g.name.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(words.normalize('NFD').replace(/[̀-ͯ]/g, ''));
    const artists = Library.groups('artist').filter(match).slice(0, 8);
    const albums = Library.groups('album').filter(match).slice(0, 8);

    if (!n && !artists.length && !albums.length) {
      box.replaceChildren(stateBlock({ icon: 'search', title: t('search.noResults', { q: search.q }), text: Library.count() ? t('search.noResultsHint') : t('lib.empty.text') }));
      return;
    }
    const groupsBox = (artists.length || albums.length)
      ? h('div', { class: 'chips wrap', style: 'margin-bottom:14px' },
        ...artists.map((g) => h('button', { class: 'chip', type: 'button', onclick: () => navigate('collection', { type: 'artist', key: g.key }) }, g.name)),
        ...albums.map((g) => h('button', { class: 'chip', type: 'button', onclick: () => navigate('collection', { type: 'album', key: g.key }) }, g.name)))
      : null;
    box.replaceChildren(
      h('header', { class: 'view-head' }, h('div', {},
        h('h1', {}, t('search.resultsFor', { q: search.q })),
        h('p', {}, n === 1 ? t('search.oneResult') : t('search.nResults', { n })))),
      groupsBox,
      n ? trackList(search.results) : null);
    if (n) Storage.addSearch(search.q);
  }

  /* ---------------------- Músicas / Álbuns / Artistas / Pastas ---------------- */

  const SORT_KEYS = ['title', 'artist', 'album', 'duration', 'added'];

  function openSortSheet() {
    const st = Storage.getSettings();
    const rows = SORT_KEYS.map((k) => sheetRow(st.sortBy === k ? 'check' : 'sort', t(`sort.${k}`), () => {
      Storage.saveSettings({ sortBy: k });
      closeSheet(); onLibraryChange(true);
    }));
    rows.push(sheetRow(st.sortDir === -1 ? 'chevronUp' : 'chevronDown', st.sortDir === -1 ? t('sort.desc') : t('sort.asc'), () => {
      Storage.saveSettings({ sortDir: st.sortDir === -1 ? 1 : -1 });
      closeSheet(); onLibraryChange(true);
    }));
    openSheet(t('sort.by'), rows);
  }

  function renderSongs() {
    const tab = state.songsTab;
    const all = Library.all();
    const counts = { tracks: all.length, albums: Library.groups('album').length, artists: Library.groups('artist').length, folders: Library.groups('folder').length };
    const sortLabel = t(`sort.${Storage.getSettings().sortBy}`);
    $('#songsSortLabel').textContent = sortLabel;
    $('#songsCount').textContent = all.length ? plural(all.length) : t('favorites.empty');
    $('#songsActions').hidden = !all.length || tab !== 'tracks';
    $('#songsTabs').replaceChildren(...SONG_TABS.map((k) => h('button', {
      class: 'chip', type: 'button', role: 'tab', 'aria-pressed': String(k === tab),
      onclick: () => { state.songsTab = k; navigate('songs', { tab: k }, { replace: true }); },
    }, t(`songs.${k}`), h('span', { class: 'n' }, String(counts[k])))));

    const box = $('#songsList');
    if (!all.length) { box.replaceChildren(emptyLibraryState()); return; }
    if (tab === 'tracks') { box.replaceChildren(trackList(all)); return; }
    if (tab === 'albums') {
      const grid = h('div', { class: 'grid-cards', role: 'list' });
      appendChunked(grid, Library.groups('album'), (g) => groupCard(g, 'album'), 48);
      box.replaceChildren(grid); return;
    }
    const type = tab === 'artists' ? 'artist' : 'folder';
    const list = h('div', { class: 'track-list', role: 'list' });
    appendChunked(list, Library.groups(type), (g) => groupRow(g, type, 'chevronRight'), 60);
    box.replaceChildren(list);
  }

  function renderCollection(type, key) {
    const g = ['album', 'artist', 'folder'].includes(type) ? Library.group(type, key) : null;
    if (!g) { navigate('songs', {}, { replace: true }); return; }
    state.colType = type; state.colKey = key;
    $('#colTitle').textContent = g.name;
    const total = g.tracks.reduce((s, x) => s + x.dur, 0);
    $('#colCount').textContent = `${plural(g.tracks.length)} · ${formatTime(total)}${type === 'album' && g.sub ? ` · ${g.sub}` : ''}`;
    const img = $('#colCover img');
    Library.loadCover(img, g.coverTrack || g.tracks[0] || {}, {});
    $('#colCoverBtn').hidden = !(window.AndroidNative && type === 'album');
    $('#colList').replaceChildren(trackList(g.tracks));
  }

  function currentCollection() { return Library.group(state.colType, state.colKey); }

  /* --------------------------- Favoritos e Recentes --------------------------- */

  const plural = (n) => (n === 1 ? t('stat.oneTrack') : t('stat.nTracks', { n }));

  function renderFavorites() {
    const favs = Storage.getFavorites();
    $('#favCount').textContent = favs.length ? plural(favs.length) : t('favorites.empty');
    $('#favActions').hidden = !favs.length;
    $('#favList').replaceChildren(favs.length
      ? trackList(favs)
      : stateBlock({
        icon: 'heart', title: t('empty.favTitle'),
        text: t('empty.favText'),
        actionLabel: t('empty.goSongs'), actionIcon: 'music', onAction: () => navigate('songs'),
      }));
  }

  function renderRecent() {
    const history = Storage.getHistory();
    $('#recentCount').textContent = history.length ? plural(history.length) : t('recent.empty');
    $('#recentActions').hidden = !history.length;
    $('#recentList').replaceChildren(history.length
      ? trackList(history)
      : stateBlock({
        icon: 'clock', title: t('empty.recentTitle'),
        text: t('empty.recentText'),
        actionLabel: t('empty.goSongs'), actionIcon: 'music', onAction: () => navigate('songs'),
      }));
  }

  /* -------------------------------- Biblioteca -------------------------------- */

  function updateCounts() {
    $('#statFav').textContent = Storage.getFavorites().length;
    $('#statRecent').textContent = Storage.getHistory().length;
    $('#statQueue').textContent = Player.getState().queue.length;
  }

  function playlistRow(pl) {
    const cover = createCover(pl.tracks.find((x) => x.cover) || pl.tracks[0] || { cover: '' }, 'small', 'cover-sm');
    return h('a', { class: 'row playlist-row', href: `#/playlist?id=${pl.id}` },
      h('span', { class: 'row-main' }, cover,
        h('span', { class: 'row-text' },
          h('span', { class: 'title' }, pl.name),
          h('span', { class: 'artist' }, pl.tracks.length ? plural(pl.tracks.length) : t('favorites.empty')))),
      h('button', {
        class: 'icon-btn', type: 'button', 'aria-label': pl.name,
        onclick: (e) => { e.preventDefault(); e.stopPropagation(); openPlaylistRowMenu(pl); },
      }, iconEl('more')));
  }

  function newPlaylistRow() {
    return h('button', { class: 'row playlist-row new-playlist-row', type: 'button', onclick: () => promptCreatePlaylist(null, () => renderPlaylists()) },
      h('span', { class: 'row-main' },
        h('span', { class: 'cover-sm add-cover', 'aria-hidden': 'true' }, iconEl('plus')),
        h('span', { class: 'row-text' }, h('span', { class: 'title' }, t('library.newPlaylist')))));
  }

  function openPlaylistRowMenu(pl) {
    const rows = [];
    if (pl.tracks.length) {
      rows.push(sheetRow('play', t('action.playAll'), () => { Player.setQueue(pl.tracks, 0); closeSheet(); }));
      rows.push(sheetRow('shuffle', t('action.shuffle'), () => {
        if (!Player.getState().shuffle) Player.toggleShuffle();
        Player.setQueue(pl.tracks, Math.floor(Math.random() * pl.tracks.length));
        closeSheet();
      }));
    }
    rows.push(sheetRow('edit', t('playlist.rename'), () => renamePlaylistFlow(pl)));
    rows.push(sheetRow('trash', t('playlist.delete'), () => deletePlaylistFlow(pl), 'danger'));
    openSheet(pl.name, rows);
  }

  function renamePlaylistFlow(pl) {
    openPromptSheet(t('playlist.rename'), { value: pl.name, placeholder: t('playlist.namePlaceholder'), confirmLabel: t('playlist.rename') }, (clean) => {
      if (!Storage.renamePlaylist(pl.id, clean)) return;
      if (state.route === 'playlist' && state.playlistId === pl.id) renderPlaylistDetail(pl.id);
    });
  }

  function deletePlaylistFlow(pl) {
    openConfirmSheet(t('playlist.delete'), t('playlist.deleteConfirm', { name: pl.name }), { confirmLabel: t('playlist.delete') }, () => {
      Storage.deletePlaylist(pl.id);
      toast(t('playlist.deleted'), { icon: 'check' });
      if (state.route === 'playlist' && state.playlistId === pl.id) navigate('library');
    });
  }

  function renderPlaylists() {
    const box = $('#libraryPlaylists');
    if (!box) return;
    const playlists = Storage.getPlaylists();
    box.replaceChildren(h('div', { class: 'track-list playlist-list', role: 'list' },
      newPlaylistRow(),
      ...(playlists.length ? playlists.map(playlistRow) : [h('p', { class: 'muted-hint' }, t('library.noPlaylists'))])));
  }

  function renderLibrary() {
    updateCounts();
    renderQueueInto($('#libraryQueue'));
    renderPlaylists();
  }

  /* ------------------------------ Detalhe de playlist -------------------------- */

  function renderPlaylistDetail(id) {
    const pl = Storage.getPlaylist(id);
    if (!pl) { navigate('library', {}, { replace: true }); return; }
    state.playlistId = id;
    $('#plTitle').textContent = pl.name;
    $('#plCount').textContent = pl.tracks.length ? plural(pl.tracks.length) : t('playlist.emptyState');
    $('#plActions').hidden = !pl.tracks.length;
    $('#plList').replaceChildren(pl.tracks.length
      ? trackList(pl.tracks, { mode: 'playlist', playlistId: id })
      : stateBlock({
        icon: 'listPlus', title: t('playlist.emptyState'),
        text: '', actionLabel: t('empty.goSongs'), actionIcon: 'music', onAction: () => navigate('songs'),
      }));
  }

  function bindPlaylistView() {
    $('#plPlay').addEventListener('click', () => { const pl = Storage.getPlaylist(state.playlistId); if (pl && pl.tracks.length) Player.setQueue(pl.tracks, 0); });
    $('#plShuffle').addEventListener('click', () => { const pl = Storage.getPlaylist(state.playlistId); if (!pl || !pl.tracks.length) return; if (!Player.getState().shuffle) Player.toggleShuffle(); Player.setQueue(pl.tracks, Math.floor(Math.random() * pl.tracks.length)); });
    $('#plRename').addEventListener('click', () => { const pl = Storage.getPlaylist(state.playlistId); if (pl) renamePlaylistFlow(pl); });
    $('#plDelete').addEventListener('click', () => { const pl = Storage.getPlaylist(state.playlistId); if (pl) deletePlaylistFlow(pl); });
    Storage.on('playlists', () => {
      if (state.route === 'library') renderPlaylists();
      if (state.route === 'playlist') renderPlaylistDetail(state.playlistId);
    });
  }

  /* ==========================================================================
     7. Player (fixo, expandido e fila)
     ========================================================================== */

  const setBind = (name, text) => $$(`[data-bind="${name}"]`).forEach((n) => { n.textContent = text; });

  function onTrackChange(track) {
    const has = !!track;
    document.body.classList.toggle('has-track', has);
    $('#miniPlayer').classList.toggle('has-track', has);
    $$('.js-seek').forEach((r) => { r.disabled = !has; });

    const miniCover = $('#miniCover');
    const fpCover = $('#fpCover');
    const backdrop = $('#fpBackdrop');

    if (!has) {
      setBind('title', t('player.nothing'));
      setBind('artist', t('player.choose'));
      Library.clearCover(miniCover);
      Library.clearCover(fpCover);
      backdrop.classList.remove('on');
      paintProgress(0, 0);
      document.title = 'I-Music';
      $$('[data-action="fav-current"]').forEach((b) => { b.dataset.favId = ''; paintFav(b); });
      closeFullPlayer();
      syncPlayingUI();
      return;
    }

    setBind('title', track.title);
    setBind('artist', track.artistName);
    document.title = `${track.title} – ${track.artistName} | I-Music`;

    Library.loadCover(miniCover, track);
    backdrop.classList.remove('on');
    Library.loadCover(fpCover, track, {
      onLoad: (src) => { backdrop.style.backgroundImage = `url("${src}")`; backdrop.classList.add('on'); },
      onFail: () => backdrop.classList.remove('on'),
    });

    $$('[data-action="fav-current"]').forEach((b) => { b.dataset.favId = track.id; paintFav(b); });

    // Animação na troca de música
    restartAnimation($('#miniText'), 'swap');
    restartAnimation($('#fpArt'), 'swap');
    restartAnimation($('#fpText'), 'swap');

    syncPlayingUI();
    paintProgress(0, track.dur || 0);
  }

  function setIcon(btn, name, cls) {
    const holder = btn.querySelector('.ico');
    if (holder && holder.dataset.now !== name) { holder.innerHTML = icon(name, cls); holder.dataset.now = name; }
  }

  function onStateChange() {
    const st = Player.getState();
    document.body.classList.toggle('is-playing', st.playing && !st.buffering);
    $$('[data-action="play"]').forEach((btn) => {
      setIcon(btn, st.playing ? 'pause' : 'play', 'fill');
      btn.classList.toggle('is-loading', st.buffering && st.playing);
      btn.setAttribute('aria-label', st.playing ? 'Pausar' : 'Tocar');
    });
    syncHero();
  }

  function onModesChange() {
    const st = Player.getState();
    const repeatText = { off: 'Repetir: desligado', all: 'Repetir: fila inteira', one: 'Repetir: esta música' }[st.repeat];
    $$('[data-action="shuffle"]').forEach((btn) => {
      btn.classList.toggle('is-on', st.shuffle);
      btn.setAttribute('aria-pressed', String(st.shuffle));
      btn.setAttribute('aria-label', st.shuffle ? 'Aleatório: ligado' : 'Aleatório: desligado');
    });
    $$('[data-action="repeat"]').forEach((btn) => {
      setIcon(btn, st.repeat === 'one' ? 'repeat1' : 'repeat');
      btn.classList.toggle('is-on', st.repeat !== 'off');
      btn.setAttribute('aria-pressed', String(st.repeat !== 'off'));
      btn.setAttribute('aria-label', repeatText);
      btn.title = repeatText;
    });
  }

  function onVolumeChange() {
    const st = Player.getState();
    const level = st.muted ? 0 : st.volume;
    $$('.js-volume').forEach((r) => {
      r.value = Math.round(level * 100);
      r.style.setProperty('--fill', `${Math.round(level * 100)}%`);
    });
    const pct = Math.round(level * 100);
    const vs = $('#fpVolSlider');
    if (vs) {
      vs.style.setProperty('--vol', `${pct}%`);
      vs.setAttribute('aria-valuenow', String(pct));
      vs.setAttribute('aria-valuetext', `${pct}%`);
    }
    const vv = $('#fpVolVal');
    if (vv) vv.textContent = String(pct);
    $$('[data-action="mute"], [data-action="toggle-volume"]').forEach((btn) => {
      setIcon(btn, level === 0 ? 'volumeX' : level < 0.5 ? 'volume1' : 'volume2');
      if (btn.dataset.action === 'mute') btn.setAttribute('aria-label', level === 0 ? 'Ativar som' : 'Silenciar');
    });
  }

  function paintProgress(current, duration) {
    const ratio = duration > 0 ? Math.min(1, current / duration) : 0;
    const pct = `${(ratio * 100).toFixed(2)}%`;
    $$('.js-seek').forEach((r) => { r.value = Math.round(ratio * 1000); r.style.setProperty('--fill', pct); });
    $('#miniLine').style.setProperty('--fill', pct);
    setBind('cur', formatTime(current));
    setBind('dur', formatTime(duration));
  }

  function onTimeUpdate() {
    if (state.seeking) return;
    const { current, duration } = Player.getTime();
    paintProgress(current, duration);
  }

  function onQueueChange() {
    const n = Player.getState().queue.length;
    $('#queueBadge').textContent = n ? String(n) : '';
    $('#statQueue').textContent = String(n);
    if (state.drawerOpen) renderQueueInto($('#queueList'));
    if (state.route === 'library') renderQueueInto($('#libraryQueue'));
  }

  function onPlayerError({ track, kind, willSkip }) {
    let message;
    if (kind === 'missing') message = t('err.trackMissing', { title: track.title });
    else if (kind === 'permission') { message = t('err.permission'); Library.checkPermissions(); }
    else message = t('err.trackFailed', { title: track.title });
    if (willSkip) message += ` ${t('err.skipping')}`;
    toast(message, { type: 'error', icon: 'alert', duration: 4500 });
  }

  /* ---- Fila ---- */
  function renderQueueInto(container) {
    const st = Player.getState();
    if (!st.queue.length) {
      container.replaceChildren(stateBlock({
        icon: 'queue', title: t('empty.queueTitle'),
        text: t('empty.queueText'),
      }));
      return;
    }
    container.replaceChildren(trackList(st.queue, { mode: 'queue' }));
  }

  function openQueue() {
    state.drawerOpen = true;
    const drawer = $('#queueDrawer');
    renderQueueInto($('#queueList'));
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden', 'false');
    state.lastFocus = document.activeElement;
    const current = $('#queueList .is-current');
    if (current) current.scrollIntoView({ block: 'center' });
    $('#queueDrawer [data-action="close-queue"].icon-btn').focus({ preventScroll: true });
  }

  function closeQueue() {
    if (!state.drawerOpen) return;
    state.drawerOpen = false;
    const drawer = $('#queueDrawer');
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    if (state.lastFocus && state.lastFocus.focus) state.lastFocus.focus({ preventScroll: true });
  }

  /* ---- Player expandido ---- */
  function openFullPlayer() {
    if (!Player.getState().current) return;
    const fp = $('#fullPlayer');
    state.lastFocus = document.activeElement;
    fp.classList.add('open');
    fp.setAttribute('aria-hidden', 'false');
    document.body.classList.add('fp-open');
    $('#fullPlayer [data-action="collapse"]').focus({ preventScroll: true });
  }

  function closeFullPlayer() {
    const fp = $('#fullPlayer');
    if (!fp.classList.contains('open')) return;
    fp.classList.remove('open');
    fp.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('fp-open');
    closeVolumePop();
    if (state.lastFocus && state.lastFocus.focus) state.lastFocus.focus({ preventScroll: true });
  }

  /* ---- Popover de volume (vertical, some sozinho após 5s) ---- */
  let volumeHideTimer = null;

  function scheduleVolumeHide() {
    clearTimeout(volumeHideTimer);
    volumeHideTimer = setTimeout(closeVolumePop, 5000);
  }

  function openVolumePop() {
    const pop = $('#fpVolumePop');
    const btn = $('[data-action="toggle-volume"]');
    if (!pop || pop.classList.contains('open')) { scheduleVolumeHide(); return; }
    Player.syncVolume();
    pop.classList.add('open');
    pop.setAttribute('aria-hidden', 'false');
    if (btn) btn.setAttribute('aria-expanded', 'true');
    scheduleVolumeHide();
  }

  function closeVolumePop() {
    clearTimeout(volumeHideTimer);
    const pop = $('#fpVolumePop');
    const btn = $('[data-action="toggle-volume"]');
    if (!pop || !pop.classList.contains('open')) return;
    pop.classList.remove('open');
    pop.setAttribute('aria-hidden', 'true');
    if (btn) btn.setAttribute('aria-expanded', 'false');
  }

  /* ---- Barra de volume do painel (arrastar, toque e teclado) ---- */
  function bindVolumeSlider() {
    const el = $('#fpVolSlider');
    if (!el) return;
    const STEPS = 15; // como os níveis do sistema Android
    let dragging = false, lastStep = -1;
    const apply = (v, haptic) => {
      v = Math.min(1, Math.max(0, v));
      Player.setVolume(v);
      const step = Math.round(v * STEPS);
      if (haptic && step !== lastStep && window.IMusic.Native && window.IMusic.Native.tick) window.IMusic.Native.tick();
      lastStep = step;
      scheduleVolumeHide();
    };
    const fromX = (x) => { const r = el.getBoundingClientRect(); return (x - r.left) / r.width; };
    el.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.vol-ico')) return;
      dragging = true;
      lastStep = Math.round(Player.getState().volume * STEPS);
      try { el.setPointerCapture(e.pointerId); } catch (_) { /* ok */ }
      el.classList.add('drag');
      apply(fromX(e.clientX), true);
      e.preventDefault();
    });
    el.addEventListener('pointermove', (e) => { if (dragging) apply(fromX(e.clientX), true); });
    const end = () => { dragging = false; el.classList.remove('drag'); };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    el.addEventListener('keydown', (e) => {
      const cur = Player.getState().volume;
      let v = null;
      if (e.key === 'ArrowRight' || e.key === 'ArrowUp') v = cur + 1 / STEPS;
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') v = cur - 1 / STEPS;
      else if (e.key === 'Home') v = 0;
      else if (e.key === 'End') v = 1;
      if (v === null) return;
      e.preventDefault();
      apply(v, true);
    });
  }

  function togglePlay() {
    const st = Player.getState();
    if (!st.current && !st.queue.length) {
      toast(t('toast.chooseTrack'), { icon: 'music' });
      return;
    }
    Player.toggle();
  }

  function bindPlayerUI() {
    // Um único ouvinte para todos os botões com data-action (player fixo, expandido e fila)
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      switch (btn.dataset.action) {
        case 'play': pulse(btn); togglePlay(); break;
        case 'prev': Player.prev(); break;
        case 'next': Player.next(); break;
        case 'shuffle': Player.toggleShuffle(); break;
        case 'repeat': Player.cycleRepeat(); break;
        case 'mute': Player.toggleMute(); break;
        case 'toggle-volume': {
          const pop = $('#fpVolumePop');
          if (pop && pop.classList.contains('open')) closeVolumePop();
          else openVolumePop();
          break;
        }
        case 'share-current': { const cur = Player.getState().current; if (cur) shareTracks([cur]); break; }
        case 'expand': openFullPlayer(); break;
        case 'collapse': closeFullPlayer(); break;
        case 'queue': closeVolumePop(); openQueue(); break;
        case 'close-queue': closeQueue(); break;
        case 'clear-queue': Player.clearQueue(); break;
        case 'fav-current': {
          const cur = Player.getState().current;
          if (cur) toggleFavorite(cur, btn);
          break;
        }
        default: break;
      }
      if (!e.target.closest('.fp-volume-anchor')) closeVolumePop();
    });

    // Barra de progresso: arrastar mostra o tempo; soltar move a música
    $$('.js-seek').forEach((range) => {
      range.addEventListener('input', () => {
        state.seeking = true;
        const { duration } = Player.getTime();
        paintProgress((range.value / 1000) * duration, duration);
      });
      range.addEventListener('change', () => {
        Player.seekRatio(range.value / 1000);
        state.seeking = false;
      });
      range.addEventListener('pointerup', () => setTimeout(() => { state.seeking = false; }, 80));
    });

    $$('.js-volume').forEach((range) => {
      range.addEventListener('input', () => Player.setVolume(range.value / 100));
    });
    bindVolumeSlider();

    // Deslizar para baixo fecha o player expandido (celular)
    const fp = $('#fullPlayer');
    let startY = null;
    fp.addEventListener('touchstart', (e) => {
      startY = e.target.closest('input, button, .vol-slider') ? null : e.touches[0].clientY;
    }, { passive: true });
    fp.addEventListener('touchend', (e) => {
      if (startY === null) return;
      if (e.changedTouches[0].clientY - startY > 110) closeFullPlayer();
      startY = null;
    }, { passive: true });
  }

  /* ==========================================================================
     8. Inicialização
     ========================================================================== */

  /* ==========================================================================
     8. Ligações da interface
     ========================================================================== */

  function bindSearch() {
    const input = $('#searchInput');
    const clearBtn = $('#searchClear');

    const submit = () => {
      const q = input.value.trim();
      navigate('search', q ? { q } : {}, { replace: state.route === 'search' });
    };
    const submitLater = debounce(submit, UI.searchDebounceMs);

    input.addEventListener('input', () => { clearBtn.hidden = !input.value; submitLater(); });
    input.addEventListener('focus', () => { if (state.route !== 'search') submit(); });
    $('#searchForm').addEventListener('submit', (e) => { e.preventDefault(); submit(); input.blur(); });
    clearBtn.addEventListener('click', () => { input.value = ''; clearBtn.hidden = true; submit(); input.focus(); });
    $('#clearSearches').addEventListener('click', () => { Storage.clearSearches(); renderSearchIdle(); });
  }

  function bindViews() {
    $('#favPlay').addEventListener('click', () => playAll(Storage.getFavorites()));
    $('#favShuffle').addEventListener('click', () => playAll(Storage.getFavorites(), { shuffle: true }));
    $('#recentPlay').addEventListener('click', () => playAll(Storage.getHistory()));
    $('#recentClear').addEventListener('click', () => Storage.clearHistory());
    $('#clearHistoryBtn').addEventListener('click', () => { Storage.clearHistory(); toast(t('toast.historyCleared')); });
    $('#clearFavsBtn').addEventListener('click', () => {
      if (Storage.getFavorites().length && window.confirm(t('toast.confirmClearFavs'))) {
        Storage.clearFavorites();
        toast(t('toast.favoritesCleared'));
      }
    });
    $('#statQueueTile').addEventListener('click', openQueue);

    $('#songsPlay').addEventListener('click', () => playAll(Library.all()));
    $('#songsShuffle').addEventListener('click', () => playAll(Library.all(), { shuffle: true }));
    $('#songsSort').addEventListener('click', openSortSheet);

    $('#colShare').addEventListener('click', () => { const g = currentCollection(); if (g) shareTracks(g.tracks.filter(playable)); });
    $('#colCoverBtn').addEventListener('click', () => { const g = currentCollection(); if (g) changeCover(g.tracks); });
    $('#colPlay').addEventListener('click', () => { const g = currentCollection(); if (g) playAll(g.tracks); });
    $('#colShuffle').addEventListener('click', () => { const g = currentCollection(); if (g) playAll(g.tracks, { shuffle: true }); });
    $('#colQueue').addEventListener('click', () => { const g = currentCollection(); if (g) { g.tracks.filter(playable).forEach((tr) => { if (!Player.getState().current) Player.setQueue([tr], 0); else Player.addToQueue(tr); }); toast(t('toast.queued'), { icon: 'queue' }); } });
  }

  function bindGlobalEvents() {
    window.addEventListener('hashchange', onRoute);

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (activeSheet) closeSheet();
        else if (state.drawerOpen) closeQueue();
        else if ($('#settingsPanel').classList.contains('open')) closeSettings();
        else closeFullPlayer();
        return;
      }
      if (e.target.closest('input, textarea, button, a, select, [contenteditable]')) return;
      if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
      else if (e.shiftKey && e.key === 'ArrowRight') Player.next();
      else if (e.shiftKey && e.key === 'ArrowLeft') Player.prev();
    });

    // Favoritos e histórico mudam em vários lugares ao mesmo tempo
    Storage.on('favorites', () => {
      syncFavoriteUI();
      updateCounts();
      if (state.route === 'favorites') renderFavorites();
    });
    Storage.on('history', () => {
      updateCounts();
      if (state.route === 'recent') renderRecent();
      if (state.route === 'home') renderRecentPreview();
    });
  }

  /* ---------------------- Biblioteca: avisos, eventos, ficheiros --------------- */

  let notifyScan = false; // só avisa o resultado de leituras pedidas pelo utilizador

  function updateBanner() {
    const st = Library.status;
    const banner = $('#libBanner');
    if (st.scanning) {
      const pct = st.total ? Math.min(100, Math.round((st.done / st.total) * 100)) : 0;
      const text = st.phase === 'collect' || !st.total ? t('lib.collecting') : t('lib.scanning', { done: st.done, total: st.total, found: st.found });
      banner.hidden = false;
      banner.replaceChildren(
        h('span', { class: 'lib-banner-text' }, text),
        h('button', { class: 'btn sm', type: 'button', onclick: () => Library.cancelScan() }, t('lib.cancel')),
        h('span', { class: 'bar', 'aria-hidden': 'true' }, h('i', { style: `width:${pct}%` })));
    } else if (st.needsPermission && Library.hasRoots()) {
      banner.hidden = false;
      banner.replaceChildren(
        h('span', { class: 'lib-banner-text' }, t('lib.permBanner')),
        h('button', { class: 'btn sm primary', type: 'button', onclick: reconnectLibrary }, t('lib.permAction')));
    } else {
      banner.hidden = true;
    }
  }

  let libTimer = 0;
  /** A biblioteca mudou (leitura em curso, ordenação, apagar...): refaz o que está visível */
  function onLibraryChange(force) {
    clearTimeout(libTimer);
    libTimer = setTimeout(() => {
      Player.getState().queue.forEach((tr) => { if (!Library.get(tr.id)) Player.dropTrack(tr.id); });
      updateCounts();
      updateLibrarySettings();
      if (!force && window.scrollY > 80 && ['songs', 'collection', 'favorites', 'recent', 'search'].includes(state.route)) return;
      onRoute();
    }, force ? 0 : 600);
  }

  function summarizeScan(sum) {
    if (!sum || sum.noRoots) return;
    const n = Library.count();
    if (sum.error) { if (notifyScan) toast(t('lib.error'), { type: 'error', icon: 'alert' }); return; }
    if (sum.missingRoot) { toast(t('lib.rootMissing', { name: sum.missingRoot }), { type: 'error', icon: 'alert' }); return; }
    if (sum.dup !== undefined) { // ficheiros escolhidos à mão
      const parts = [];
      if (sum.added) parts.push(t('lib.filesDone', { n: sum.added }));
      if (sum.dup) parts.push(t('lib.filesDup', { n: sum.dup }));
      if (sum.bad) parts.push(t('lib.filesBad', { n: sum.bad }));
      if (sum.full) parts.unshift(t('lib.full'));
      if (parts.length) toast(parts.join(' · '), { icon: sum.added ? 'check' : 'alert', duration: 4800 });
      return;
    }
    const parts = [];
    if (sum.added) parts.push(t('lib.added', { n: sum.added }));
    if (sum.updated) parts.push(t('lib.updated', { n: sum.updated }));
    if (sum.removed) parts.push(t('lib.removed', { n: sum.removed }));
    if (parts.length) toast(`${t('lib.scanDone', { n })} · ${parts.join(' · ')}`, { icon: 'check', duration: 4500 });
    else if (notifyScan) toast(sum.total ? t('lib.noChanges') : t('lib.noneFound'), { icon: sum.total ? 'check' : 'alert' });
  }

  function bindLibraryEvents() {
    Library.on('scan', updateBanner);
    Library.on('change', () => onLibraryChange(false));
    Library.on('scandone', (sum) => {
      updateBanner();
      summarizeScan(sum);
      notifyScan = false;
      onLibraryChange(false);
      const ob = $('#obLibStatus');
      if (ob && !$('#onboarding').hidden && Library.count()) { ob.textContent = t('ob.libFound', { n: Library.count() }); ob.classList.add('ok'); }
    });

    const onFiles = (e) => {
      const files = e.target.files;
      if (files && files.length) { notifyScan = true; Library.addFiles(files); }
      e.target.value = '';
    };
    $('#fileInput').addEventListener('change', onFiles);
    $('#dirInput').addEventListener('change', onFiles);
  }

  function updateLibrarySettings() {
    const countEl = $('#spLibCount');
    if (!countEl) return;
    const n = Library.count();
    countEl.textContent = plural(n);
    const roots = Library.rootsInfo();
    $('#spLibFolders').textContent = roots.length ? (roots.length === 1 ? `${t('lib.folderOne')}: ${roots[0].name}` : t('lib.folderCount', { n: roots.length })) : t('lib.noFolder');
    const st = Storage.getSettings();
    $('#hideShortSwitch').setAttribute('aria-checked', String(!!st.hideShort));
    $('#resumeSwitch').setAttribute('aria-checked', String(!!st.resume));
  }

  function bindLibrarySettings() {
    $('#spAddFolder').addEventListener('click', pickFolder);
    $('#spAddFiles').addEventListener('click', () => {
      if (window.AndroidNative) { notifyScan = true; Library.useAll(); return; }
      openSheet(t('settings.addFiles'), [
        sheetRow('music', t('ob.pickFiles'), () => { closeSheet(); $('#fileInput').click(); }),
        sheetRow('folder', t('lib.pickFolder'), () => { closeSheet(); $('#dirInput').click(); }),
      ]);
    });
    $('#spRescan').addEventListener('click', () => {
      if (!Library.hasRoots()) { toast(t('lib.empty.text'), { icon: 'folder', duration: 5000 }); return; }
      notifyScan = true;
      Library.rescan({ request: true });
    });
    $('#hideShortSwitch').addEventListener('click', () => {
      Storage.saveSettings({ hideShort: !Storage.getSettings().hideShort });
      updateLibrarySettings(); onLibraryChange(true);
    });
    $('#resumeSwitch').addEventListener('click', () => { Storage.saveSettings({ resume: !Storage.getSettings().resume }); updateLibrarySettings(); });
    $('#clearLibraryBtn').addEventListener('click', () => {
      openConfirmSheet(t('settings.clearLibrary'), t('lib.clearConfirm'), { confirmLabel: t('settings.clear') }, async () => {
        Player.stop();
        await Library.removeAll();
        toast(t('lib.cleared'), { icon: 'check' });
        updateBanner(); onLibraryChange(true);
      });
    });
    updateLibrarySettings();
  }

  /* ==========================================================================
     9. Configurações (tema, idioma, dados e sobre)
     ========================================================================== */

  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    const meta = $('#themeColorMeta');
    if (meta) meta.setAttribute('content', theme === 'light' ? '#f7f5f1' : '#0b0a13');
    const sw = $('#themeSwitch');
    if (sw) sw.setAttribute('aria-checked', String(theme === 'dark'));
  }

  function applyLang(lang) {
    const sw = $('#langSwitch');
    if (sw) $$('button', sw).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.lang === lang)));
    applyI18n();
    document.title = Player.getState().current ? document.title : 'I-Music';
    if (!Player.getState().current) { setBind('title', t('player.nothing')); setBind('artist', t('player.choose')); }
    renderCurrentView();
  }

  /** Re-renderiza a view atual (usado após trocar o idioma) */
  function renderCurrentView() {
    updateBanner();
    updateLibrarySettings();
    onRoute();
  }

  function openSettings() {
    const panel = $('#settingsPanel');
    panel.hidden = false;
    panel.setAttribute('aria-hidden', 'false');
    requestAnimationFrame(() => panel.classList.add('open'));
    document.body.style.overflow = 'hidden';
    updateLibrarySettings();
  }

  function closeSettings() {
    const panel = $('#settingsPanel');
    panel.classList.remove('open');
    panel.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    setTimeout(() => { panel.hidden = true; }, 500);
  }

  function bindSettings() {
    $('#settingsOpen').addEventListener('click', openSettings);
    $('#eqOpenTop').addEventListener('click', () => openEqualizerSheet());
    $('#settingsOpenDesktop').addEventListener('click', openSettings);
    $('#settingsClose').addEventListener('click', closeSettings);

    const settings = Storage.getSettings();
    applyTheme(settings.theme === 'dark' ? 'dark' : 'light');

    $('#themeSwitch').addEventListener('click', () => {
      const next = Storage.getSettings().theme === 'dark' ? 'light' : 'dark';
      Storage.saveSettings({ theme: next });
      applyTheme(next);
    });

    $('#langSwitch').addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-lang]');
      if (!btn) return;
      const next = btn.dataset.lang === 'en' ? 'en' : 'pt';
      if (next === Storage.getSettings().lang) return;
      Storage.saveSettings({ lang: next });
      applyLang(next);
    });

    $('#appVersion').textContent = UI.appVersion;
    bindSleepTimer();
    bindResetAndEq();
    bindLibrarySettings();
    applyLang(settings.lang === 'en' ? 'en' : 'pt');
  }

  let sleepTimerHandle = null;

  function setSleepTimerUI(minutes) {
    $$('#sleepTimerSwitch button').forEach((btn) => {
      btn.setAttribute('aria-pressed', String(Number(btn.dataset.min) === minutes));
    });
  }

  function applySleepTimer(minutes, { silent = false } = {}) {
    if (sleepTimerHandle) { clearTimeout(sleepTimerHandle); sleepTimerHandle = null; }
    setSleepTimerUI(minutes);
    if (minutes > 0) {
      sleepTimerHandle = setTimeout(() => { Player.pause(); setSleepTimerUI(0); }, minutes * 60000);
      if (!silent) toast(t('settings.sleepTimerSet', { min: minutes }), { icon: 'clock' });
    } else if (!silent) {
      toast(t('settings.sleepTimerCancelled'), { icon: 'clock' });
    }
  }

  function bindSleepTimer() {
    setSleepTimerUI(0); // não persiste entre sessões: cada sessão começa desligado
    $('#sleepTimerSwitch').addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-min]');
      if (!btn) return;
      applySleepTimer(Number(btn.dataset.min) || 0);
    });
  }

  function bindResetAndEq() {
    $('#resetSettingsBtn').addEventListener('click', () => {
      applySleepTimer(0, { silent: true });
      Storage.saveSettings({ theme: 'light', lang: 'pt' });
      applyTheme('light');
      applyLang('pt');
      toast(t('settings.resetDone'), { icon: 'check' });
    });
    $('#openEqBtn').addEventListener('click', openEqualizerSheet);
  }

  /** Modal do equalizador: presets + sliders manuais, aberto a partir da
   *  linha "Equalizador" nas Configurações. Reconstrói o conteúdo a cada
   *  abertura a partir do estado atual do Player. */
  function openEqualizerSheet() {
    const bandKeys = ['bass', 'mid', 'treble'];
    const presetsBox = h('div', { class: 'chips wrap' });
    const rangeEls = {};
    const outEls = {};

    function paintFromState() {
      const eq = Player.getEqState();
      $$('button[data-eq-preset]', presetsBox).forEach((btn) => btn.setAttribute('aria-pressed', String(btn.dataset.eqPreset === eq.preset)));
      bandKeys.forEach((band) => {
        const v = eq.bands[band] || 0;
        rangeEls[band].value = v;
        outEls[band].textContent = `${v > 0 ? '+' : ''}${v}dB`;
      });
    }

    const eq = Player.getEqState();
    presetsBox.replaceChildren(...eq.presets.map((name) => h('button', {
      class: 'chip', type: 'button', dataset: { eqPreset: name }, 'aria-pressed': String(eq.preset === name), disabled: !eq.available,
      onclick: () => { Player.setEqPreset(name); paintFromState(); },
    }, t(`eq.${name}`))));

    const sliders = bandKeys.map((band) => {
      const range = h('input', {
        type: 'range', min: '-12', max: '12', step: '1', value: String(eq.bands[band] || 0), class: 'eq-range',
        'aria-label': t(`eq.${band}Label`), disabled: !eq.available,
        oninput: () => { Player.setEqBand(band, range.value); paintFromState(); },
      });
      const out = h('output', {}, `${eq.bands[band] > 0 ? '+' : ''}${eq.bands[band]}dB`);
      rangeEls[band] = range;
      outEls[band] = out;
      return h('label', { class: 'eq-slider' }, h('span', {}, t(`eq.${band}Label`)), range, out);
    });

    const body = h('div', { class: 'eq-card' },
      eq.available ? null : h('p', { class: 'sheet-message eq-warning' }, t('eq.unavailable')),
      presetsBox, h('div', { class: 'eq-sliders' }, ...sliders));
    mountSheet(t('settings.equalizer'), body);
  }

  /* ==========================================================================
     10. Boas-vindas (primeira abertura)
     ========================================================================== */

  const onboarding = { step: 0, last: window.AndroidNative ? 1 : 2 };

  function goOnboardingStep(step) {
    onboarding.step = step;
    $$('.ob-step').forEach((el) => el.classList.toggle('active', Number(el.dataset.step) === step));
    $$('#obDots span').forEach((el, i) => el.classList.toggle('active', i === step));
    const btn = $('#obNext');
    btn.textContent = step === onboarding.last ? t('ob.proceed') : t('ob.continue');
    btn.disabled = step === 1 && !$('#obName').value.trim();
  }

  function finishOnboarding() {
    Storage.saveProfile({ onboarded: true, name: $('#obName').value.trim() });
    $('#onboarding').hidden = true;
    if (state.route === 'home') loadHome();
  }

  function bindOnboarding() {
    if (window.AndroidNative) {
      // O app lê as músicas do telemóvel sozinho: não há passo de escolher pasta/ficheiros
      const step = document.querySelector('.ob-step[data-step="2"]');
      if (step) step.remove();
      const dots = $$('#obDots span');
      if (dots[2]) dots[2].remove();
    }
    $('#obName').addEventListener('input', () => {
      if (onboarding.step === 1) $('#obNext').disabled = !$('#obName').value.trim();
    });
    $('#obName').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#obNext').click(); } });
    $('#obNext').addEventListener('click', () => {
      if (onboarding.step < onboarding.last) goOnboardingStep(onboarding.step + 1);
      else finishOnboarding();
    });
    const obFolder = $('#obPickFolder'), obFiles = $('#obPickFiles');
    if (obFolder) obFolder.addEventListener('click', () => { notifyScan = true; pickFolder(); });
    if (obFiles) obFiles.addEventListener('click', pickFiles);

    if (!Storage.getProfile().onboarded) {
      $('#onboarding').hidden = false;
      goOnboardingStep(0);
    }
  }

  async function init() {
    hydrateIcons();
    try { await Library.init(); }
    catch (_) { $('#main').prepend(stateBlock({ icon: 'alert', title: 'I-Music', text: t('err.storage') })); }

    bindSearch();
    bindViews();
    bindPlayerUI();
    bindGlobalEvents();
    bindLibraryEvents();
    bindSettings();
    bindOnboarding();
    bindPlaylistView();

    Player.on('trackchange', onTrackChange);
    Player.on('state', onStateChange);
    Player.on('time', onTimeUpdate);
    Player.on('queue', onQueueChange);
    Player.on('queue', paintQueueButtons);
    Player.on('modes', onModesChange);
    Player.on('volume', onVolumeChange);
    Player.on('started', (track) => Storage.addToHistory(track));
    Player.on('error', onPlayerError);
    Player.on('blocked', () => toast(t('toast.pressPlay'), { icon: 'play' }));
    Player.init();
    // Se a música já está a tocar no leitor nativo (app reaberto), liga-se sempre a ela
    if (Storage.getSettings().resume || Player.isNativeRunning()) Player.restore();

    if (!location.hash) history.replaceState(null, '', '#/home');
    onRoute();
    updateCounts();
    updateBanner();

    // Lê a pasta sozinho em cada abertura (sem pedir nada se o acesso já está guardado)
    if (Library.hasRoots()) Library.rescan();

    if (!window.AndroidNative && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
      navigator.serviceWorker.register('service-worker.js').catch(() => {});
    }
  }

  init();
})();
