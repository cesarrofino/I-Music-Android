/**
 * I-Music · storage.js
 * Persistência local: favoritos, playlists, histórico, pesquisas recentes,
 * preferências e último estado do player.
 *
 * Favoritos, playlists e histórico guardam só os IDs das músicas; os dados
 * (título, capa...) vêm sempre da biblioteca local (library.js) através do
 * "resolver". Assim nada fica desatualizado e músicas apagadas do telemóvel
 * deixam de aparecer sem partir as listas.
 *
 * Tudo fica no localStorage com um prefixo próprio. Se o navegador bloquear o
 * localStorage (modo privado), os dados continuam em memória durante a sessão.
 */
(function (global) {
  'use strict';

  const IMusic = (global.IMusic = global.IMusic || {});

  const PREFIX = 'imusic:v2:';
  const OLD_PREFIX = 'imusic:v1:';

  const LIMITS = Object.freeze({ history: 100, searches: 8, playlists: 200 });

  const DEFAULT_SETTINGS = Object.freeze({
    volume: 0.8, shuffle: false, repeat: 'off', theme: 'light', lang: 'pt',
    sortBy: 'title', sortDir: 1, hideShort: true, resume: true,
    eq: { preset: 'flat', bands: { bass: 0, mid: 0, treble: 0 } },
  });
  const DEFAULT_PROFILE = Object.freeze({ onboarded: false, name: '' });

  const cache = {};
  const listeners = {};
  let resolver = (id) => null;

  /* ---------------------------- Acesso ao disco ---------------------------- */

  function read(key, fallback) {
    if (key in cache) return cache[key];
    try {
      let raw = global.localStorage.getItem(PREFIX + key);
      if (raw === null && (key === 'settings' || key === 'profile')) raw = global.localStorage.getItem(OLD_PREFIX + key); // migra preferências antigas
      if (raw !== null) { const value = JSON.parse(raw); cache[key] = value; return value; }
    } catch (_) { /* indisponível ou corrompido */ }
    return fallback;
  }

  function write(key, value) {
    cache[key] = value;
    try { global.localStorage.setItem(PREFIX + key, JSON.stringify(value)); return true; } catch (_) { return false; }
  }

  function on(name, fn) { (listeners[name] = listeners[name] || []).push(fn); }
  function emit(name, payload) {
    (listeners[name] || []).forEach((fn) => { try { fn(payload); } catch (err) { console.error('[storage]', err); } });
  }

  function setResolver(fn) { resolver = fn; }
  const asIds = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []);
  const hydrate = (ids) => ids.map((id) => resolver(id)).filter(Boolean);

  /* -------------------------------- Favoritos ------------------------------ */

  let favSet = null;
  const favIds = () => asIds(read('favorites', []));
  const idSet = () => (favSet || (favSet = new Set(favIds())));

  function getFavorites() { return hydrate(favIds()); }
  function isFavorite(id) { return idSet().has(String(id)); }

  function toggleFavorite(track) {
    const id = String(track.id);
    const list = favIds();
    const exists = list.includes(id);
    write('favorites', exists ? list.filter((x) => x !== id) : [id, ...list]);
    favSet = null;
    emit('favorites', { id, added: !exists });
    return !exists;
  }

  function clearFavorites() { write('favorites', []); favSet = null; emit('favorites', { cleared: true }); }

  /* -------------------------------- Histórico ------------------------------ */

  const historyIds = () => asIds(read('history', []));
  function getHistory() { return hydrate(historyIds()); }

  function addToHistory(track) {
    const id = String(track.id);
    write('history', [id].concat(historyIds().filter((x) => x !== id)).slice(0, LIMITS.history));
    emit('history', { id });
  }

  function clearHistory() { write('history', []); emit('history', { cleared: true }); }

  /* --------------------------- Pesquisas recentes -------------------------- */

  function getSearches() {
    const list = read('searches', []);
    return Array.isArray(list) ? list.filter((q) => typeof q === 'string').slice() : [];
  }
  function addSearch(query) {
    const q = String(query || '').trim();
    if (!q) return;
    const next = [q, ...getSearches().filter((s) => s.toLowerCase() !== q.toLowerCase())].slice(0, LIMITS.searches);
    write('searches', next); emit('searches', next);
  }
  function clearSearches() { write('searches', []); emit('searches', []); }

  /* -------------------------------- Playlists ------------------------------- */

  const genId = () => `pl_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const rawPlaylists = () => {
    const v = read('playlists', []);
    return Array.isArray(v) ? v.filter((p) => p && p.id && typeof p.name === 'string' && Array.isArray(p.ids)) : [];
  };
  const present = (p) => Object.assign({}, p, { tracks: hydrate(asIds(p.ids)) });

  function getPlaylists() { return rawPlaylists().map(present); }
  function getPlaylist(id) { const p = rawPlaylists().find((x) => x.id === id); return p ? present(p) : null; }

  function createPlaylist(name, initialTracks) {
    const clean = String(name || '').trim();
    if (!clean) return null;
    const list = rawPlaylists();
    if (list.length >= LIMITS.playlists) return null;
    const playlist = { id: genId(), name: clean.slice(0, 80), createdAt: Date.now(), ids: Array.from(new Set((initialTracks || []).map((t) => String(t.id)))) };
    write('playlists', [playlist, ...list]);
    emit('playlists', { created: playlist.id });
    return present(playlist);
  }

  function updatePlaylist(id, fn) {
    const list = rawPlaylists(); const i = list.findIndex((p) => p.id === id);
    if (i === -1) return false;
    const next = fn(Object.assign({}, list[i], { ids: asIds(list[i].ids).slice() }));
    if (next === false) return false;
    list[i] = next; write('playlists', list); emit('playlists', { updated: id });
    return true;
  }

  function renamePlaylist(id, name) {
    const clean = String(name || '').trim();
    if (!clean) return false;
    return updatePlaylist(id, (p) => Object.assign(p, { name: clean.slice(0, 80) }));
  }
  function deletePlaylist(id) { write('playlists', rawPlaylists().filter((p) => p.id !== id)); emit('playlists', { deleted: id }); }

  /** 'added' | 'exists' | null (playlist inexistente) */
  function addToPlaylist(id, track) {
    let result = null;
    updatePlaylist(id, (p) => {
      const tid = String(track.id);
      if (p.ids.includes(tid)) { result = 'exists'; return false; }
      p.ids.push(tid); result = 'added'; return p;
    });
    return result;
  }

  function addManyToPlaylist(id, tracks) {
    let n = 0;
    updatePlaylist(id, (p) => { tracks.forEach((t) => { const tid = String(t.id); if (!p.ids.includes(tid)) { p.ids.push(tid); n++; } }); return p; });
    return n;
  }

  function removeFromPlaylist(id, trackId) { return updatePlaylist(id, (p) => { p.ids = p.ids.filter((x) => x !== String(trackId)); return p; }); }

  /** Move uma faixa dentro da playlist (dir = -1 sobe, +1 desce) */
  function moveInPlaylist(id, trackId, dir) {
    return updatePlaylist(id, (p) => {
      const i = p.ids.indexOf(String(trackId)), j = i + dir;
      if (i < 0 || j < 0 || j >= p.ids.length) return false;
      [p.ids[i], p.ids[j]] = [p.ids[j], p.ids[i]]; return p;
    });
  }

  function isTrackInPlaylist(id, trackId) { const p = rawPlaylists().find((x) => x.id === id); return !!p && p.ids.includes(String(trackId)); }

  /* ------------------------------- Preferências ---------------------------- */

  function getSettings() {
    const saved = read('settings', {});
    return Object.assign({}, DEFAULT_SETTINGS, saved && typeof saved === 'object' ? saved : {});
  }
  function saveSettings(patch) { write('settings', Object.assign(getSettings(), patch)); emit('settings', patch); }

  /* --------------------------------- Perfil --------------------------------- */

  function getProfile() {
    const saved = read('profile', {});
    return Object.assign({}, DEFAULT_PROFILE, saved && typeof saved === 'object' ? saved : {});
  }
  function saveProfile(patch) { const next = Object.assign(getProfile(), patch); write('profile', next); emit('profile', next); return next; }

  /* ----------------------- Último estado do player -------------------------- */

  function getPlayerState() { const s = read('player', null); return s && typeof s === 'object' ? s : null; }
  function savePlayerState(s) { write('player', s); }

  IMusic.Storage = {
    LIMITS, on, setResolver,
    getFavorites, isFavorite, toggleFavorite, clearFavorites,
    getHistory, addToHistory, clearHistory,
    getSearches, addSearch, clearSearches,
    getPlaylists, getPlaylist, createPlaylist, renamePlaylist, deletePlaylist,
    addToPlaylist, addManyToPlaylist, removeFromPlaylist, moveInPlaylist, isTrackInPlaylist,
    getSettings, saveSettings,
    getProfile, saveProfile,
    getPlayerState, savePlayerState,
  };
})(window);
