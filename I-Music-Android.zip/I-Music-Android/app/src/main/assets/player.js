/**
 * I-Music · player.js
 * Motor de reprodução: elemento <audio>, fila, aleatório, repetição, volume,
 * tratamento de ficheiros em falta e integração com os controles do sistema
 * (Media Session: tela de bloqueio, teclas de mídia, fones).
 *
 * O Player não conhece a interface. Ele avisa o que aconteceu por eventos:
 *   trackchange · state · time · queue · modes · volume · started · error · blocked
 */
(function (global) {
  'use strict';

  const IMusic = (global.IMusic = global.IMusic || {});
  const Library = IMusic.Library;
  const Storage = IMusic.Storage;

  const audio = new Audio();
  audio.preload = 'auto';
  // Sem crossOrigin de propósito: o equalizador (abaixo) só filtra o áudio,
  // nunca lê as amostras em JavaScript, então não precisa de CORS — e exigir
  // CORS aqui quebraria a reprodução em fontes que não enviam esse cabeçalho.

  /* -------------------------------- Equalizador ------------------------------
   * 3 bandas (graves/médios/agudos) via Web Audio API (BiquadFilterNode),
   * encadeadas entre o <audio> e a saída. Só é montado na primeira reprodução
   * (precisa de um gesto do usuário para o AudioContext ligar em vários
   * navegadores) e continua ativo depois disso. */
  const EQ_PRESETS = {
    flat: { bass: 0, mid: 0, treble: 0 },
    bass: { bass: 7, mid: 1, treble: -1 },
    treble: { bass: -1, mid: 0, treble: 7 },
    vocal: { bass: -3, mid: 5, treble: 2 },
    rock: { bass: 4, mid: -2, treble: 3 },
    pop: { bass: 2, mid: 1, treble: 3 },
    loudness: { bass: 5, mid: -1, treble: 4 },
  };
  const eqState = { preset: 'flat', bands: Object.assign({}, EQ_PRESETS.flat) };
  let eqGraph = null; // { ctx, bassFilter, midFilter, trebleFilter }
  let eqGraphAttempted = false; // só tenta montar o grafo uma vez (evita recriar AudioContext à toa)

  /** Navegadores embutidos (Messenger, Instagram, TikTok, WeChat, Line etc.)
   *  costumam ter suporte quebrado a Web Audio API: o AudioContext nunca sai
   *  do estado "suspended" e a música fica muda quando o <audio> é roteado
   *  por ele. Nesses casos o equalizador simplesmente não é ativado — a
   *  reprodução normal continua funcionando, só sem o efeito de EQ. */
  function isRiskyInAppBrowser() {
    try {
      const ua = navigator.userAgent || '';
      return /FBAN|FBAV|Instagram|Line\/|MicroMessenger|TikTok|BytedanceWebview|Twitter/i.test(ua);
    } catch (_) { return false; }
  }

  /** Monta o grafo de Web Audio SOMENTE quando é realmente preciso (o usuário
   *  está mexendo no equalizador agora). Enquanto ninguém toca no
   *  equalizador nesta sessão, o <audio> continua tocando pelo caminho
   *  normal do navegador, sem passar pela Web Audio API — assim um eventual
   *  problema ao montar o grafo (navegador embutido, sem suporte, política
   *  de autoplay etc.) nunca derruba a reprodução em si.
   *  política de autoplay etc.) nunca derruba a reprodução em si. */
  function ensureEqGraph() {
    if (eqGraph || eqGraphAttempted) return eqGraph;
    eqGraphAttempted = true;
    if (isRiskyInAppBrowser()) return null;
    try {
      const Ctx = global.AudioContext || global.webkitAudioContext;
      if (!Ctx) return null;
      const ctx = new Ctx();
      const source = ctx.createMediaElementSource(audio);
      try {
        const bassFilter = ctx.createBiquadFilter();
        bassFilter.type = 'lowshelf';
        bassFilter.frequency.value = 200;
        const midFilter = ctx.createBiquadFilter();
        midFilter.type = 'peaking';
        midFilter.frequency.value = 1000;
        midFilter.Q.value = 0.9;
        const trebleFilter = ctx.createBiquadFilter();
        trebleFilter.type = 'highshelf';
        trebleFilter.frequency.value = 3500;
        source.connect(bassFilter).connect(midFilter).connect(trebleFilter).connect(ctx.destination);
        eqGraph = { ctx, bassFilter, midFilter, trebleFilter };
        applyEqGains();
      } catch (_) {
        // Os filtros falharam depois que a fonte já foi criada: liga direto
        // no destino pra não perder o som (só fica sem efeito de EQ).
        try { source.connect(ctx.destination); } catch (_) { /* nada mais a fazer */ }
      }
    } catch (_) {
      eqGraph = null; // navegador sem suporte, ou grafo já existia: toca sem EQ
    }
    return eqGraph;
  }

  function applyEqGains() {
    if (!eqGraph) return;
    const b = eqState.bands;
    eqGraph.bassFilter.gain.value = clamp(Number(b.bass) || 0, -12, 12);
    eqGraph.midFilter.gain.value = clamp(Number(b.mid) || 0, -12, 12);
    eqGraph.trebleFilter.gain.value = clamp(Number(b.treble) || 0, -12, 12);
  }

  /** Chamado a cada início/retomada de reprodução. Só reconecta o Web Audio
   *  se o grafo já foi criado NESTA sessão (ou seja, o usuário já abriu o
   *  equalizador e mexeu em algo) — uma preferência de EQ salva de uma
   *  sessão anterior nunca liga o Web Audio sozinha num carregamento novo
   *  da página, o que elimina o risco de silêncio para quem só toca música. */
  function resumeEqContext() {
    if (!eqGraph) return;
    if (eqGraph.ctx.state === 'suspended') eqGraph.ctx.resume().catch(() => {});
  }

  function getEqAvailable() {
    return !isRiskyInAppBrowser();
  }

  function setEqPreset(name) {
    const preset = EQ_PRESETS[name] ? name : 'flat';
    eqState.preset = preset;
    eqState.bands = Object.assign({}, EQ_PRESETS[preset]);
    if (preset !== 'flat') {
      const g = ensureEqGraph();
      if (g && g.ctx.state === 'suspended') g.ctx.resume().catch(() => {});
    }
    applyEqGains();
    Storage.saveSettings({ eq: { preset: eqState.preset, bands: eqState.bands } });
    emit('eq');
  }

  function setEqBand(band, value) {
    if (!['bass', 'mid', 'treble'].includes(band)) return;
    eqState.preset = 'custom';
    eqState.bands = Object.assign({}, eqState.bands, { [band]: clamp(Number(value) || 0, -12, 12) });
    const g = ensureEqGraph();
    if (g && g.ctx.state === 'suspended') g.ctx.resume().catch(() => {});
    applyEqGains();
    Storage.saveSettings({ eq: { preset: eqState.preset, bands: eqState.bands } });
    emit('eq');
  }

  function getEqState() {
    return { preset: eqState.preset, bands: Object.assign({}, eqState.bands), presets: Object.keys(EQ_PRESETS), available: getEqAvailable() };
  }

  const state = {
    queue: [],        // faixas na ordem de exibição (sem repetidas)
    index: -1,        // posição da faixa atual na fila
    current: null,
    playing: false,   // intenção de tocar (otimista enquanto carrega)
    buffering: false,
    shuffle: false,
    repeat: 'off',    // off | all | one
    volume: 0.8,
    muted: false,
  };

  let playedIds = new Set(); // ids já tocados no ciclo atual (aleatório)
  let historyIds = [];       // pilha para "anterior" no modo aleatório
  let errorStreak = 0;       // falhas seguidas (evita loop infinito)
  let loadToken = 0;         // evita corridas ao trocar de faixa depressa
  let currentUrl = null;     // blob: da faixa atual (revogado ao trocar)
  let pendingSeek = 0;       // posição a aplicar quando a faixa carregar (restaurar sessão)
  let saveTimer = 0;
  let startedFor = null;     // id da faixa que já disparou 'started'

  const listeners = {};

  /* ------------------------------- Eventos --------------------------------- */

  function on(name, fn) {
    (listeners[name] = listeners[name] || []).push(fn);
  }

  function emit(name, payload) {
    (listeners[name] || []).forEach((fn) => {
      try { fn(payload); } catch (err) { console.error('[player]', err); }
    });
  }

  const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

  /* ------------------------------ Inicialização ---------------------------- */

  function init() {
    const s = Storage.getSettings();
    state.volume = clamp(Number(s.volume), 0, 1);
    if (Number.isNaN(state.volume)) state.volume = 0.8;
    state.shuffle = !!s.shuffle;
    state.repeat = ['off', 'all', 'one'].includes(s.repeat) ? s.repeat : 'off';

    audio.volume = state.volume;
    audio.loop = state.repeat === 'one';

    if (s.eq && EQ_PRESETS[s.eq.preset]) {
      eqState.preset = s.eq.preset;
      eqState.bands = Object.assign({}, EQ_PRESETS[s.eq.preset]);
    } else if (s.eq && s.eq.preset === 'custom' && s.eq.bands) {
      eqState.preset = 'custom';
      eqState.bands = Object.assign({}, EQ_PRESETS.flat, s.eq.bands);
    }

    bindAudioEvents();
    bindMediaSession();

    emit('volume');
    emit('modes');
    emit('state');
    emit('eq');
  }

  function bindAudioEvents() {
    audio.addEventListener('playing', () => {
      state.playing = true;
      state.buffering = false;
      errorStreak = 0;
      setMediaPlaybackState('playing');
      if (state.current && startedFor !== state.current.id) {
        startedFor = state.current.id;
        emit('started', state.current);
      }
      emit('state');
    });
    audio.addEventListener('pause', () => { state.playing = false; setMediaPlaybackState('paused'); emit('state'); });
    audio.addEventListener('waiting', () => { state.buffering = true; emit('state'); });
    audio.addEventListener('canplay', () => { if (state.buffering) { state.buffering = false; emit('state'); } });
    audio.addEventListener('timeupdate', () => { emit('time'); schedulePersist(); });
    audio.addEventListener('loadedmetadata', () => {
      if (pendingSeek > 0) { try { audio.currentTime = pendingSeek; } catch (_) { /* ok */ } pendingSeek = 0; }
      emit('time');
    });
    audio.addEventListener('durationchange', () => { emit('time'); updatePositionState(); });
    audio.addEventListener('seeked', updatePositionState);
    audio.addEventListener('ended', () => { next({ auto: true }); });
    audio.addEventListener('error', handleAudioError);
  }

  /* ------------------------------ Reproduzir música ------------------------ */

  /** Toca a faixa indicada e atualiza todo o estado */
  function startTrack(track, { autoplay = true, seek = 0 } = {}) {
    state.current = track;
    playedIds.add(track.id);
    state.playing = autoplay;
    state.buffering = true;
    pendingSeek = seek;
    const token = ++loadToken;

    emit('trackchange', track);
    emit('state');
    updateMediaSession(track);

    Library.getUrl(track).then((url) => {
      if (token !== loadToken) { URL.revokeObjectURL(url); return; }
      const old = currentUrl;
      currentUrl = url;
      audio.src = url;
      if (old) URL.revokeObjectURL(old);
      resumeEqContext();
      if (!autoplay) { state.playing = false; state.buffering = false; emit('state'); return; }
      const p = audio.play();
      if (p && p.catch) p.catch(handlePlayRejection);
    }).catch((err) => {
      if (token !== loadToken) return;
      if (err && err.code === 'missing') Library.markMissing(track.id);
      fail(track, (err && err.code) || 'read');
    });
  }

  function handlePlayRejection(err) {
    if (!err || err.name === 'AbortError') return; // troca rápida de faixa
    if (err.name === 'NotAllowedError') {          // navegador bloqueou o autoplay
      state.playing = false;
      state.buffering = false;
      emit('state');
      emit('blocked');
    }
    // NotSupportedError também dispara o evento 'error' do <audio>, tratado abaixo
  }

  function handleAudioError() {
    const track = state.current;
    if (!track || !audio.getAttribute('src')) return;
    if (audio.error && audio.error.code === 1) return; // MEDIA_ERR_ABORTED
    fail(track, 'decode');
  }

  /** Falha definitiva: avisa a interface e pula para a próxima, se houver */
  function fail(track, kind) {
    state.playing = false;
    state.buffering = false;
    errorStreak += 1;

    const nextIdx = errorStreak < state.queue.length && kind !== 'permission' ? pickNextIndex(true) : -1;
    emit('error', { track, kind, willSkip: nextIdx !== -1 });
    emit('state');
    if (nextIdx !== -1) playAt(nextIdx);
  }

  /* ---------------------------------- Fila --------------------------------- */

  /** Define a fila (sem repetidas e só com faixas que têm stream) e começa a tocar */
  function setQueue(tracks, startIndex = 0) {
    const startId = tracks[startIndex] ? tracks[startIndex].id : null;
    const seen = new Set();
    const queue = [];
    tracks.forEach((t) => {
      if (t && !t.missing && !seen.has(t.id)) { seen.add(t.id); queue.push(t); }
    });
    if (!queue.length) return false;

    state.queue = queue;
    playedIds = new Set();
    historyIds = [];
    errorStreak = 0;
    emit('queue');

    playAt(Math.max(0, queue.findIndex((t) => t.id === startId)), { record: false });
    return true;
  }

  function playAt(index, { record = true } = {}) {
    const track = state.queue[index];
    if (!track) return;
    if (record && state.current && state.current.id !== track.id) {
      historyIds.push(state.current.id);
      if (historyIds.length > 100) historyIds.shift();
    }
    state.index = index;
    startTrack(track);
  }

  function addToQueue(track) {
    if (state.queue.some((t) => t.id === track.id)) return 'exists';
    state.queue = state.queue.concat(track);
    emit('queue');
    return 'added';
  }

  function removeFromQueue(id) {
    const i = state.queue.findIndex((t) => t.id === id);
    if (i === -1) return;

    const removingCurrent = !!state.current && state.current.id === id;
    state.queue = state.queue.filter((t) => t.id !== id);
    historyIds = historyIds.filter((h) => h !== id);
    if (i < state.index) state.index -= 1;
    emit('queue');

    if (!removingCurrent) return;
    if (state.queue.length) {
      playAt(Math.min(i, state.queue.length - 1), { record: false });
    } else {
      stop();
    }
  }

  /** Esvazia a fila, mantendo apenas a faixa que está tocando */
  function clearQueue() {
    state.queue = state.current ? [state.current] : [];
    state.index = state.current ? 0 : -1;
    playedIds = new Set(state.current ? [state.current.id] : []);
    historyIds = [];
    emit('queue');
  }

  function stop() {
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    if (currentUrl) { URL.revokeObjectURL(currentUrl); currentUrl = null; }
    loadToken++;
    state.current = null;
    state.index = -1;
    state.playing = false;
    state.buffering = false;
    setMediaPlaybackState('none');
    emit('trackchange', null);
    emit('state');
    emit('time');
  }

  /* ------------------------------- Navegação ------------------------------- */

  function pickNextIndex(auto) {
    const n = state.queue.length;
    if (!n) return -1;
    const canWrap = state.repeat === 'all' || !auto;

    if (state.shuffle) {
      const currentId = state.current ? state.current.id : null;
      let pool = [];
      state.queue.forEach((t, i) => { if (!playedIds.has(t.id)) pool.push(i); });
      if (!pool.length) {
        if (!canWrap) return -1;
        playedIds = new Set(currentId ? [currentId] : []); // novo ciclo
        state.queue.forEach((t, i) => { if (!playedIds.has(t.id)) pool.push(i); });
        if (!pool.length) return n === 1 ? 0 : -1;
      }
      return pool[Math.floor(Math.random() * pool.length)];
    }

    const i = state.index + 1;
    if (i < n) return i;
    return canWrap ? 0 : -1;
  }

  function next({ auto = false } = {}) {
    const idx = pickNextIndex(auto);
    if (idx === -1) {
      if (auto) { state.playing = false; emit('state'); }
      return false;
    }
    playAt(idx);
    return true;
  }

  function prev() {
    if (!state.current) return;
    // Depois de 3 segundos, "anterior" reinicia a música (como nos apps de música)
    if (audio.currentTime > 3 || state.queue.length < 2) { audio.currentTime = 0; return; }

    if (state.shuffle) {
      while (historyIds.length) {
        const id = historyIds.pop();
        const i = state.queue.findIndex((t) => t.id === id);
        if (i !== -1 && id !== state.current.id) { playAt(i, { record: false }); return; }
      }
      audio.currentTime = 0;
      return;
    }

    const i = state.index - 1;
    if (i >= 0) playAt(i, { record: false });
    else if (state.repeat === 'all') playAt(state.queue.length - 1, { record: false });
    else audio.currentTime = 0;
  }

  /* ------------------------------- Controles ------------------------------- */

  function play() {
    if (!state.current) {
      if (state.queue.length) playAt(0, { record: false });
      return;
    }
    if (audio.error || !audio.getAttribute('src')) { startTrack(state.current, { seek: audio.currentTime || 0 }); return; }
    resumeEqContext();
    const p = audio.play();
    if (p && p.catch) p.catch(handlePlayRejection);
  }

  function pause() { audio.pause(); }

  function toggle() { if (state.playing) pause(); else play(); }

  function getDuration() {
    if (Number.isFinite(audio.duration) && audio.duration > 0) return audio.duration;
    return state.current ? state.current.dur || 0 : 0;
  }

  function getTime() {
    return { current: audio.currentTime || 0, duration: getDuration() };
  }

  function seek(seconds) {
    const dur = getDuration();
    if (!dur) return;
    audio.currentTime = clamp(seconds, 0, dur);
  }

  function seekRatio(ratio) { seek(clamp(ratio, 0, 1) * getDuration()); }

  function setVolume(v) {
    state.volume = clamp(v, 0, 1);
    audio.volume = state.volume;
    if (state.volume > 0 && state.muted) { state.muted = false; audio.muted = false; }
    Storage.saveSettings({ volume: state.volume });
    emit('volume');
  }

  function toggleMute() {
    if (state.volume === 0) { setVolume(0.5); return; } // volume zerado: "reativar" sobe para 50%
    state.muted = !state.muted;
    audio.muted = state.muted;
    emit('volume');
  }

  function setShuffle(value) {
    state.shuffle = !!value;
    playedIds = new Set(state.current ? [state.current.id] : []);
    Storage.saveSettings({ shuffle: state.shuffle });
    emit('modes');
  }

  function toggleShuffle() { setShuffle(!state.shuffle); }

  function cycleRepeat() {
    state.repeat = state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off';
    audio.loop = state.repeat === 'one';
    Storage.saveSettings({ repeat: state.repeat });
    emit('modes');
  }

  /* ------------------------------ Media Session ---------------------------- */

  function bindMediaSession() {
    if (!('mediaSession' in navigator)) return;
    const set = (action, fn) => { try { navigator.mediaSession.setActionHandler(action, fn); } catch (_) { /* não suportado */ } };
    set('play', () => play());
    set('pause', () => pause());
    set('stop', () => stop());
    set('previoustrack', () => prev());
    set('nexttrack', () => next());
    set('seekto', (d) => { if (d && typeof d.seekTime === 'number') seek(d.seekTime); });
  }

  /** Define explicitamente o estado de reprodução na Media Session. Vários
   *  navegadores móveis (sobretudo em PWA instalada) só mostram os controles
   *  na tela de bloqueio / central de controle quando este estado é definido
   *  manualmente — não basta o <audio> estar tocando. */
  function setMediaPlaybackState(value) {
    if (!('mediaSession' in navigator)) return;
    try { navigator.mediaSession.playbackState = value; } catch (_) { /* ignora */ }
  }

  function updateMediaSession(track) {
    if (!('mediaSession' in navigator) || !track || typeof MediaMetadata === 'undefined') return;
    const apply = (artwork) => {
      if (state.current !== track) return;
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: track.title, artist: track.artistName || track.artist, album: track.albumName || track.album || 'I-Music', artwork,
        });
      } catch (_) { /* ignora */ }
    };
    apply([{ src: 'icon-512.png', sizes: '512x512', type: 'image/png' }]);
    if (track.cover) Library.coverUrl(track.cover).then((u) => { if (u) apply([{ src: u, sizes: '420x420', type: 'image/jpeg' }]); });
  }

  function updatePositionState() {
    if (!('mediaSession' in navigator) || !navigator.mediaSession.setPositionState) return;
    const duration = getDuration();
    if (!duration) return;
    try {
      navigator.mediaSession.setPositionState({ duration, position: clamp(audio.currentTime || 0, 0, duration), playbackRate: 1 });
    } catch (_) { /* ignora */ }
  }

  /* ------------------------- Guardar / restaurar sessão ---------------------- */

  function persistNow() {
    clearTimeout(saveTimer); saveTimer = 0;
    if (!state.current) { Storage.savePlayerState(null); return; }
    Storage.savePlayerState({ ids: state.queue.map((t) => t.id), id: state.current.id, time: audio.currentTime || 0 });
  }

  function schedulePersist() { if (!saveTimer) saveTimer = setTimeout(persistNow, 4000); }

  /** Repõe a última fila e a posição (sem tocar) ao abrir o app */
  function restore() {
    const saved = Storage.getPlayerState();
    if (!saved || !Array.isArray(saved.ids)) return false;
    const tracks = saved.ids.map((id) => Library.get(id)).filter(Boolean);
    const idx = tracks.findIndex((t) => t.id === saved.id);
    if (!tracks.length || idx < 0) return false;
    state.queue = tracks;
    playedIds = new Set([saved.id]);
    historyIds = [];
    emit('queue');
    state.index = idx;
    startTrack(tracks[idx], { autoplay: false, seek: Number(saved.time) || 0 });
    return true;
  }

  /** Tira uma música da fila (ex.: apagada da biblioteca) */
  function dropTrack(id) { if (state.queue.some((t) => t.id === id)) removeFromQueue(id); }

  global.addEventListener('pagehide', persistNow);
  document.addEventListener('visibilitychange', () => { if (document.hidden) persistNow(); });

  /* --------------------------------- Público ------------------------------- */

  IMusic.Player = {
    on, init,
    setQueue, playAt, addToQueue, removeFromQueue, clearQueue,
    play, pause, toggle, next, prev,
    seek, seekRatio, getTime,
    setVolume, toggleMute,
    setShuffle, toggleShuffle, cycleRepeat,
    setEqPreset, setEqBand, getEqState,
    restore, dropTrack, stop,
    getState: () => Object.assign({}, state),
  };
})(window);
