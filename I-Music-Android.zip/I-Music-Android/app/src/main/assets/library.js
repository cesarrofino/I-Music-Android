/**
 * I-Music · library.js
 * Biblioteca de músicas do próprio telemóvel.
 *
 * Como as músicas entram:
 *  1) Pasta (recomendado): o utilizador escolhe UMA vez a pasta de músicas
 *     (ex.: "Music" / "Download"). O app guarda a permissão e, em cada abertura,
 *     volta a percorrer a pasta sozinho, adicionando músicas novas e removendo as
 *     apagadas. Os ficheiros NÃO são copiados: tocam diretamente da pasta.
 *     Usa a File System Access API (showDirectoryPicker).
 *  2) Ficheiros: escolha manual de ficheiros ou de uma pasta pelo seletor padrão
 *     (plano B quando o navegador não suporta showDirectoryPicker). Aqui o
 *     navegador não guarda acesso ao original, por isso uma cópia fica guardada
 *     no próprio app (IndexedDB).
 *
 * No app Android nativo (window.AndroidNative) as músicas vêm do MediaStore do sistema.
 */
(function (global) {
  'use strict';

  const IMusic = (global.IMusic = global.IMusic || {});
  const Storage = IMusic.Storage;

  /* ------------------------------- Utilitários ------------------------------ */

  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const hash = (s) => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; return h.toString(36); };
  const ascii = (b, s, l) => { let r = ''; for (let i = s; i < s + l && i < b.length; i++) r += String.fromCharCode(b[i]); return r; };
  const tick = () => new Promise((r) => setTimeout(r, 0));
  const coll = new Intl.Collator('pt', { numeric: true, sensitivity: 'base' });
  const AUDIO_RE = /\.(mp3|m4a|aac|wav|ogg|oga|opus|flac|wma|amr|mka|weba)$/i;
  const MIME = { mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', flac: 'audio/flac', weba: 'audio/webm' };
  const isAudioName = (n) => AUDIO_RE.test(n);
  const mimeOf = (n) => MIME[(n.split('.').pop() || '').toLowerCase()] || 'audio/mpeg';
  const COVER_NAMES = ['cover', 'folder', 'album', 'albumart', 'albumartsmall', 'front', 'artwork'];
  const COVER_EXT = ['jpg', 'jpeg', 'png', 'webp'];

  const listeners = {};
  function on(name, fn) { (listeners[name] = listeners[name] || []).push(fn); }
  function emit(name, payload) { (listeners[name] || []).forEach((fn) => { try { fn(payload); } catch (e) { console.error('[library]', e); } }); }

  /* --------------------------- Leitura de metadados -------------------------- */

/* ================= metadata parsers ================= */
async function readSlice(f, s, l) { return new Uint8Array(await f.slice(s, s + l).arrayBuffer()); }
const syncsafe = (b, p) => ((b[p] & 127) << 21) | ((b[p + 1] & 127) << 14) | ((b[p + 2] & 127) << 7) | (b[p + 3] & 127);
function txt(d) {
  if (!d.length) return '';
  const e = d[0], b = d.subarray(1); let s = '';
  try {
    if (e === 0) { try { s = new TextDecoder('utf-8', { fatal: true }).decode(b); } catch (_) { s = new TextDecoder('windows-1252').decode(b); } }
    else if (e === 1) {
      if (b[0] === 0xFE && b[1] === 0xFF) s = new TextDecoder('utf-16be').decode(b.subarray(2));
      else if (b[0] === 0xFF && b[1] === 0xFE) s = new TextDecoder('utf-16le').decode(b.subarray(2));
      else s = new TextDecoder('utf-16le').decode(b);
    } else if (e === 2) s = new TextDecoder('utf-16be').decode(b);
    else s = new TextDecoder('utf-8').decode(b);
  } catch (_) { s = ''; }
  return s.split('\0')[0].trim();
}
function parseAPIC(d, v2) {
  const enc = d[0]; let p = 1, mime;
  if (v2) { mime = 'image/' + ascii(d, p, 3).toLowerCase().replace('jpg', 'jpeg'); p += 3; }
  else { const e = d.indexOf(0, p); mime = ascii(d, p, e - p) || 'image/jpeg'; if (mime === 'image/jpg') mime = 'image/jpeg'; p = e + 1; }
  p++;
  if (enc === 1 || enc === 2) { while (p + 1 < d.length && !(d[p] === 0 && d[p + 1] === 0)) p += 2; p += 2; }
  else { while (p < d.length && d[p] !== 0) p++; p++; }
  if (p >= d.length) return null;
  return new Blob([d.slice(p)], { type: mime });
}
async function parseID3v1(f) {
  if (f.size < 128) return {};
  const b = await readSlice(f, f.size - 128, 128);
  if (ascii(b, 0, 3) !== 'TAG') return {};
  const s = (a, l) => ascii(b, a, l).replace(/\0.*$/, '').trim();
  return { title: s(3, 30), artist: s(33, 30), album: s(63, 30) };
}
async function parseID3(f) {
  const h = await readSlice(f, 0, 10);
  if (ascii(h, 0, 3) !== 'ID3') return parseID3v1(f);
  const ver = h[3], flags = h[5], size = syncsafe(h, 6);
  const buf = await readSlice(f, 10, Math.min(size, 12 * 1024 * 1024));
  let p = 0; const out = {};
  if ((flags & 0x40) && ver >= 3) p = ver === 4 ? syncsafe(buf, 0) : ((buf[0] << 24 | buf[1] << 16 | buf[2] << 8 | buf[3]) + 4);
  const v2 = ver === 2;
  while (p + (v2 ? 6 : 10) <= buf.length) {
    let id, fsz;
    if (v2) { id = ascii(buf, p, 3); fsz = (buf[p + 3] << 16) | (buf[p + 4] << 8) | buf[p + 5]; p += 6; }
    else { id = ascii(buf, p, 4); fsz = ver === 4 ? syncsafe(buf, p + 4) : (buf[p + 4] * 16777216 + (buf[p + 5] << 16) + (buf[p + 6] << 8) + buf[p + 7]); p += 10; }
    if (!id || id.charCodeAt(0) === 0 || fsz <= 0 || p + fsz > buf.length) break;
    const d = buf.subarray(p, p + fsz); p += fsz;
    switch (id) {
      case 'TIT2': case 'TT2': out.title = txt(d); break;
      case 'TPE1': case 'TP1': out.artist = txt(d); break;
      case 'TALB': case 'TAL': out.album = txt(d); break;
      case 'TPE2': case 'TP2': out.albumArtist = txt(d); break;
      case 'TRCK': case 'TRK': out.no = parseInt(txt(d), 10) || 0; break;
      case 'APIC': case 'PIC': if (!out.cover) { try { out.cover = parseAPIC(d, v2); } catch (_) {} } break;
    }
  }
  if (!out.title && !out.artist) { const v1 = await parseID3v1(f); return Object.assign(v1, out); }
  return out;
}
function boxes(buf, s, e) {
  const r = []; let p = s;
  while (p + 8 <= e) {
    let len = ((buf[p] << 24) | (buf[p + 1] << 16) | (buf[p + 2] << 8) | buf[p + 3]) >>> 0;
    const t = ascii(buf, p + 4, 4); let hl = 8;
    if (len === 1) { hl = 16; len = Number(new DataView(buf.buffer, buf.byteOffset + p + 8, 8).getBigUint64(0)); }
    if (len < hl || p + len > e) break;
    r.push({ t, s: p + hl, e: p + len }); p += len;
  }
  return r;
}
function readMoov(buf, out) {
  const udta = boxes(buf, 0, buf.length).find(b => b.t === 'udta'); if (!udta) return;
  const meta = boxes(buf, udta.s, udta.e).find(b => b.t === 'meta'); if (!meta) return;
  const ilst = boxes(buf, meta.s + 4, meta.e).find(b => b.t === 'ilst'); if (!ilst) return;
  for (const it of boxes(buf, ilst.s, ilst.e)) {
    const dt = boxes(buf, it.s, it.e).find(b => b.t === 'data'); if (!dt) continue;
    const pl = buf.subarray(dt.s + 8, dt.e), u8 = () => new TextDecoder('utf-8').decode(pl).trim();
    switch (it.t) {
      case '\xa9nam': out.title = u8(); break;
      case '\xa9ART': out.artist = u8(); break;
      case '\xa9alb': out.album = u8(); break;
      case 'aART': out.albumArtist = u8(); break;
      case 'trkn': out.no = (pl[2] << 8) | pl[3]; break;
      case 'covr': if (!out.cover && pl.length > 8) out.cover = new Blob([pl.slice()], { type: buf[dt.s + 3] === 14 ? 'image/png' : 'image/jpeg' }); break;
    }
  }
}
async function parseMP4(f) {
  let pos = 0; const out = {};
  while (pos + 8 <= f.size) {
    const h = await readSlice(f, pos, 16);
    let len = ((h[0] << 24) | (h[1] << 16) | (h[2] << 8) | h[3]) >>> 0; const t = ascii(h, 4, 4); let hl = 8;
    if (len === 1) { len = Number(new DataView(h.buffer).getBigUint64(8)); hl = 16; } else if (len === 0) len = f.size - pos;
    if (len < hl) break;
    if (t === 'moov') { if (len > 48 * 1024 * 1024) break; readMoov(await readSlice(f, pos + hl, len - hl), out); break; }
    pos += len;
  }
  return out;
}
async function parseFLAC(f) {
  const out = {}; let pos = 4;
  for (let i = 0; i < 64; i++) {
    const bh = await readSlice(f, pos, 4); if (bh.length < 4) break;
    const last = bh[0] & 128, type = bh[0] & 127, len = (bh[1] << 16) | (bh[2] << 8) | bh[3]; pos += 4;
    if (type === 4) {
      const d = await readSlice(f, pos, Math.min(len, 1 << 20)), dv = new DataView(d.buffer);
      let p = 4 + dv.getUint32(0, true); const n = dv.getUint32(p, true); p += 4;
      for (let k = 0; k < n && p + 4 <= d.length; k++) {
        const l = dv.getUint32(p, true); p += 4;
        const s = new TextDecoder().decode(d.subarray(p, p + l)); p += l;
        const eq = s.indexOf('='); if (eq < 1) continue;
        const key = s.slice(0, eq).toUpperCase(), val = s.slice(eq + 1);
        if (key === 'TITLE') out.title = val; else if (key === 'ARTIST') out.artist = val; else if (key === 'ALBUM') out.album = val;
        else if (key === 'ALBUMARTIST') out.albumArtist = val; else if (key === 'TRACKNUMBER') out.no = parseInt(val, 10) || 0;
      }
    } else if (type === 6 && len < 12 * 1024 * 1024 && !out.cover) {
      const d = await readSlice(f, pos, len), dv = new DataView(d.buffer);
      let p = 4; const ml = dv.getUint32(p); p += 4; const mime = ascii(d, p, ml); p += ml;
      p += 4 + dv.getUint32(p); p += 16; const pl = dv.getUint32(p); p += 4;
      out.cover = new Blob([d.slice(p, p + pl)], { type: mime || 'image/jpeg' });
    }
    pos += len; if (last) break;
  }
  return out;
}
async function readMeta(f) {
  try {
    const h = await readSlice(f, 0, 12);
    if (ascii(h, 0, 3) === 'ID3') return await parseID3(f);
    if (ascii(h, 0, 4) === 'fLaC') return await parseFLAC(f);
    if (ascii(h, 4, 4) === 'ftyp') return await parseMP4(f);
    if (/\.mp3$/i.test(f.name)) return await parseID3v1(f);
  } catch (_) {}
  return {};
}
function fromName(name) {
  let b = name.replace(/\.[^.]+$/, '').replace(/_/g, ' ').trim(), no = 0;
  const m = b.match(/^(\d{1,3})[\s.\-)]+(?=\S)/); if (m) { no = +m[1]; b = b.slice(m[0].length); }
  const i = b.indexOf(' - ');
  return i > 0 ? { artist: b.slice(0, i).trim(), title: b.slice(i + 3).trim(), no } : { title: b, artist: '', no };
}

  async function shrink(blob) {
    try {
      const bmp = await createImageBitmap(blob);
      const sc = Math.min(1, 420 / Math.max(bmp.width, bmp.height));
      const w = Math.max(1, Math.round(bmp.width * sc)), h = Math.max(1, Math.round(bmp.height * sc));
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      c.getContext('2d').drawImage(bmp, 0, 0, w, h); if (bmp.close) bmp.close();
      return await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.82));
    } catch (_) { return null; }
  }

  /** Duração real pelo próprio navegador (também valida se o ficheiro toca). -1 = ilegível */
  function getDuration(file) {
    return new Promise((res) => {
      const u = URL.createObjectURL(file), a = new Audio(); a.preload = 'metadata'; let fin = false;
      const end = (v) => { if (fin) return; fin = true; clearTimeout(tm); a.removeAttribute('src'); try { a.load(); } catch (_) {} URL.revokeObjectURL(u); res(v); };
      const tm = setTimeout(() => end(-1), 12000);
      a.onloadedmetadata = () => end(isFinite(a.duration) ? a.duration : 0);
      a.onerror = () => end(-1);
      a.src = u;
    });
  }

  /* --------------------------------- Base local ------------------------------ */

  const req = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const txDone = (t) => new Promise((res, rej) => { t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
  let db = null;

  function openDb() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('imusic-lib', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('tracks', { keyPath: 'id' });
        d.createObjectStore('covers');
        d.createObjectStore('roots', { keyPath: 'id' });
        d.createObjectStore('files');
      };
      r.onsuccess = () => { db = r.result; res(); };
      r.onerror = () => rej(r.error);
    });
  }
  const dbGetAll = (s) => req(db.transaction(s).objectStore(s).getAll());
  const dbGet = (s, k) => req(db.transaction(s).objectStore(s).get(k));
  const dbKeys = (s) => req(db.transaction(s).objectStore(s).getAllKeys());
  function dbPut(s, v, k) { const t = db.transaction(s, 'readwrite'); t.objectStore(s).put(v, k); return txDone(t); }
  function dbDel(s, k) { const t = db.transaction(s, 'readwrite'); t.objectStore(s).delete(k); return txDone(t); }
  function dbPutMany(s, list) { const t = db.transaction(s, 'readwrite'); const st = t.objectStore(s); list.forEach((v) => st.put(v)); return txDone(t); }
  function dbClear(stores) { const t = db.transaction(stores, 'readwrite'); stores.forEach((s) => t.objectStore(s).clear()); return txDone(t); }

  /* ---------------------------------- Estado --------------------------------- */

  const T = new Map();          // id -> registo da música
  const roots = new Map();      // id -> { id, name, handle }
  const coverIds = new Set();   // capas existentes
  const status = { scanning: false, cancel: false, done: 0, total: 0, found: 0, needsPermission: false, lastScan: 0, phase: '' };
  let version = 0;
  let cache = null;
  let scanChain = Promise.resolve();

  const NATIVE = global.AndroidNative || null;
  const hasPicker = !!NATIVE || typeof global.showDirectoryPicker === 'function';

  function prep(t) {
    const parts = (t.folder || '').split('/');
    t.folderName = parts[parts.length - 1] || t.folder || 'Importados';
    t.artistName = t.artist || 'Artista desconhecido';
    t.albumName = t.album || (t.src === 'dir' && parts.length > 1 ? t.folderName : '') || 'Álbum desconhecido';
    t._s = norm(`${t.title} ${t.artist} ${t.album} ${t.name}`);
    return t;
  }
  function touch() { version += 1; cache = null; }

  /* ---------------------------------- Capas ---------------------------------- */

  const coverUrls = new Map(); // coverId -> object URL (limitado)
  const COVER_LIMIT = 400;

  async function coverUrl(coverId) {
    if (!coverId) return '';
    if (String(coverId).indexOf('n:') === 0) return global.location.origin + '/native-cover/' + coverId.slice(2);
    let u = coverUrls.get(coverId);
    if (u) { coverUrls.delete(coverId); coverUrls.set(coverId, u); return u; }
    try {
      const blob = await dbGet('covers', coverId);
      if (!blob) return '';
      u = URL.createObjectURL(blob);
      coverUrls.set(coverId, u);
      if (coverUrls.size > COVER_LIMIT) {
        const first = coverUrls.keys().next().value;
        const old = coverUrls.get(first); coverUrls.delete(first);
        setTimeout(() => URL.revokeObjectURL(old), 30000);
      }
      return u;
    } catch (_) { return ''; }
  }

  /** Carrega a capa local de uma música para um <img>. Sem capa: onFail. */
  function loadCover(img, track, hooks) {
    hooks = hooks || {};
    img.classList.remove('is-loaded');
    img.onload = null;
    const id = track && track.cover;
    img.dataset.cid = id || '';
    if (!id) { img.removeAttribute('src'); if (hooks.onFail) hooks.onFail(); return; }
    coverUrl(id).then((u) => {
      if (img.dataset.cid !== id) return; // o <img> já foi reutilizado
      if (!u) { if (hooks.onFail) hooks.onFail(); return; }
      img.onload = () => { img.classList.add('is-loaded'); if (hooks.onLoad) hooks.onLoad(u); };
      img.onerror = () => { img.classList.remove('is-loaded'); if (hooks.onFail) hooks.onFail(); };
      img.src = u;
      if (img.complete && img.naturalWidth > 0) img.onload();
    });
  }

  function clearCover(img) {
    img.onload = null; img.onerror = null; img.dataset.cid = '';
    img.removeAttribute('src'); img.classList.remove('is-loaded');
  }

  async function findFolderCover(dir) {
    if (!dir) return null;
    for (const base of COVER_NAMES) {
      for (const ext of COVER_EXT) {
        try {
          const fh = await dir.getFileHandle(`${base}.${ext}`);
          const f = await fh.getFile();
          if (f.size > 0 && f.size < 15 * 1024 * 1024) return f;
        } catch (_) { /* não existe */ }
      }
    }
    return null;
  }

  /* ------------------------------- Ler uma música ---------------------------- */

  async function buildRecord(file, base, dir, dirCovers) {
    const rec = Object.assign({
      title: '', artist: '', album: '', albumArtist: '', no: 0, dur: 0, cover: '',
      size: file.size, mtime: file.lastModified, name: file.name, type: file.type || mimeOf(file.name),
      added: Date.now(), bad: false, hidden: false,
    }, base);
    const dur = await getDuration(file);
    if (dur < 0) { rec.bad = true; return rec; }
    rec.dur = dur;
    const m = await readMeta(file), fb = fromName(file.name);
    rec.title = (m.title || fb.title || file.name).trim();
    rec.artist = (m.artist || fb.artist || '').trim();
    rec.album = (m.album || '').trim();
    rec.albumArtist = (m.albumArtist || '').trim();
    rec.no = m.no || fb.no || 0;

    let coverBlob = null, cid = '';
    if (m.cover) {
      const key = rec.album || rec.title;
      cid = 'e' + hash(`${key}|${rec.albumArtist || rec.artist}`);
      if (!coverIds.has(cid)) coverBlob = await shrink(m.cover);
      if (!coverBlob && !coverIds.has(cid)) cid = '';
    } else if (dir) {
      const dk = base.root + ':' + base.path.slice(0, -1).join('/');
      if (!dirCovers.has(dk)) {
        const f = await findFolderCover(dir);
        const b = f ? await shrink(f) : null;
        const id = b ? 'd' + hash(dk) : '';
        if (b && !coverIds.has(id)) { await dbPut('covers', b, id); coverIds.add(id); }
        dirCovers.set(dk, id);
      }
      cid = dirCovers.get(dk) || '';
    }
    if (coverBlob && cid) { await dbPut('covers', coverBlob, cid); coverIds.add(cid); }
    rec.cover = cid;
    return rec;
  }

  /* ----------------------------- Percorrer uma pasta ------------------------- */

  async function ensurePermission(handle, request) {
    const opts = { mode: 'read' };
    try {
      if (handle.queryPermission) {
        if ((await handle.queryPermission(opts)) === 'granted') return true;
        if (!request) return false;
        return (await handle.requestPermission(opts)) === 'granted';
      }
    } catch (_) { return false; }
    return true;
  }

  async function collect(dir, path, out) {
    for await (const [name, entry] of dir.entries()) {
      if (status.cancel) return;
      if (name.startsWith('.')) continue;
      if (entry.kind === 'directory') await collect(entry, path.concat(name), out);
      else if (isAudioName(name)) out.push({ entry, path: path.concat(name), dir });
    }
  }

  async function scanRoot(root, request) {
    if (!(await ensurePermission(root.handle, request))) { status.needsPermission = true; return { skipped: true }; }
    status.phase = 'collect';
    emit('scan', Object.assign({}, status));
    const items = [];
    try { await collect(root.handle, [], items); }
    catch (e) { if (e && e.name === 'NotFoundError') return { missingRoot: true }; throw e; }
    if (status.cancel) return { cancelled: true };

    status.phase = 'read';
    status.total += items.length;
    emit('scan', Object.assign({}, status));

    const seen = new Set();
    const dirCovers = new Map();
    let pending = [], added = 0, updated = 0, idx = 0;
    const flush = async () => {
      if (!pending.length) return;
      const batch = pending; pending = [];
      await dbPutMany('tracks', batch);
      touch(); emit('change');
    };

    const worker = async () => {
      while (!status.cancel) {
        const i = idx++; if (i >= items.length) return;
        const it = items[i];
        const id = `${root.id}:${it.path.join('/')}`;
        seen.add(id);
        try {
          const file = await it.entry.getFile();
          const old = T.get(id);
          if (old && old.size === file.size && old.mtime === file.lastModified) { status.done++; continue; }
          const rec = await buildRecord(file, {
            id, root: root.id, src: 'dir', path: it.path,
            folder: [root.name].concat(it.path.slice(0, -1)).join('/'),
          }, it.dir, dirCovers);
          if (!rec.bad) { if (old) { rec.added = old.added; rec.hidden = !!old.hidden; updated++; } else added++; } else if (old) { rec.added = old.added; }
          prep(rec);
          T.set(id, rec); pending.push(rec);
          if (!rec.bad) status.found++;
        } catch (_) { /* ficheiro desapareceu ou ilegível: ignora */ }
        status.done++;
        if (pending.length >= 15) await flush();
        if (status.done % 6 === 0) emit('scan', Object.assign({}, status));
      }
    };
    await Promise.all([worker(), worker(), worker(), worker()]);
    await flush();
    if (status.cancel) return { cancelled: true, added, updated };

    // Removidas do armazenamento
    const gone = [];
    T.forEach((t, id) => { if (t.root === root.id && !seen.has(id)) gone.push(id); });
    if (gone.length) {
      const tx = db.transaction('tracks', 'readwrite');
      gone.forEach((id) => { tx.objectStore('tracks').delete(id); T.delete(id); });
      await txDone(tx); touch(); emit('change');
    }
    return { added, updated, removed: gone.length, total: items.length };
  }

  async function cleanupCovers() {
    try {
      const used = new Set(); T.forEach((t) => { if (t.cover) used.add(t.cover); });
      const keys = await dbKeys('covers');
      const del = keys.filter((k) => !used.has(k));
      if (!del.length) return;
      const tx = db.transaction('covers', 'readwrite');
      del.forEach((k) => { tx.objectStore('covers').delete(k); coverIds.delete(k); });
      await txDone(tx);
    } catch (_) { /* não crítico */ }
  }

  /** Percorre todas as pastas guardadas. request=true só com gesto do utilizador. */
  function rescan({ request = false } = {}) {
    if (NATIVE) return nativeRescan({ request });
    scanChain = scanChain.then(async () => {
      if (!roots.size) return { added: 0, removed: 0, total: 0, noRoots: true };
      status.scanning = true; status.cancel = false; status.done = 0; status.total = 0; status.found = 0; status.needsPermission = false;
      emit('scan', Object.assign({}, status));
      const sum = { added: 0, updated: 0, removed: 0, total: 0 };
      try {
        for (const root of Array.from(roots.values())) {
          const r = await scanRoot(root, request);
          if (r) { sum.added += r.added || 0; sum.updated += r.updated || 0; sum.removed += r.removed || 0; sum.total += r.total || 0; if (r.missingRoot) sum.missingRoot = root.name; }
        }
        await cleanupCovers();
      } catch (e) { sum.error = e; console.error('[library] scan', e); }
      status.scanning = false; status.phase = ''; status.lastScan = Date.now();
      touch(); emit('scan', Object.assign({}, status)); emit('change'); emit('scandone', sum);
      return sum;
    });
    return scanChain;
  }

  function cancelScan() { status.cancel = true; if (NATIVE) nativeCall('cancelScan'); }

  /* ------------------------------ Adicionar fontes --------------------------- */

  /** Regista uma pasta (FileSystemDirectoryHandle) e percorre-a. */
  async function addRoot(handle) {
    for (const r of roots.values()) {
      try { if (await r.handle.isSameEntry(handle)) return rescan({ request: true }); } catch (_) { /* ignora */ }
    }
    const root = { id: 'r' + Date.now().toString(36), name: handle.name || 'Música', handle };
    await dbPut('roots', root);
    roots.set(root.id, root);
    return rescan({ request: true });
  }

  /** Abre o seletor de pastas do sistema (precisa de gesto: toque num botão). */
  async function addFolder() {
    if (NATIVE) { nativeCall('pickFolder'); return; }
    if (!hasPicker) { const e = new Error('unsupported'); e.name = 'Unsupported'; throw e; }
    const handle = await global.showDirectoryPicker({ id: 'imusic-music', mode: 'read', startIn: 'music' });
    return addRoot(handle);
  }

  /* --------------------------- Ponte com o Android --------------------------- */
  // O app nativo lê as músicas pelo MediaStore e envia-as em blocos. Os ficheiros
  // são servidos ao <audio> por https://appassets.androidplatform.net/native-audio/<id>.

  let nativeSeen = null, nativeWait = null, nativeChain = Promise.resolve(), nativeStat = { added: 0, updated: 0 }, nativeDog = 0;

  function nativeCall(fn, arg) {
    try { return arg === undefined ? NATIVE[fn]() : NATIVE[fn](arg); } catch (_) { return null; }
  }

  function nativeRescan({ request = false } = {}) {
    if (nativeWait) return nativeWait.promise;
    if (!nativeCall('hasPermission')) {
      status.needsPermission = true; emit('scan', Object.assign({}, status));
      if (request) nativeCall('requestPermission');
      return Promise.resolve({ added: 0, updated: 0, removed: 0, total: 0, noRoots: true });
    }
    let resolve; const promise = new Promise((r) => { resolve = r; });
    nativeWait = { promise, resolve };
    nativeSeen = new Set(); nativeStat = { added: 0, updated: 0 };
    Object.assign(status, { scanning: true, cancel: false, done: 0, total: 0, found: 0, needsPermission: false, phase: 'collect' });
    emit('scan', Object.assign({}, status));
    clearTimeout(nativeDog);
    nativeDog = setTimeout(() => { if (nativeWait) nativeDone({ error: 'timeout' }); }, 180000);
    nativeCall('scan');
    return promise;
  }

  function nativeIngest(p) {
    nativeChain = nativeChain.then(async () => {
      if (!nativeWait || !p) return;
      status.phase = 'read'; status.total = p.total || status.total;
      const batch = [];
      for (const o of (p.items || [])) {
        const id = 'n:' + o.i;
        nativeSeen.add(id);
        status.done++;
        const old = T.get(id);
        const cover = o.c ? 'n:' + o.c : '';
        const title = (o.t || o.nm || '').trim();
        if (old && old.size === o.s && old.mtime === o.m && old.cover === cover && old.dur === o.d && old.title === title) continue;
        const rec = {
          id, root: 'native', src: 'native', path: [o.nm], folder: o.f || '',
          title, artist: o.a || '', album: o.b || '', albumArtist: o.aa || '', no: o.n || 0, dur: o.d || 0, cover,
          size: o.s || 0, mtime: o.m || 0, name: o.nm, type: o.ty || mimeOf(o.nm || ''),
          added: o.da ? o.da * 1000 : Date.now(), bad: false, hidden: old ? !!old.hidden : false,
        };
        prep(rec); T.set(id, rec); batch.push(rec);
        if (old) nativeStat.updated++; else { nativeStat.added++; status.found++; }
      }
      if (batch.length) await dbPutMany('tracks', batch);
      touch(); emit('scan', Object.assign({}, status)); emit('change');
    }).catch((e) => console.error('[library] native', e));
    return nativeChain;
  }

  function nativeDone(info) {
    nativeChain = nativeChain.then(async () => {
      if (!nativeWait) return;
      clearTimeout(nativeDog);
      const sum = { added: nativeStat.added, updated: nativeStat.updated, removed: 0, total: nativeSeen ? nativeSeen.size : 0 };
      if (info && info.error) sum.error = new Error(String(info.error));
      else if (nativeSeen && !(info && info.cancelled)) {
        const gone = [];
        T.forEach((t, id) => { if (t.src === 'native' && !nativeSeen.has(id)) gone.push(id); });
        if (gone.length) {
          const tx = db.transaction('tracks', 'readwrite');
          gone.forEach((id) => { tx.objectStore('tracks').delete(id); T.delete(id); });
          await txDone(tx);
        }
        sum.removed = gone.length;
      }
      const w = nativeWait; nativeWait = null; nativeSeen = null;
      status.scanning = false; status.phase = ''; status.lastScan = Date.now();
      touch(); emit('scan', Object.assign({}, status)); emit('change'); emit('scandone', sum);
      w.resolve(sum);
    }).catch((e) => console.error('[library] native', e));
    return nativeChain;
  }

  /** Android: volta a ler todas as músicas do telemóvel (sem filtro de pastas). */
  function useAll() {
    if (NATIVE) nativeCall('clearFolders');
    return rescan({ request: true });
  }

  /** Plano B: ficheiros escolhidos pelo seletor padrão. Guarda uma cópia no app. */
  async function addFiles(list) {
    const files = Array.from(list || []).filter((f) => isAudioName(f.name) || /^audio\//.test(f.type));
    const sum = { added: 0, dup: 0, bad: 0, full: false, total: files.length };
    if (!files.length) return sum;
    scanChain = scanChain.then(async () => {
      status.scanning = true; status.cancel = false; status.done = 0; status.total = files.length; status.found = 0; status.phase = 'read';
      emit('scan', Object.assign({}, status));
      const dirCovers = new Map();
      let pending = [];
      for (let n = 0; n < files.length; n++) {
        if (status.cancel) break;
        const f = files[n];
        const id = `f:${hash(f.name)}-${f.size}-${f.lastModified}`;
        status.done = n;
        if (T.has(id)) { sum.dup++; continue; }
        try {
          const rel = f.webkitRelativePath ? f.webkitRelativePath.split('/') : [];
          rel.pop();
          const rec = await buildRecord(f, { id, root: '', src: 'blob', path: [f.name], folder: rel.join('/') || 'Importados' }, null, dirCovers);
          if (rec.bad) { sum.bad++; continue; }
          rec.added = Date.now() + n;
          await dbPut('files', f, id);
          prep(rec); T.set(id, rec); pending.push(rec); sum.added++; status.found++;
          if (pending.length >= 10) { await dbPutMany('tracks', pending); pending = []; touch(); emit('change'); }
        } catch (e) {
          if (e && e.name === 'QuotaExceededError') { sum.full = true; break; }
          sum.bad++;
        }
        if (n % 3 === 2) { emit('scan', Object.assign({}, status)); await tick(); }
      }
      if (pending.length) await dbPutMany('tracks', pending);
      try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (_) { /* ok */ }
      status.scanning = false; status.phase = ''; status.lastScan = Date.now();
      touch(); emit('scan', Object.assign({}, status)); emit('change'); emit('scandone', sum);
      return sum;
    });
    await scanChain;
    return sum;
  }

  /** Reativa o acesso às pastas (precisa de gesto) e volta a percorrê-las. */
  async function reconnect() { return rescan({ request: true }); }

  async function checkPermissions() {
    if (NATIVE) {
      status.needsPermission = !nativeCall('hasPermission');
      emit('scan', Object.assign({}, status));
      return !status.needsPermission;
    }
    let need = false;
    for (const r of roots.values()) { if (!(await ensurePermission(r.handle, false))) need = true; }
    status.needsPermission = need;
    emit('scan', Object.assign({}, status));
    return !need;
  }

  /* ---------------------------------- Consulta ------------------------------- */

  function sortList(list) {
    const s = Storage.getSettings(), dir = s.sortDir === -1 ? -1 : 1;
    const cmp = {
      title: (a, b) => coll.compare(a.title, b.title),
      artist: (a, b) => coll.compare(a.artistName, b.artistName) || coll.compare(a.title, b.title),
      album: (a, b) => coll.compare(a.albumName, b.albumName) || (a.no || 0) - (b.no || 0) || coll.compare(a.title, b.title),
      duration: (a, b) => a.dur - b.dur,
      added: (a, b) => a.added - b.added,
    }[s.sortBy] || ((a, b) => coll.compare(a.title, b.title));
    return list.sort((a, b) => cmp(a, b) * dir);
  }

  /** Todas as músicas visíveis (sem duplicadas nem áudios curtos, se ativado) */
  function all() {
    if (cache && cache.v === version && cache.k === JSON.stringify([Storage.getSettings().sortBy, Storage.getSettings().sortDir, Storage.getSettings().hideShort])) return cache.list;
    const s = Storage.getSettings();
    const minDur = s.hideShort ? 30 : 0;
    const seen = new Set(), list = [];
    T.forEach((t) => {
      if (t.bad || t.hidden || t.dur < minDur) return;
      const key = `${norm(t.title)}|${norm(t.artist)}|${t.size}`;
      if (seen.has(key)) return;
      seen.add(key); list.push(t);
    });
    sortList(list);
    cache = { v: version, k: JSON.stringify([s.sortBy, s.sortDir, s.hideShort]), list, groups: {} };
    return list;
  }

  function get(id) { const t = T.get(id); return t && !t.bad && !t.hidden ? t : null; }
  function count() { return all().length; }

  function groups(kind) {
    all();
    if (cache.groups[kind]) return cache.groups[kind];
    const m = new Map();
    const keyOf = {
      artist: (t) => t.artistName,
      album: (t) => `${t.albumName}¦${t.albumArtist || ''}`,
      folder: (t) => t.folder || 'Importados',
    }[kind];
    const nameOf = { artist: (t) => t.artistName, album: (t) => t.albumName, folder: (t) => t.folderName }[kind];
    const subOf = { artist: () => '', album: (t) => t.albumArtist || t.artistName, folder: (t) => t.folder }[kind];
    cache.list.forEach((t) => {
      const k = keyOf(t);
      let g = m.get(k);
      if (!g) { g = { key: k, name: nameOf(t), sub: subOf(t), tracks: [], coverTrack: null }; m.set(k, g); }
      g.tracks.push(t);
      if (!g.coverTrack && t.cover) g.coverTrack = t;
    });
    const out = Array.from(m.values()).sort((a, b) => coll.compare(a.name, b.name));
    if (kind === 'album') out.forEach((g) => g.tracks.sort((a, b) => (a.no || 0) - (b.no || 0) || coll.compare(a.title, b.title)));
    cache.groups[kind] = out;
    return out;
  }

  function group(kind, key) { return groups(kind).find((g) => g.key === key) || null; }

  function search(q) {
    const words = norm(q).trim().split(/\s+/).filter(Boolean);
    if (!words.length) return [];
    return all().filter((t) => words.every((w) => t._s.includes(w)));
  }

  /* ------------------------------ Reprodução / ficheiros --------------------- */

  async function getFile(track) {
    if (track.src === 'native') {
      try {
        const r = await fetch(await getUrl(track));
        if (!r.ok) throw new Error('missing');
        return await r.blob();
      } catch (_) { const e = new Error('missing'); e.code = 'missing'; throw e; }
    }
    if (track.src === 'blob') {
      const f = await dbGet('files', track.id);
      if (!f) { const e = new Error('missing'); e.code = 'missing'; throw e; }
      return f.type ? f : new Blob([f], { type: track.type });
    }
    const root = roots.get(track.root);
    if (!root) { const e = new Error('missing'); e.code = 'missing'; throw e; }
    if (!(await ensurePermission(root.handle, false))) { const e = new Error('permission'); e.code = 'permission'; throw e; }
    try {
      let dir = root.handle;
      for (let i = 0; i < track.path.length - 1; i++) dir = await dir.getDirectoryHandle(track.path[i]);
      const fh = await dir.getFileHandle(track.path[track.path.length - 1]);
      const f = await fh.getFile();
      return f.type ? f : new Blob([f], { type: track.type });
    } catch (err) {
      const e = new Error('missing'); e.code = (err && (err.name === 'NotFoundError' || err.name === 'TypeMismatchError')) ? 'missing' : 'read'; throw e;
    }
  }

  /** URL local (blob:) pronto para o <audio>. Quem chama deve revogar com URL.revokeObjectURL. */
  async function getUrl(track) {
    if (track.src === 'native') return global.location.origin + '/native-audio/' + encodeURIComponent(String(track.id).slice(2));
    return URL.createObjectURL(await getFile(track));
  }

  function markMissing(id) {
    const t = T.get(id);
    if (t) { t.missing = true; touch(); emit('change'); }
  }

  async function hideTrack(id) {
    const t = T.get(id); if (!t) return;
    if (t.src === 'blob') { T.delete(id); const tx = db.transaction(['tracks', 'files'], 'readwrite'); tx.objectStore('tracks').delete(id); tx.objectStore('files').delete(id); await txDone(tx); }
    else { t.hidden = true; await dbPut('tracks', t); }
    touch(); emit('change');
  }

  async function removeAll() {
    status.cancel = true;
    await scanChain.catch(() => {});
    status.cancel = false;
    await dbClear(['tracks', 'covers', 'roots', 'files']);
    T.clear(); roots.clear(); coverIds.clear();
    coverUrls.forEach((u) => URL.revokeObjectURL(u)); coverUrls.clear();
    if (NATIVE) nativeCall('clearFolders');
    touch(); emit('change');
  }

  function rootsInfo() {
    if (NATIVE) { try { return JSON.parse(nativeCall('getFolders') || '[]'); } catch (_) { return []; } }
    return Array.from(roots.values()).map((r) => ({ id: r.id, name: r.name }));
  }

  /* ----------------------------------- Início -------------------------------- */

  async function init() {
    await openDb();
    const [tracks, rts, cks] = await Promise.all([dbGetAll('tracks'), dbGetAll('roots'), dbKeys('covers')]);
    tracks.forEach((t) => T.set(t.id, prep(t)));
    rts.forEach((r) => roots.set(r.id, r));
    cks.forEach((k) => coverIds.add(k));
    touch();
    Storage.setResolver(get);
    await checkPermissions();
  }

  IMusic.Library = {
    init, on, hasPicker, status, isAudioName,
    all, get, count, groups, group, search,
    addFolder, addRoot, addFiles, rescan, reconnect, useAll, nativeIngest, nativeDone, cancelScan, checkPermissions,
    getUrl, getFile, markMissing, hideTrack, removeAll, rootsInfo,
    loadCover, clearCover, coverUrl,
    hasRoots: () => !!NATIVE || roots.size > 0,
    isNative: !!NATIVE,
  };
})(window);
